Sanger Sequence Pipeline v2.1
=============================

Structure:
  app.R                  - Shiny UI/server
  R/core_sanger.R        - AB1 reading, trimming and QC engine
  R/sequence_tools.R     - sequence metrics, biological primer model, chromatogram viewer
  R/export_tools.R       - FASTA/checkpoint exports and BLAST result helpers
  run_app.bat            - Windows launcher

Pipeline:
  1 Upload AB1
  2 Assay & Trim settings
  3 QC & Chromatogram (Checkpoint A)
  4 Rename (Checkpoint B)
  5 Export
  6 NCBI BLAST (Checkpoint C)

v2.1 chromatogram:
  The displayed X axis is Base position, not the internal AB1 trace-sample coordinate.
  Visible bases controls zoom/resolution. Window start base scrolls horizontally through the read.
  Nucleotide labels update with the visible window and become denser when zooming in.

v2.1 primer model:
  Choose which primer was used for the Sanger reaction (Forward, Reverse or Unknown/infer).
  The sequencing primer is treated as a read-start anchor and is only evaluated near the beginning.
  The opposite PCR primer is searched downstream in its reverse-complement orientation, with the
  expected amplicon length used as positional context. The sequencing-primer sequence itself may
  be absent from the called bases because extension begins after the primer.

NCBI BLAST:
  A processed + renamed sequence can be submitted to the official NCBI BLAST URL endpoint.
  NCBI returns an RID (Request ID) and estimated wait. Retrieve checks the job and, when ready,
  parses the top hit into accession, identity, query coverage, E-value and preliminary match support.
  Match support is technical, not yet a locus-aware taxonomic confidence score.
