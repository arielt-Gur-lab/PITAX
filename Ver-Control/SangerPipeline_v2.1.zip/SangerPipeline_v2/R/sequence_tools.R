# ============================================================
# Sequence / primer / chromatogram tools
# ============================================================

sanitize_dna <- function(x) {
  x <- toupper(gsub("\\s+", "", ifelse(is.null(x), "", x)))
  gsub("[^ACGTN]", "", x)
}

reverse_complement <- function(x) {
  x <- sanitize_dna(x)
  if (!nzchar(x)) return("")
  chars <- strsplit(x, "")[[1]]
  comp <- chartr("ACGTN", "TGCAN", chars)
  paste(rev(comp), collapse = "")
}

sequence_gc <- function(x) {
  x <- sanitize_dna(x)
  if (!nzchar(x)) return(NA_real_)
  b <- strsplit(x, "")[[1]]
  valid <- b %in% c("A", "C", "G", "T")
  if (!any(valid)) return(NA_real_)
  round(100 * mean(b[valid] %in% c("G", "C")), 2)
}

sequence_n_count <- function(x) {
  x <- sanitize_dna(x)
  if (!nzchar(x)) return(0L)
  sum(strsplit(x, "")[[1]] == "N")
}

empty_primer_match <- function(primer = "") {
  data.frame(
    orientation = NA_character_, start = NA_integer_, end = NA_integer_,
    identity = NA_real_, matches = NA_integer_, primer_length = nchar(primer),
    query = primer, target = NA_character_, search_from = NA_integer_,
    search_to = NA_integer_, stringsAsFactors = FALSE
  )
}

# Search a defined region for one defined sequence orientation.
# This avoids the old behaviour of choosing a high-scoring site anywhere in the read.
regional_primer_match <- function(sequence, query, search_from = 1L, search_to = NULL) {
  sequence <- sanitize_dna(sequence)
  query <- sanitize_dna(query)
  n <- nchar(sequence)
  L <- nchar(query)

  if (!nzchar(query) || !n || L > n) return(empty_primer_match(query))

  if (is.null(search_to) || is.na(search_to)) search_to <- n
  search_from <- max(1L, as.integer(search_from))
  search_to <- min(n, as.integer(search_to))
  last_start <- min(search_to - L + 1L, n - L + 1L)
  if (last_start < search_from) return(empty_primer_match(query))

  qchars <- strsplit(query, "")[[1]]
  best <- NULL
  for (i in seq.int(search_from, last_start)) {
    target <- substr(sequence, i, i + L - 1L)
    tchars <- strsplit(target, "")[[1]]
    comparable <- qchars != "N" & tchars != "N"
    denom <- sum(comparable)
    matches <- if (denom > 0) sum(qchars[comparable] == tchars[comparable]) else 0L
    identity <- if (denom > 0) 100 * matches / denom else 0
    row <- data.frame(
      orientation = "expected", start = i, end = i + L - 1L,
      identity = identity, matches = matches, primer_length = L,
      query = query, target = target, search_from = search_from,
      search_to = search_to, stringsAsFactors = FALSE
    )
    if (is.null(best) || row$identity > best$identity) best <- row
  }
  best$identity <- round(best$identity, 1)
  best
}

# Biological primer model for a single Sanger read.
# Forward read:
#   - Forward sequencing primer is the start anchor. It may be absent from the called bases
#     because extension begins immediately after the primer.
#   - The opposite Reverse primer site, if reached, is expected as reverse-complement(R).
# Reverse read:
#   - Reverse sequencing primer is the start anchor.
#   - The opposite Forward primer site, if reached, is expected as reverse-complement(F).
# Unknown:
#   - both biological models are evaluated and the model with stronger positional evidence wins.
primer_model_matches <- function(result, settings) {
  seq <- sanitize_dna(result$raw_seq)
  n <- nchar(seq)
  f <- sanitize_dna(settings$forward_primer_seq)
  r <- sanitize_dna(settings$reverse_primer_seq)
  direction <- ifelse(is.null(settings$sequencing_primer), "Forward", settings$sequencing_primer)
  expected_len <- suppressWarnings(as.integer(settings$expected_amplicon_len))
  if (is.na(expected_len) || expected_len < 1) expected_len <- n

  start_window <- min(n, max(80L, min(150L, round(expected_len * 0.20))))
  opposite_half_window <- max(100L, min(220L, round(expected_len * 0.25)))

  build_model <- function(dir) {
    rows <- list()
    if (dir == "Forward") {
      if (nzchar(f)) {
        m <- regional_primer_match(seq, f, 1L, start_window)
        rows[["Forward"]] <- cbind(
          data.frame(Primer="Forward", Role="Sequencing primer / read-start anchor",
                     Expected_sequence="as entered", stringsAsFactors=FALSE), m
        )
      }
      if (nzchar(r)) {
        q <- reverse_complement(r)
        center <- expected_len - nchar(r) + 1L
        lo <- max(start_window + 1L, center - opposite_half_window)
        hi <- min(n, center + opposite_half_window)
        # If the expected amplicon end is beyond the read, search the accessible downstream region.
        if (lo > hi) {
          lo <- max(start_window + 1L, floor(n * 0.35))
          hi <- n
        }
        m <- regional_primer_match(seq, q, lo, hi)
        rows[["Reverse"]] <- cbind(
          data.frame(Primer="Reverse", Role="Opposite primer site",
                     Expected_sequence="reverse-complement", stringsAsFactors=FALSE), m
        )
      }
    } else if (dir == "Reverse") {
      if (nzchar(r)) {
        m <- regional_primer_match(seq, r, 1L, start_window)
        rows[["Reverse"]] <- cbind(
          data.frame(Primer="Reverse", Role="Sequencing primer / read-start anchor",
                     Expected_sequence="as entered", stringsAsFactors=FALSE), m
        )
      }
      if (nzchar(f)) {
        q <- reverse_complement(f)
        center <- expected_len - nchar(f) + 1L
        lo <- max(start_window + 1L, center - opposite_half_window)
        hi <- min(n, center + opposite_half_window)
        if (lo > hi) {
          lo <- max(start_window + 1L, floor(n * 0.35))
          hi <- n
        }
        m <- regional_primer_match(seq, q, lo, hi)
        rows[["Forward"]] <- cbind(
          data.frame(Primer="Forward", Role="Opposite primer site",
                     Expected_sequence="reverse-complement", stringsAsFactors=FALSE), m
        )
      }
    }
    if (!length(rows)) return(data.frame())
    out <- do.call(rbind, rows)
    rownames(out) <- NULL
    out
  }

  if (direction %in% c("Forward", "Reverse")) {
    out <- build_model(direction)
    attr(out, "model_direction") <- direction
    return(out)
  }

  fm <- build_model("Forward")
  rm <- build_model("Reverse")
  score_model <- function(x) {
    if (!nrow(x)) return(-Inf)
    ids <- x$identity[is.finite(x$identity)]
    if (!length(ids)) return(-Inf)
    # Prioritise the start-anchor evidence, then opposite-primer evidence.
    roles <- x$Role
    start_id <- ids[1]
    start_rows <- which(grepl("read-start", roles))
    if (length(start_rows) && is.finite(x$identity[start_rows[1]])) start_id <- x$identity[start_rows[1]]
    opp_rows <- which(roles == "Opposite primer site")
    opp_id <- if (length(opp_rows) && is.finite(x$identity[opp_rows[1]])) x$identity[opp_rows[1]] else 0
    start_id + 0.7 * opp_id
  }
  if (score_model(fm) >= score_model(rm)) {
    attr(fm, "model_direction") <- "Forward (inferred)"
    fm
  } else {
    attr(rm, "model_direction") <- "Reverse (inferred)"
    rm
  }
}

primer_match_table <- function(result, settings) {
  pm <- primer_model_matches(result, settings)
  if (!nrow(pm)) {
    return(data.frame(
      Primer=character(), Name=character(), Role=character(), Expected=character(),
      Start=integer(), End=integer(), Identity_percent=numeric(), Support=character(),
      In_trimmed=character(), Search_region=character(), stringsAsFactors=FALSE
    ))
  }

  name_for <- function(type) {
    val <- if (type == "Forward") settings$forward_primer else settings$reverse_primer
    if (is.null(val) || !nzchar(val)) type else val
  }
  sm <- result$summary
  out <- data.frame(
    Primer = pm$Primer,
    Name = vapply(pm$Primer, name_for, character(1)),
    Role = pm$Role,
    Expected = pm$Expected_sequence,
    Start = pm$start,
    End = pm$end,
    Identity_percent = pm$identity,
    Support = ifelse(is.na(pm$identity), "Not detected",
                     ifelse(pm$identity >= 95, "Strong",
                            ifelse(pm$identity >= 85, "Moderate", "Weak"))),
    In_trimmed = ifelse(is.na(pm$start), "No",
                        ifelse(!is.na(sm$trim_start) & !is.na(sm$trim_end) &
                                 pm$start >= sm$trim_start & pm$end <= sm$trim_end, "Yes", "No")),
    Search_region = ifelse(is.na(pm$search_from), NA_character_, paste0(pm$search_from, "-", pm$search_to)),
    stringsAsFactors = FALSE
  )
  attr(out, "model_direction") <- attr(pm, "model_direction")
  out
}

primer_alignment_text <- function(result, settings) {
  pm_raw <- primer_model_matches(result, settings)
  if (!nrow(pm_raw)) return("No primer sequences supplied.")
  model <- attr(pm_raw, "model_direction")
  pieces <- c(paste0("Sequencing model: ", model), "")
  for (i in seq_len(nrow(pm_raw))) {
    m <- pm_raw[i, , drop=FALSE]
    if (is.na(m$start)) {
      pieces <- c(pieces, paste0(m$Primer, ": no site evaluated/detected."), "")
      next
    }
    qchars <- strsplit(m$query, "")[[1]]
    tchars <- strsplit(m$target, "")[[1]]
    marks <- ifelse(qchars == tchars & qchars != "N" & tchars != "N", "|", " ")
    pieces <- c(
      pieces,
      paste0(m$Primer, " primer — ", m$Role),
      paste0("Search region: bases ", m$search_from, "-", m$search_to,
             " | best site: ", m$start, "-", m$end,
             " | ", m$identity, "% identity | expected ", m$Expected_sequence),
      paste0("Primer  ", m$query),
      paste0("        ", paste(marks, collapse="")),
      paste0("Read    ", m$target),
      ""
    )
  }
  paste(pieces, collapse="\n")
}

# Convert trace-sample coordinates to a continuous base-position coordinate.
# Peak positions map exactly to integer base positions; points between peaks are interpolated.
trace_to_base_x <- function(peak_pos, trace_idx) {
  good <- which(is.finite(peak_pos) & peak_pos >= 1)
  if (length(good) < 2) return(rep(NA_real_, length(trace_idx)))
  approx(x=peak_pos[good], y=good, xout=trace_idx, rule=2, ties="ordered")$y
}

# Main chromatogram: X axis is BASE POSITION, not raw trace sample index.
draw_chromatogram <- function(result, settings, start_base=1L, visible_bases=50L) {
  trace <- result$trace
  peak_pos <- result$peak_pos
  cmap <- result$channel_map
  n <- length(peak_pos)
  visible_bases <- max(10L, min(as.integer(visible_bases), n))
  from_base <- max(1L, min(as.integer(start_base), max(1L, n-visible_bases+1L)))
  to_base <- min(n, from_base + visible_bases - 1L)

  x_from <- max(1L, peak_pos[from_base])
  x_to <- min(nrow(trace), peak_pos[to_base])
  idx <- seq.int(x_from, x_to)
  x_base <- trace_to_base_x(peak_pos, idx)
  vals <- trace[idx, , drop=FALSE]
  ymax <- max(vals, na.rm=TRUE)
  if (!is.finite(ymax) || ymax <= 0) ymax <- 1

  plot(x_base, trace[idx, cmap[["A"]]], type="l", col="green3", lwd=1,
       xlab="Base position", ylab="Signal", xlim=c(from_base, to_base), ylim=c(0, ymax*1.20),
       xaxt="n", main=paste0(result$sample_id, " — bases ", from_base, "-", to_base))
  lines(x_base, trace[idx, cmap[["C"]]], col="blue3", lwd=1)
  lines(x_base, trace[idx, cmap[["G"]]], col="black", lwd=1)
  lines(x_base, trace[idx, cmap[["T"]]], col="red3", lwd=1)

  # X-axis resolution adapts to zoom.
  axis_step <- if (visible_bases <= 30) 1L else if (visible_bases <= 60) 5L else if (visible_bases <= 120) 10L else 20L
  at <- seq(ceiling(from_base/axis_step)*axis_step, to_base, by=axis_step)
  if (!length(at)) at <- c(from_base, to_base)
  axis(1, at=at, labels=at)
  legend("topright", legend=c("A","C","G","T"), col=c("green3","blue3","black","red3"), lty=1, horiz=TRUE, bty="n")

  # Nucleotide labels: every base when zoomed in, progressively sparser when zoomed out.
  bases <- strsplit(result$raw_seq, "")[[1]]
  label_step <- if (visible_bases <= 50) 1L else if (visible_bases <= 100) 2L else if (visible_bases <= 160) 5L else 10L
  label_idx <- seq(from_base, to_base, by=label_step)
  text(label_idx, rep(ymax*1.045, length(label_idx)), labels=bases[label_idx], cex=if (visible_bases<=50) 0.78 else 0.62)

  sm <- result$summary
  if (!is.na(sm$trim_start) && sm$trim_start >= from_base && sm$trim_start <= to_base) abline(v=sm$trim_start, lty=2, lwd=2)
  if (!is.na(sm$trim_end) && sm$trim_end >= from_base && sm$trim_end <= to_base) abline(v=sm$trim_end, lty=2, lwd=2)

  pm <- primer_match_table(result, settings)
  if (nrow(pm)) {
    for (i in seq_len(nrow(pm))) {
      s <- pm$Start[i]; e <- pm$End[i]
      if (!is.na(s) && e >= from_base && s <= to_base) {
        ss <- max(s, from_base); ee <- min(e, to_base)
        col <- if (pm$Primer[i] == "Forward") "darkorange" else "purple"
        rect(ss, ymax*1.09, ee, ymax*1.17, border=col, lwd=2)
        text(mean(c(ss,ee)), ymax*1.13, labels=paste0(pm$Primer[i], " primer"), cex=0.68, col=col)
      }
    }
  }
}

# Overview connects read length, trimming and biologically constrained primer matches.
draw_amplicon_overview <- function(result, settings) {
  n <- nchar(result$raw_seq)
  plot(c(1,n), c(0,1), type="n", xlab="Base position", ylab="", yaxt="n", ylim=c(0,1),
       main=paste0(result$sample_id, " — read / trim / primer overview"))
  segments(1,0.82,n,0.82,lwd=5,col="grey70")
  text(1,0.91,"RAW",adj=0,cex=0.8)
  sm <- result$summary
  if (!is.na(sm$trim_start) && !is.na(sm$trim_end)) {
    segments(sm$trim_start,0.55,sm$trim_end,0.55,lwd=8,col="steelblue")
    text(sm$trim_start,0.66,"TRIMMED",adj=0,cex=0.8,col="steelblue4")
  }
  pm <- primer_match_table(result, settings)
  if (nrow(pm)) {
    for (i in seq_len(nrow(pm))) {
      if (is.na(pm$Start[i])) next
      y <- if (pm$Primer[i]=="Forward") 0.30 else 0.16
      col <- if (pm$Primer[i]=="Forward") "darkorange" else "purple"
      segments(pm$Start[i], y, pm$End[i], y, lwd=8, col=col)
      text(pm$Start[i], y+0.07, paste0(pm$Primer[i], " (", pm$Identity_percent[i], "%)"), adj=0, cex=0.72, col=col)
    }
  }
  abline(v=settings$expected_amplicon_len, lty=3, col="grey50")
  text(min(n,settings$expected_amplicon_len),0.98,"Expected amplicon",adj=c(0.5,1),cex=0.7,col="grey40")
}

make_sequence_preview <- function(result) {
  data.frame(
    Metric=c("Raw length","Trimmed length","GC % (trimmed)","N count (trimmed)","Trim start","Trim end"),
    Value=c(nchar(result$raw_seq),nchar(result$seq),sequence_gc(result$seq),sequence_n_count(result$seq),
            result$summary$trim_start,result$summary$trim_end),
    stringsAsFactors=FALSE
  )
}
