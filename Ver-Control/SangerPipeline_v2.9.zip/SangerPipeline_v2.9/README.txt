Sanger Sequence Pipeline v2.9.0
===============================

Purpose
-------
Local Shiny application for Sanger AB1 processing and sequence identification:

AB1 upload -> Assay & trimming -> QC -> Rename -> Export -> NCBI BLAST -> Taxonomic summary

Key v2.9 additions
------------------
- Save the complete working state to a portable `.sangerproject` file and load it later.
- Saved projects retain processed sequences, chromatogram trace data, QC, rename mapping, RIDs, retrieved BLAST hits, and taxonomic analyses.
- Loading a project restores the completed workflow without re-running trimming or previously retrieved BLAST work.
- BLAST evidence is normalized to one unique accession-level hit per RID before taxonomic interpretation.
- Multiple HSPs (High-scoring Segment Pairs) belonging to one accession no longer count as separate taxonomic votes.
- Headerless BLAST CSV fallback now aggregates HSP query intervals to calculate accession-level query coverage.
- Sequence evidence is based on the near-tied competitive unique-hit set (or top five unique hits if needed), not the weak tail of the full Top-N list.

Project files
-------------
Use the Project bar near the top of the app:

  Save project  -> downloads a .sangerproject file
  Load project  -> restores a previously saved project

The project file may be larger than a normal CSV because it contains the processed AB1 trace information needed to reopen QC/chromatogram views.

Run
---
Double-click run_app.bat, or from R:

  shiny::runApp('.', launch.browser = TRUE)

First run
---------
Missing R packages are installed automatically.

Scientific interpretation
-------------------------
BLAST similarity and agreement among database hits support an identification hypothesis. They are not by themselves formal taxonomic validation. Species-level resolution depends on the target locus, taxonomic group and reference-database representation.

Roadmap
-------
v3.0: isolate-level evidence integration, including Forward/Reverse consensus and multi-locus identification.
