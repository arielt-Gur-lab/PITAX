# ============================================================
# Export / checkpoint / BLAST helpers
# ============================================================

clean_fasta_name <- function(x) {
  x <- trimws(x)
  x <- gsub("\\s+", "_", x)
  gsub("[^A-Za-z0-9_.-]", "_", x)
}

wrap_sequence <- function(seq, width = 80) {
  if (is.null(seq) || !nzchar(seq)) return("")
  starts <- seq(1, nchar(seq), by = width)
  paste(substring(seq, starts, pmin(starts + width - 1, nchar(seq))), collapse = "\n")
}

make_fasta <- function(records, include_metadata = FALSE, summary_df = NULL) {
  out <- character()
  if (!length(records)) return("")
  for (original_name in names(records)) {
    record <- records[[original_name]]
    if (is.null(record) || !nzchar(record$seq)) next
    final_name <- clean_fasta_name(record$final_name)
    header <- paste0(">", final_name)
    if (include_metadata && !is.null(summary_df)) {
      sm <- summary_df[summary_df$sample_id == original_name, , drop = FALSE]
      if (nrow(sm) == 1) {
        header <- paste0(header,
          " target=", gsub("\\s+", "_", sm$target),
          " length=", sm$trimmed_length,
          " trim=", sm$trim_start, "-", sm$trim_end,
          " reason=", sm$reason)
      }
    }
    out <- c(out, header, wrap_sequence(record$seq, 80))
  }
  paste(out, collapse = "\n")
}

write_checkpoint_zip <- function(file, stage, records, summary_df, settings, rename_df = NULL) {
  temp_dir <- tempfile(paste0("sanger_", stage, "_"))
  dir.create(temp_dir, recursive = TRUE)
  on.exit(unlink(temp_dir, recursive = TRUE, force = TRUE), add = TRUE)

  target_name <- clean_fasta_name(settings$target)
  write.csv(summary_df, file.path(temp_dir, paste0(target_name, "_", stage, "_summary.csv")),
            row.names = FALSE, fileEncoding = "UTF-8")
  writeLines(make_fasta(records, FALSE), file.path(temp_dir, paste0(target_name, "_", stage, ".fasta")))
  if (!is.null(rename_df)) {
    write.csv(rename_df, file.path(temp_dir, "rename_map.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  }
  settings_lines <- unlist(lapply(names(settings), function(nm) paste0(nm, ": ", settings[[nm]])))
  writeLines(settings_lines, file.path(temp_dir, "run_settings.txt"))
  files <- list.files(temp_dir, recursive = TRUE, full.names = TRUE)
  zip::zipr(file, files, root = temp_dir)
}

# Preliminary support classification from BLAST-style metrics.
# This is deliberately labeled "support" rather than taxonomic certainty.
blast_match_support <- function(identity, coverage, evalue) {
  identity <- suppressWarnings(as.numeric(identity))
  coverage <- suppressWarnings(as.numeric(coverage))
  evalue <- suppressWarnings(as.numeric(evalue))
  if (any(is.na(c(identity, coverage, evalue)))) return("Unscored")
  if (identity >= 99 && coverage >= 95 && evalue <= 1e-50) return("Strong")
  if (identity >= 97 && coverage >= 90 && evalue <= 1e-20) return("Moderate")
  "Weak / review"
}

parse_blast_csv_top_hit <- function(text) {
  if (is.null(text) || !nzchar(text)) return(NULL)
  if (grepl("Status=WAITING|Status=UNKNOWN|Status=FAILED", text, fixed = FALSE)) return(NULL)
  df <- tryCatch(read.csv(text = text, check.names = FALSE, stringsAsFactors = FALSE), error = function(e) NULL)
  if (is.null(df) || !nrow(df)) return(NULL)

  nms <- tolower(names(df))
  find_col <- function(patterns) {
    idx <- which(vapply(nms, function(x) any(grepl(paste(patterns, collapse = "|"), x)), logical(1)))
    if (length(idx)) idx[1] else NA_integer_
  }

  subj_col <- find_col(c("subject", "description", "title"))
  acc_col <- find_col(c("accession", "acc"))
  ident_col <- find_col(c("identity", "pident"))
  cover_col <- find_col(c("query cover", "qcov"))
  eval_col <- find_col(c("e.?value", "expect"))

  row <- df[1, , drop = FALSE]
  getv <- function(col) if (is.na(col)) NA else row[[col]][1]
  ident <- suppressWarnings(as.numeric(gsub("%", "", getv(ident_col))))
  cover <- suppressWarnings(as.numeric(gsub("%", "", getv(cover_col))))
  ev <- suppressWarnings(as.numeric(getv(eval_col)))

  data.frame(
    top_hit = as.character(getv(subj_col)),
    accession = as.character(getv(acc_col)),
    identity_percent = ident,
    query_coverage_percent = cover,
    evalue = ev,
    match_support = blast_match_support(ident, cover, ev),
    stringsAsFactors = FALSE
  )
}
