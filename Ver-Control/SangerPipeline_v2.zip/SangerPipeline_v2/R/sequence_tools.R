# ============================================================
# Sequence / primer / chromatogram tools
# ============================================================

sanitize_dna <- function(x) {
  x <- toupper(gsub("\\s+", "", ifelse(is.null(x), "", x)))
  gsub("[^ACGTN]", "", x)
}

reverse_complement <- function(x) {
  x <- sanitize_dna(x)
  if (!nzchar(x)) return("")
  chars <- strsplit(x, "")[[1]]
  comp <- chartr("ACGTN", "TGCAN", chars)
  paste(rev(comp), collapse = "")
}

sequence_gc <- function(x) {
  x <- sanitize_dna(x)
  if (!nzchar(x)) return(NA_real_)
  b <- strsplit(x, "")[[1]]
  valid <- b %in% c("A", "C", "G", "T")
  if (!any(valid)) return(NA_real_)
  round(100 * mean(b[valid] %in% c("G", "C")), 2)
}

sequence_n_count <- function(x) {
  x <- sanitize_dna(x)
  if (!nzchar(x)) return(0L)
  sum(strsplit(x, "")[[1]] == "N")
}

# Ungapped sliding alignment. This is intentionally simple and transparent:
# it finds the best position for the primer or its reverse complement.
best_primer_match <- function(sequence, primer) {
  sequence <- sanitize_dna(sequence)
  primer <- sanitize_dna(primer)

  if (!nzchar(primer) || nchar(primer) > nchar(sequence)) {
    return(data.frame(
      orientation = NA_character_, start = NA_integer_, end = NA_integer_,
      identity = NA_real_, matches = NA_integer_, primer_length = nchar(primer),
      query = primer, target = NA_character_, stringsAsFactors = FALSE
    ))
  }

  candidates <- list(
    `as entered` = primer,
    `reverse-complement` = reverse_complement(primer)
  )

  best <- NULL
  for (orientation in names(candidates)) {
    q <- candidates[[orientation]]
    qchars <- strsplit(q, "")[[1]]
    L <- nchar(q)
    for (i in seq_len(nchar(sequence) - L + 1)) {
      target <- substr(sequence, i, i + L - 1)
      tchars <- strsplit(target, "")[[1]]
      comparable <- qchars != "N" & tchars != "N"
      matches <- if (any(comparable)) sum(qchars[comparable] == tchars[comparable]) else 0L
      denom <- sum(comparable)
      identity <- if (denom > 0) 100 * matches / denom else 0
      row <- data.frame(
        orientation = orientation,
        start = i,
        end = i + L - 1,
        identity = identity,
        matches = matches,
        primer_length = L,
        query = q,
        target = target,
        stringsAsFactors = FALSE
      )
      if (is.null(best) || row$identity > best$identity) best <- row
    }
  }

  best$identity <- round(best$identity, 1)
  best
}

primer_match_table <- function(result, settings) {
  out <- list()
  defs <- list(
    Forward = settings$forward_primer_seq,
    Reverse = settings$reverse_primer_seq
  )
  names_map <- list(
    Forward = settings$forward_primer,
    Reverse = settings$reverse_primer
  )

  for (type in names(defs)) {
    seq_primer <- defs[[type]]
    if (is.null(seq_primer) || !nzchar(sanitize_dna(seq_primer))) next
    m <- best_primer_match(result$raw_seq, seq_primer)
    support <- if (is.na(m$identity)) "Not found" else if (m$identity >= 95) "Strong" else if (m$identity >= 85) "Moderate" else "Weak"
    out[[type]] <- data.frame(
      Primer = type,
      Name = ifelse(is.null(names_map[[type]]) || names_map[[type]] == "", type, names_map[[type]]),
      Start = m$start,
      End = m$end,
      Orientation = m$orientation,
      Identity_percent = m$identity,
      Support = support,
      stringsAsFactors = FALSE
    )
  }

  if (!length(out)) {
    return(data.frame(
      Primer = character(), Name = character(), Start = integer(), End = integer(),
      Orientation = character(), Identity_percent = numeric(), Support = character(),
      stringsAsFactors = FALSE
    ))
  }
  do.call(rbind, out)
}

primer_alignment_text <- function(result, settings) {
  pieces <- character()
  defs <- list(
    Forward = settings$forward_primer_seq,
    Reverse = settings$reverse_primer_seq
  )
  for (type in names(defs)) {
    p <- sanitize_dna(defs[[type]])
    if (!nzchar(p)) next
    m <- best_primer_match(result$raw_seq, p)
    if (is.na(m$start)) next
    qchars <- strsplit(m$query, "")[[1]]
    tchars <- strsplit(m$target, "")[[1]]
    marks <- ifelse(qchars == tchars & qchars != "N" & tchars != "N", "|", " ")
    pieces <- c(
      pieces,
      paste0(type, " primer: bases ", m$start, "-", m$end, " (", m$orientation, ", ", m$identity, "% identity)"),
      paste0("Primer  ", m$query),
      paste0("        ", paste(marks, collapse = "")),
      paste0("Read    ", m$target),
      ""
    )
  }
  if (!length(pieces)) "No primer sequences supplied." else paste(pieces, collapse = "\n")
}

# Plot the four inferred channels over a base-index window, with trim and primer tracks.
draw_chromatogram <- function(result, settings, center_base = NULL, flank = 70) {
  trace <- result$trace
  peak_pos <- result$peak_pos
  cmap <- result$channel_map
  n <- length(peak_pos)
  if (is.null(center_base) || is.na(center_base)) center_base <- max(1, floor(n / 2))
  from_base <- max(1, as.integer(center_base - flank))
  to_base <- min(n, as.integer(center_base + flank))
  x_from <- max(1, peak_pos[from_base])
  x_to <- min(nrow(trace), peak_pos[to_base])
  idx <- x_from:x_to

  vals <- trace[idx, , drop = FALSE]
  ymax <- max(vals, na.rm = TRUE)
  if (!is.finite(ymax) || ymax <= 0) ymax <- 1

  plot(idx, trace[idx, cmap[["A"]]], type = "l", col = "green3", lwd = 1,
       xlab = "Trace position", ylab = "Signal", ylim = c(0, ymax * 1.18),
       main = paste0(result$sample_id, " - chromatogram (bases ", from_base, "-", to_base, ")"))
  lines(idx, trace[idx, cmap[["C"]]], col = "blue3", lwd = 1)
  lines(idx, trace[idx, cmap[["G"]]], col = "black", lwd = 1)
  lines(idx, trace[idx, cmap[["T"]]], col = "red3", lwd = 1)
  legend("topright", legend = c("A", "C", "G", "T"), col = c("green3", "blue3", "black", "red3"), lty = 1, horiz = TRUE, bty = "n")

  # Base labels at peak positions.
  bases <- strsplit(result$raw_seq, "")[[1]]
  label_idx <- seq(from_base, to_base, by = max(1, floor((to_base - from_base + 1) / 50)))
  text(peak_pos[label_idx], rep(ymax * 1.03, length(label_idx)), labels = bases[label_idx], cex = 0.65)

  # Trim boundaries.
  sm <- result$summary
  if (!is.na(sm$trim_start) && sm$trim_start >= from_base && sm$trim_start <= to_base) {
    abline(v = peak_pos[sm$trim_start], lty = 2, lwd = 2)
  }
  if (!is.na(sm$trim_end) && sm$trim_end >= from_base && sm$trim_end <= to_base) {
    abline(v = peak_pos[sm$trim_end], lty = 2, lwd = 2)
  }

  # Primer binding intervals.
  pm <- primer_match_table(result, settings)
  if (nrow(pm)) {
    for (i in seq_len(nrow(pm))) {
      s <- pm$Start[i]; e <- pm$End[i]
      if (!is.na(s) && e >= from_base && s <= to_base) {
        ss <- max(s, from_base); ee <- min(e, to_base)
        rect(peak_pos[ss], ymax * 1.08, peak_pos[ee], ymax * 1.16,
             border = if (pm$Primer[i] == "Forward") "darkorange" else "purple",
             lwd = 2)
        text(mean(c(peak_pos[ss], peak_pos[ee])), ymax * 1.12,
             labels = paste0(pm$Primer[i], " primer"), cex = 0.7)
      }
    }
  }
}

make_sequence_preview <- function(result) {
  data.frame(
    Metric = c("Raw length", "Trimmed length", "GC % (trimmed)", "N count (trimmed)", "Trim start", "Trim end"),
    Value = c(
      nchar(result$raw_seq), nchar(result$seq), sequence_gc(result$seq), sequence_n_count(result$seq),
      result$summary$trim_start, result$summary$trim_end
    ),
    stringsAsFactors = FALSE
  )
}
