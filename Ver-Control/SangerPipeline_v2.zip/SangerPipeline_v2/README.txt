Sanger Sequence Pipeline v2
===========================

Run:
  Double-click run_app.bat

Structure:
  app.R
  R/core_sanger.R       - AB1 reading, trimming and QC calculations
  R/sequence_tools.R    - primer matching, sequence metrics, chromatogram viewer
  R/export_tools.R      - FASTA/checkpoint exports and BLAST result helpers

Workflow:
  1 Upload AB1
  2 Assay & Trim settings
  3 QC & Chromatogram (Checkpoint A)
  4 Rename (Checkpoint B)
  5 Export
  6 NCBI BLAST (Checkpoint C)

Primer alignment:
  Supply primer sequences in step 2. The current algorithm performs an ungapped
  sliding match against the raw read in both entered and reverse-complement
  orientations, then displays the best location and identity. This is intended
  as a QC visualization, not a full primer-alignment/amplicon validation engine.

NCBI BLAST:
  Internet access is required on the computer running the app.
  The automated stage uses the official NCBI BLAST URL API.
