Sanger Sequence Pipeline v2.6
=============================

Workflow
--------
1. Upload AB1 files
2. Assay & trimming settings
3. QC + interactive chromatogram
4. Optional rename
5. Export processed sequences
6. NCBI BLAST submission / retrieval
7. Taxonomic summary / multi-hit interpretation

v2.6 changes
------------
- Added "Submit ALL processed sequences" in the NCBI BLAST stage.
- Batch BLAST keeps one RID per sequence, preserving a direct sample -> RID -> hit set -> taxonomy relationship.
- Added "Check / retrieve ALL submitted" to collect results for all submitted sequences.
- Automated BLAST contacts are spaced by at least 10 seconds and the same RID is not polled more than once per minute.
- Batch submission skips sequences whose latest BLAST job is already submitted, waiting, or ready; a selected sequence can still be manually resubmitted if needed.
- BLAST hit count now defaults to 25 per sequence and can be increased to 100.
- The Preliminary identification overview now shows one current top-hit row for every sequence with a retrieved result, instead of filtering to the selected sample.
- The detailed Retrieved BLAST hits table remains sample-specific and now shows 25 rows per page by default.
- The Taxonomic summary selector is kept synchronized as each sequence's BLAST result is retrieved, including batch retrieval.
- Taxonomic interpretation now defaults to the top 25 hits and can use up to 100.

NCBI usage note
---------------
NCBI BLAST is a shared service. This application intentionally uses conservative request spacing. For very large projects or high daily search volumes, use local BLAST+ or another NCBI-supported high-volume option instead of the public BLAST URL API.

Run
---
Double-click run_app.bat, or run from R:

  shiny::runApp('.', launch.browser = TRUE)

First run
---------
The application installs missing R packages automatically. The taxonomic stage uses rentrez and taxize, so the first launch can take longer while their dependencies are installed.

Interpretation note
-------------------
The taxonomic stage is deliberately conservative. BLAST similarity, hit agreement and NCBI taxonomy support an identification hypothesis; they do not by themselves prove a species identification. The discriminatory power of ITS, LSU, TEF1, RPB2, beta-tubulin and other loci depends on the fungal group being examined.

v2.7 taxonomic-consensus fix
----------------------------
- Taxonomic recommendation is now based on agreement among hits resolved at the relevant rank.
- Identity/query coverage are evaluated separately as sequence evidence; weak or missing quality values no longer erase a strong taxonomic consensus and produce a misleading "Unresolved" result.
- Species-unresolved labels (for example "sp.", uncultured, unclassified) are not treated as conflicting species.
- The UI now reports taxonomic support, sequence evidence, resolved-hit agreement, overall Top-N share, and a plain-language decision explanation.
