# ============================================================
# Taxonomic interpretation helpers
# Sanger Sequence Pipeline v2.7
# ============================================================

as_num_safe <- function(x) suppressWarnings(as.numeric(as.character(x)))

clean_taxon_text <- function(x) {
  x <- ifelse(is.na(x), "", trimws(as.character(x)))
  gsub("\\s+", " ", x)
}

# Resolve missing NCBI TaxIDs from organism names using rentrez.
# This is a fallback only: BLAST/nuccore TaxIDs remain preferred because they
# are linked directly to the returned sequence record.
resolve_missing_taxids_rentrez <- function(hits, sleep_seconds = 0.35) {
  if (is.null(hits) || !nrow(hits)) return(hits)
  if (!"taxid" %in% names(hits)) hits$taxid <- NA_integer_
  if (!"organism" %in% names(hits)) hits$organism <- ""

  missing <- which(is.na(suppressWarnings(as.numeric(hits$taxid))) & nzchar(clean_taxon_text(hits$organism)))
  if (!length(missing)) return(hits)

  cache <- new.env(parent = emptyenv())
  for (i in missing) {
    org <- clean_taxon_text(hits$organism[i])
    if (!nzchar(org)) next

    if (exists(org, envir = cache, inherits = FALSE)) {
      hits$taxid[i] <- get(org, envir = cache, inherits = FALSE)
      next
    }

    # Exact scientific-name query. More than one returned identifier is treated
    # as ambiguous rather than silently selecting one.
    srch <- tryCatch(
      rentrez::entrez_search(
        db = "taxonomy",
        term = paste0('"', org, '"[Scientific Name]'),
        retmax = 2
      ),
      error = function(e) NULL
    )

    tx <- NA_integer_
    if (!is.null(srch) && length(srch$ids) == 1) {
      tx <- suppressWarnings(as.integer(srch$ids[1]))
    }
    assign(org, tx, envir = cache)
    hits$taxid[i] <- tx
    Sys.sleep(sleep_seconds)
  }
  hits
}

classification_for_taxid <- function(class_list, taxid, fallback_index = NULL) {
  if (is.null(class_list) || !length(class_list)) return(NULL)
  tx <- as.character(taxid)

  if (!is.null(names(class_list))) {
    idx <- which(names(class_list) == tx)
    if (length(idx)) return(class_list[[idx[1]]])
  }

  # taxize classifications normally contain an id column. Use it to recover a
  # stable mapping if the returned list is unnamed or differently named.
  for (i in seq_along(class_list)) {
    cl <- class_list[[i]]
    if (is.data.frame(cl) && nrow(cl) && "id" %in% names(cl)) {
      ids <- as.character(cl$id)
      if (tx %in% ids) return(cl)
    }
  }

  if (!is.null(fallback_index) && fallback_index <= length(class_list)) {
    return(class_list[[fallback_index]])
  }
  NULL
}

rank_value <- function(classification_df, rank_names) {
  if (is.null(classification_df) || !is.data.frame(classification_df) || !nrow(classification_df)) return("")
  if (!all(c("name", "rank") %in% names(classification_df))) return("")
  rr <- tolower(trimws(as.character(classification_df$rank)))
  nn <- trimws(as.character(classification_df$name))
  for (rk in tolower(rank_names)) {
    idx <- which(rr == rk)
    if (length(idx)) return(nn[idx[length(idx)]])
  }
  ""
}

# Query NCBI taxonomy lineages for all usable TaxIDs and attach common ranks to
# every BLAST hit. The classification list is retained as an attribute so the
# LCA calculation can reuse it without repeating requests.
enrich_hits_with_taxonomy <- function(hits) {
  if (is.null(hits) || !nrow(hits)) return(hits)

  hits <- resolve_missing_taxids_rentrez(hits)
  ids <- unique(as.character(hits$taxid[!is.na(suppressWarnings(as.numeric(hits$taxid)))]))
  ids <- ids[nzchar(ids)]

  empty_cols <- c("kingdom", "phylum", "class", "order", "family", "genus", "species")
  for (nm in empty_cols) if (!nm %in% names(hits)) hits[[nm]] <- ""

  if (!length(ids)) {
    attr(hits, "classification_list") <- list()
    attr(hits, "classification_ids") <- character()
    return(hits)
  }

  classes <- tryCatch(
    taxize::classification(ids, db = "ncbi"),
    error = function(e) {
      attr(list(), "taxonomy_error") <- conditionMessage(e)
      list()
    }
  )

  for (i in seq_len(nrow(hits))) {
    tx <- suppressWarnings(as.integer(hits$taxid[i]))
    if (is.na(tx)) next
    idx_id <- match(as.character(tx), ids)
    cl <- classification_for_taxid(classes, tx, fallback_index = idx_id)
    if (is.null(cl) || !is.data.frame(cl)) next

    hits$kingdom[i] <- rank_value(cl, c("kingdom", "superkingdom"))
    hits$phylum[i]  <- rank_value(cl, "phylum")
    hits$class[i]   <- rank_value(cl, "class")
    hits$order[i]   <- rank_value(cl, "order")
    hits$family[i]  <- rank_value(cl, "family")
    hits$genus[i]   <- rank_value(cl, "genus")
    hits$species[i] <- rank_value(cl, "species")
  }

  attr(hits, "classification_list") <- classes
  attr(hits, "classification_ids") <- ids
  attr(hits, "taxonomy_error") <- attr(classes, "taxonomy_error")
  hits
}

safe_mode_taxon <- function(x, denominator = length(x)) {
  x <- clean_taxon_text(x)
  x <- x[nzchar(x)]
  denominator <- suppressWarnings(as.integer(denominator))
  if (!is.finite(denominator) || denominator < 1) denominator <- length(x)
  if (!length(x)) return(list(name = "", count = 0L, agreement = NA_real_))
  tt <- sort(table(x), decreasing = TRUE)
  list(
    name = names(tt)[1],
    count = as.integer(tt[1]),
    agreement = as.numeric(tt[1]) / denominator
  )
}

locus_interpretation_note <- function(target) {
  target <- toupper(clean_taxon_text(target))
  if (grepl("^ITS$", target)) {
    return("ITS is the primary fungal barcode for many groups, but species-level resolution is taxon-dependent. Concordant BLAST hits support a candidate species; difficult species complexes may require an additional locus.")
  }
  if (grepl("LSU", target)) {
    return("LSU is often robust for higher-level placement, while species-level resolution can be limited in some fungal groups. Treat a species call as provisional unless the group is known to be well resolved by LSU.")
  }
  if (grepl("TEF1|EF1|RPB2|BETA|TUBULIN|CYP51|SDHB", target)) {
    return("This locus can provide useful species-level discrimination in relevant groups, but discriminatory power remains clade-dependent. Interpret BLAST consensus together with the biology of the target group.")
  }
  "BLAST consensus is sequence-similarity evidence, not a formal taxonomic validation. Species-level resolution depends on the locus and the organism group."
}

# Build a transparent multi-hit consensus. Hit frequency is evidence of
# agreement, not independent replication: public databases can contain many
# related or redundant records from the same taxon.
build_taxonomic_consensus <- function(enriched_hits, target = "", top_n = 25L) {
  if (is.null(enriched_hits) || !nrow(enriched_hits)) {
    return(list(summary = data.frame(), hits = data.frame(), counts = data.frame(), lca = data.frame()))
  }

  hits <- enriched_hits[order(as_num_safe(enriched_hits$rank)), , drop = FALSE]
  top_n <- max(1L, min(as.integer(top_n), nrow(hits)))
  hits <- hits[seq_len(top_n), , drop = FALSE]

  # Competitive hits are those whose bit score is essentially tied with the
  # best result. They are used to detect ambiguity among genuinely competing
  # BLAST matches, not to decide the taxon by themselves.
  bits <- as_num_safe(hits$bit_score)
  best_bit <- if (any(is.finite(bits))) max(bits, na.rm = TRUE) else NA_real_
  competitive <- if (is.finite(best_bit)) {
    hits[is.finite(bits) & bits >= best_bit - 2, , drop = FALSE]
  } else {
    hits
  }
  if (!nrow(competitive)) competitive <- hits

  # Resolved-taxonomy agreement is intentionally separated from agreement
  # across all BLAST rows. A row labelled only "sp.", uncultured, unclassified,
  # etc. should not count as evidence *against* a species call; it is simply
  # unresolved at that rank.
  resolved_taxon <- function(x, rank = c("genus", "species")) {
    rank <- match.arg(rank)
    x <- clean_taxon_text(x)
    bad <- !nzchar(x) |
      grepl("(^|\\s)(sp\\.?|cf\\.?|aff\\.?)(\\s|$)", x, ignore.case = TRUE) |
      grepl("uncultured|unclassified|unidentified|unknown|environmental sample|metagenome", x, ignore.case = TRUE)
    if (rank == "species") {
      # A proper species name normally has at least two tokens. This avoids
      # treating higher-rank labels that slipped into the species field as a
      # species-level identification.
      bad <- bad | lengths(strsplit(x, "\\s+")) < 2
    }
    x[bad] <- ""
    x
  }

  genus_vals <- resolved_taxon(hits$genus, "genus")
  species_vals <- resolved_taxon(hits$species, "species")
  comp_genus_vals <- resolved_taxon(competitive$genus, "genus")
  comp_species_vals <- resolved_taxon(competitive$species, "species")

  mode_resolved <- function(vals) {
    vals <- vals[nzchar(vals)]
    if (!length(vals)) return(list(name = "", count = 0L, agreement = NA_real_, n_resolved = 0L))
    tt <- sort(table(vals), decreasing = TRUE)
    list(
      name = names(tt)[1],
      count = as.integer(tt[1]),
      agreement = as.numeric(tt[1]) / length(vals),
      n_resolved = length(vals)
    )
  }

  genus_all <- mode_resolved(genus_vals)
  species_all <- mode_resolved(species_vals)
  genus_comp <- mode_resolved(comp_genus_vals)
  species_comp <- mode_resolved(comp_species_vals)

  # Overall agreement is also retained because it answers a different useful
  # question: what fraction of *all* returned BLAST rows explicitly name the
  # dominant taxon?
  overall_genus_agree <- if (nrow(hits) && nzchar(genus_all$name)) sum(genus_vals == genus_all$name) / nrow(hits) else NA_real_
  overall_species_agree <- if (nrow(hits) && nzchar(species_all$name)) sum(species_vals == species_all$name) / nrow(hits) else NA_real_

  identities <- as_num_safe(hits$identity_percent)
  coverages <- as_num_safe(hits$query_coverage_percent)
  best_identity <- if (any(is.finite(identities))) max(identities, na.rm = TRUE) else NA_real_
  median_identity <- if (any(is.finite(identities))) median(identities[is.finite(identities)], na.rm = TRUE) else NA_real_
  median_coverage <- if (any(is.finite(coverages))) median(coverages[is.finite(coverages)], na.rm = TRUE) else NA_real_

  # Lowest common ancestor (LCA) is supportive context only. Failure to resolve
  # an LCA must never erase a strong genus/species consensus.
  classes <- attr(enriched_hits, "classification_list")
  ids <- unique(as.character(hits$taxid[!is.na(suppressWarnings(as.numeric(hits$taxid)))]))
  ids <- ids[nzchar(ids)]
  lca_df <- data.frame(name = "", rank = "", id = "", stringsAsFactors = FALSE)
  if (length(ids) >= 2 && !is.null(classes) && length(classes)) {
    class_subset <- lapply(seq_along(ids), function(i) {
      classification_for_taxid(classes, ids[i], fallback_index = match(ids[i], attr(enriched_hits, "classification_ids")))
    })
    names(class_subset) <- ids
    class(class_subset) <- class(classes)
    lca_try <- tryCatch(
      taxize::lowest_common(ids, class_list = class_subset),
      error = function(e) NULL
    )
    if (!is.null(lca_try) && is.data.frame(lca_try) && nrow(lca_try)) {
      lca_df <- data.frame(
        name = as.character(lca_try$name[1]),
        rank = as.character(lca_try$rank[1]),
        id = if ("id" %in% names(lca_try)) as.character(lca_try$id[1]) else "",
        stringsAsFactors = FALSE
      )
    }
  }

  # -----------------------------------------------------------------------
  # 1) Taxonomic recommendation: driven by agreement among resolved hits.
  # 2) Sequence evidence: driven by identity / query coverage.
  # 3) Overall confidence: combines both, but low/missing sequence-quality
  #    evidence does NOT turn a strong taxonomic consensus into "Unresolved".
  # -----------------------------------------------------------------------

  recommendation <- "Unresolved"
  rec_rank <- "unresolved"
  taxonomic_support <- "Insufficient"

  if (species_all$n_resolved >= 3 && nzchar(species_all$name) &&
      is.finite(species_all$agreement) && species_all$agreement >= 0.80) {
    recommendation <- species_all$name
    rec_rank <- "species candidate"
    taxonomic_support <- if (species_all$agreement >= 0.95) "Very high" else if (species_all$agreement >= 0.90) "High" else "Moderate"
  } else if (genus_all$n_resolved >= 3 && nzchar(genus_all$name) &&
             is.finite(genus_all$agreement) && genus_all$agreement >= 0.80) {
    recommendation <- genus_all$name
    rec_rank <- "genus"
    taxonomic_support <- if (genus_all$agreement >= 0.95) "Very high" else if (genus_all$agreement >= 0.90) "High" else "Moderate"
  } else if (nzchar(lca_df$name[1])) {
    recommendation <- lca_df$name[1]
    rec_rank <- paste0("LCA: ", lca_df$rank[1])
    taxonomic_support <- "Low / review"
  }

  sequence_evidence <- "Unavailable"
  if (is.finite(median_identity) && is.finite(median_coverage)) {
    if (median_identity >= 99.5 && median_coverage >= 95) {
      sequence_evidence <- "High"
    } else if (median_identity >= 97 && median_coverage >= 85) {
      sequence_evidence <- "Moderate"
    } else {
      sequence_evidence <- "Low"
    }
  }

  confidence <- "Insufficient"
  if (rec_rank == "species candidate") {
    comp_ok <- is.na(species_comp$agreement) || species_comp$agreement >= 0.80
    if (species_all$agreement >= 0.95 && comp_ok && sequence_evidence == "High") {
      confidence <- "High"
    } else if (species_all$agreement >= 0.80 && comp_ok && sequence_evidence %in% c("High", "Moderate")) {
      confidence <- "Moderate"
    } else {
      confidence <- "Low / review"
    }
  } else if (rec_rank == "genus") {
    comp_ok <- is.na(genus_comp$agreement) || genus_comp$agreement >= 0.80
    if (genus_all$agreement >= 0.95 && comp_ok && sequence_evidence %in% c("High", "Moderate")) {
      confidence <- "High"
    } else if (genus_all$agreement >= 0.80 && comp_ok) {
      confidence <- "Moderate"
    } else {
      confidence <- "Low / review"
    }
  } else if (grepl("^LCA:", rec_rank)) {
    confidence <- "Low / review"
  }

  decision_reason <- if (rec_rank == "species candidate") {
    paste0(
      species_all$count, "/", species_all$n_resolved,
      " species-resolved hits support ", species_all$name,
      " (", round(100 * species_all$agreement, 1), "%).",
      if (species_all$n_resolved < nrow(hits)) paste0(" ", nrow(hits) - species_all$n_resolved, " hit(s) were unresolved at species rank and were not treated as conflicting species.") else "",
      " Sequence evidence: ", sequence_evidence, "."
    )
  } else if (rec_rank == "genus") {
    paste0(
      genus_all$count, "/", genus_all$n_resolved,
      " genus-resolved hits support ", genus_all$name,
      " (", round(100 * genus_all$agreement, 1), "%). Sequence evidence: ", sequence_evidence, "."
    )
  } else if (grepl("^LCA:", rec_rank)) {
    paste0("No sufficiently dominant genus/species consensus; lowest common taxon is ", recommendation, ".")
  } else {
    "Too few resolved or concordant taxonomic hits to make a recommendation."
  }

  summary <- data.frame(
    recommended_identification = recommendation,
    recommended_level = rec_rank,
    confidence = confidence,
    taxonomic_support = taxonomic_support,
    sequence_evidence = sequence_evidence,
    decision_reason = decision_reason,
    hits_used = nrow(hits),
    taxonomy_resolved_hits = genus_all$n_resolved,
    genus_resolved_hits = genus_all$n_resolved,
    species_resolved_hits = species_all$n_resolved,
    competitive_hits = nrow(competitive),
    dominant_genus = genus_all$name,
    genus_agreement_percent = ifelse(is.na(genus_all$agreement), NA_real_, round(100 * genus_all$agreement, 1)),
    overall_genus_agreement_percent = ifelse(is.na(overall_genus_agree), NA_real_, round(100 * overall_genus_agree, 1)),
    competitive_genus_agreement_percent = ifelse(is.na(genus_comp$agreement), NA_real_, round(100 * genus_comp$agreement, 1)),
    dominant_species = species_all$name,
    species_agreement_percent = ifelse(is.na(species_all$agreement), NA_real_, round(100 * species_all$agreement, 1)),
    overall_species_agreement_percent = ifelse(is.na(overall_species_agree), NA_real_, round(100 * overall_species_agree, 1)),
    competitive_species_agreement_percent = ifelse(is.na(species_comp$agreement), NA_real_, round(100 * species_comp$agreement, 1)),
    best_identity_percent = ifelse(is.finite(best_identity), round(best_identity, 3), NA_real_),
    median_identity_percent = ifelse(is.finite(median_identity), round(median_identity, 3), NA_real_),
    median_query_coverage_percent = ifelse(is.finite(median_coverage), round(median_coverage, 2), NA_real_),
    lowest_common_taxon = lca_df$name[1],
    lowest_common_rank = lca_df$rank[1],
    locus_note = locus_interpretation_note(target),
    stringsAsFactors = FALSE
  )

  # Transparent frequency table. Agreement (%) is among hits resolved at that
  # rank; Overall (%) is among every BLAST row in the Top-N set.
  count_rows <- list()
  for (level in c("genus", "species")) {
    vals <- if (level == "genus") genus_vals else species_vals
    resolved <- vals[nzchar(vals)]
    if (length(resolved)) {
      tt <- sort(table(resolved), decreasing = TRUE)
      count_rows[[level]] <- data.frame(
        level = level,
        taxon = names(tt),
        hit_count = as.integer(tt),
        resolved_hits = length(resolved),
        agreement_percent = round(100 * as.integer(tt) / length(resolved), 1),
        overall_percent = round(100 * as.integer(tt) / nrow(hits), 1),
        stringsAsFactors = FALSE
      )
    }
  }
  counts <- if (length(count_rows)) do.call(rbind, count_rows) else data.frame(
    level=character(), taxon=character(), hit_count=integer(), resolved_hits=integer(),
    agreement_percent=numeric(), overall_percent=numeric(), stringsAsFactors=FALSE
  )
  rownames(counts) <- NULL

  list(summary = summary, hits = hits, counts = counts, lca = lca_df)
}

make_taxonomy_checkpoint_zip <- function(file, tax_summary, tax_hits, tax_counts, blast_hits = NULL) {
  temp_dir <- tempfile("sanger_taxonomy_")
  dir.create(temp_dir, recursive = TRUE)
  on.exit(unlink(temp_dir, recursive = TRUE, force = TRUE), add = TRUE)

  write.csv(tax_summary, file.path(temp_dir, "taxonomic_summary.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(tax_hits, file.path(temp_dir, "taxonomic_hits_enriched.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(tax_counts, file.path(temp_dir, "taxonomic_agreement_counts.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  if (!is.null(blast_hits) && nrow(blast_hits)) {
    write.csv(blast_hits, file.path(temp_dir, "BLAST_hits_source.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  }

  note <- c(
    "Taxonomic interpretation is a BLAST multi-hit consensus heuristic.",
    "Hit frequencies are not independent biological replicates and can reflect database sampling bias.",
    "Species-level resolution is locus- and clade-dependent; review the locus note in taxonomic_summary.csv."
  )
  writeLines(note, file.path(temp_dir, "README_taxonomic_interpretation.txt"))

  files <- list.files(temp_dir, recursive = TRUE, full.names = TRUE)
  zip::zipr(file, files, root = temp_dir)
}
