Sanger Sequence Pipeline v2.10.2
================================

Purpose
-------
Local Shiny application for Sanger AB1 processing and sequence identification:

AB1 upload -> Assay & trimming -> QC -> Rename -> Export -> NCBI BLAST -> Taxonomic summary

Key v2.10.x additions
-------------------
- Taxonomic interpretation is score-aware and uses a competitive primary BLAST score cluster rather than a flat database-frequency vote.
- BLAST evidence is normalized to one accession-level hit before interpretation.
- A primary high-scoring cluster is identified from the Bit-score profile.
- The best different species and best different genus are compared directly using Delta-Bit.
- If species evidence is insufficient but genus evidence is clear, the app reports the supported genus and retains the best species as a review candidate.
- Candidate Identity and Query coverage are evaluated separately from taxonomic agreement.
- For ITS, the broad 99.6% species / 94.3% genus identity benchmarks from Vu et al. are shown as context, not universal hard cutoffs.
- Reference quality is visible: type-material wording, RefSeq, standard GenBank, or unresolved annotation.
- A BLAST score-landscape plot shows which accessions are inside the primary score cluster.
- Taxonomic analysis uses all unique accession-level hits retrieved for the sample; there is no second Top-N voting/control stage.
- Team summary exports now include candidate species, competitor separation and reference support.

Score-cluster heuristic
----------------------------------
1. Sort unique accession-level hits by Bit score.
2. After at least 3 hits, identify the largest leading score gap while the hit above the gap remains at least 70% of the best Bit score; the gap must be >= max(20 bits, 3% of the best Bit score).
3. The hits before that gap form the primary score cluster.
4. If no large gap exists, use hits with >=90% of the best Bit score.
5. Genus/species agreement is calculated in the primary competitive score cluster; weaker tail hits remain visible in the score landscape and enriched-hit table.
6. The best different species/genus is evaluated separately.

The score-cluster and Delta-Bit categories are application heuristics, not published taxonomic delimitation thresholds. They are intentionally documented in Help / About and should be calibrated with known isolates.

Project files
-------------
Use the Project bar near the top of the app:

  Save project  -> downloads a .sangerproject file
  Load project  -> restores a previously saved project

Projects retain processed sequences, chromatogram data, QC, rename mapping, RIDs, retrieved BLAST hits and taxonomic analyses. v2.10.2 can load v2.9/v2.10 project files. Re-run taxonomic analysis on a loaded sample to apply the current decision logic.

Run
---
Double-click run_app.bat, or from R:

  shiny::runApp('.', launch.browser = TRUE)

First run
---------
Missing R packages are installed automatically.

Scientific interpretation
-------------------------
BLAST similarity and database agreement support an identification hypothesis; they are not formal taxonomic validation. Species-level resolution depends on locus, clade and reference-database quality. The app exposes each decision component so the user can audit why a genus/species recommendation was made.

Scientific basis highlighted in Help / About
-------------------------------------------
- Schoch et al. (2012): ITS as the universal fungal barcode marker.
- Vu et al. (2018): broad fungal ITS identity benchmarks (~99.6% species, ~94.3% genus).
- NCBI RefSeq Targeted Loci: curated fungal ITS reference resources, largely type-derived.
- NCBI BLAST documentation: Bit scores and HSP/accession-level alignment structure.

Roadmap
-------
v3.0: isolate-level evidence integration, including Forward/Reverse consensus and multi-locus identification.


TESTING
-------
The taxonomy smoke test can be run from any working directory.
Easiest option on Windows: double-click run_tests.bat.
Alternatively: Rscript tests/taxonomy_logic_smoke.R
The smoke test is not required for normal app startup; it is a regression check for taxonomy decision logic.


v2.10.4 QC review addition
--------------------------
The QC & Chromatogram stage includes an Ambiguous peak review table. It highlights called positions where another fluorescence channel competes strongly with the called base, where the called channel is not locally dominant, or where the base caller returned N. Select a row to center the interactive chromatogram around that base. Flags are review aids only; they do not edit the sequence automatically. QC flags are included in checkpoint ZIP exports and the team Excel report.
