Sanger Sequence Pipeline v2.13.1
================================

Purpose
-------
Local Shiny application for Sanger AB1 processing and sequence identification:

AB1 upload -> Assay & trimming -> QC -> Rename -> Export -> NCBI BLAST -> Taxonomic summary


Key v2.13 interface completion
------------------------------
- The dashboard visual language now covers every workflow stage, not only Taxonomic summary.
- Aptos is the preferred UI font when available on the computer; sequence/code fields stay monospaced for readability.
- Each stage has a compact heading, clear primary action, consistent cards, reduced explanatory copy, hover help, and responsive layouts.
- Upload, settings, QC, rename, export and BLAST were reorganized into task-oriented workspaces while keeping the same processing behavior and data provenance.
- v2.13.1 is intentionally the final major v2 presentation pass before the planned v3.0 isolate-level / multi-locus architecture.

Key v2.12 visual update
-----------------------
- New shared visual system for the application: cleaner cards, spacing, typography, controls, navigation and tables.
- Taxonomic summary redesigned as a dashboard with a recommendation hero, five evidence cards, clearer interpretation/agreement panels and a restyled BLAST score landscape.
- Long explanatory text in the working view is reduced; concise tooltips and collapsible help keep the data area wide and readable.
- No taxonomy decision thresholds or scientific logic were changed in v2.12.0; the score-aware v2.11.1 decision engine remains the active algorithm.

Key v2.11 additions
-------------------
- QC now includes a manual curation layer: confirmed base edits, IUPAC ambiguity calls and manual trim-boundary changes modify only the curated sequence; raw AB1/base-call evidence is retained.
- Ambiguous-peak flags support right-click curation, per-sample Undo/Redo, History, Reset to auto, Active/Reviewed status and an exported audit log.
- A conservative Auto-correct high-confidence tool previews only strongly supported alternative calls before user confirmation.
- Any sequence-changing curation invalidates previous BLAST/taxonomic results for that sample and marks old RIDs STALE until the current curated sequence is resubmitted.
- The QC working view uses compact tooltips instead of long explanatory paragraphs; full method details remain in Help / About.
- Taxonomic interpretation is score-aware and uses a competitive primary BLAST score cluster rather than a flat database-frequency vote.
- BLAST evidence is normalized to one accession-level hit before interpretation.
- A primary high-scoring cluster is identified from the Bit-score profile.
- The best different species and best different genus are compared directly using Delta-Bit.
- If species evidence is insufficient but genus evidence is clear, the app reports the supported genus and retains the best species as a review candidate.
- Candidate Identity and Query coverage are evaluated separately from taxonomic agreement.
- For ITS, the broad 99.6% species / 94.3% genus identity benchmarks from Vu et al. are shown as context, not universal hard cutoffs.
- Reference quality is visible: type-material wording, RefSeq, standard GenBank, or unresolved annotation.
- A BLAST score-landscape plot shows which accessions are inside the primary score cluster.
- Taxonomic analysis uses all unique accession-level hits retrieved for the sample; there is no second Top-N voting/control stage.
- Team summary exports now include candidate species, competitor separation and reference support.

Score-cluster heuristic
----------------------------------
1. Sort unique accession-level hits by Bit score.
2. After at least 3 hits, identify the largest leading score gap while the hit above the gap remains at least 70% of the best Bit score; the gap must be >= max(20 bits, 3% of the best Bit score).
3. The hits before that gap form the primary score cluster.
4. If no large gap exists, use hits with >=90% of the best Bit score.
5. Genus/species agreement is calculated in the primary competitive score cluster; weaker tail hits remain visible in the score landscape and enriched-hit table.
6. The best different species/genus is evaluated separately.

The score-cluster and Delta-Bit categories are application heuristics, not published taxonomic delimitation thresholds. They are intentionally documented in Help / About and should be calibrated with known isolates.

Project files
-------------
Use the Project bar near the top of the app:

  Save project  -> downloads a .sangerproject file
  Load project  -> restores a previously saved project

Projects retain processed/curated sequences, chromatogram data, automatic trim state, manual curation history, QC, rename mapping, RIDs, retrieved BLAST hits and taxonomic analyses. v2.12.0 remains backward-compatible with v2.9/v2.10 project state; older projects simply begin with an empty curation history.

Run
---
Double-click run_app.bat, or from R:

  shiny::runApp('.', launch.browser = TRUE)

First run
---------
Missing R packages are installed automatically.

Scientific interpretation
-------------------------
BLAST similarity and database agreement support an identification hypothesis; they are not formal taxonomic validation. Species-level resolution depends on locus, clade and reference-database quality. The app exposes each decision component so the user can audit why a genus/species recommendation was made.

Scientific basis highlighted in Help / About
-------------------------------------------
- Schoch et al. (2012): ITS as the universal fungal barcode marker.
- Vu et al. (2018): broad fungal ITS identity benchmarks (~99.6% species, ~94.3% genus).
- NCBI RefSeq Targeted Loci: curated fungal ITS reference resources, largely type-derived.
- NCBI BLAST documentation: Bit scores and HSP/accession-level alignment structure.

Roadmap
-------
v3.0: isolate-level evidence integration, including Forward/Reverse consensus and multi-locus identification.


TESTING
-------
Regression tests can be run from any working directory. Easiest option on Windows: double-click run_tests.bat. It runs taxonomy logic, ambiguous-peak detection, and manual curation/undo-redo smoke tests. These tests are not required for normal app startup.


v2.11 manual curation
---------------------
The QC & Chromatogram stage now separates three layers: immutable raw AB1 evidence, the automatic trim/base calls, and the current curated sequence. Left-click a flag to inspect it and right-click to open curation actions. Sequence-changing actions are confirmed, reversible, logged, exported, and automatically invalidate downstream BLAST/taxonomy results that were generated from an older sequence version.
