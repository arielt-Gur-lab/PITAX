Sanger Sequence Pipeline v2.5
=============================

Workflow
--------
1. Upload AB1 files
2. Assay & trimming settings
3. QC + interactive chromatogram
4. Optional rename
5. Export processed sequences
6. NCBI BLAST submission / retrieval
7. Taxonomic summary / multi-hit interpretation

v2.5 changes
------------
- The workflow indicator at the bottom of every tab is now a non-interactive process diagram: connected dots and lines, not button-like boxes.
- Added a dedicated Taxonomic summary stage after NCBI BLAST.
- Added CRAN dependencies: rentrez and taxize.
- Taxonomic analysis starts from the latest retrieved BLAST hit set for a selected sequence.
- Missing TaxIDs can be resolved conservatively through NCBI Taxonomy using rentrez.
- NCBI lineages are retrieved with taxize::classification().
- Genus, species, family, order, class, phylum and kingdom are attached to usable BLAST hits.
- taxize::lowest_common() is used as one part of the interpretation, but LCA is not treated as the sole identification rule.
- The app calculates top-N genus/species agreement and a separate agreement among near-tied BLAST hits (bit score within 2 of the best hit).
- A transparent, provisional recommendation is generated as species candidate / genus / LCA-level / unresolved, with BLAST-consensus confidence.
- Added locus-aware interpretation notes for ITS, LSU and several protein-coding targets.
- Added Taxonomic summary, agreement table, taxonomy-enriched hit table, and Checkpoint D exports.
- Taxonomic summary exports include the source BLAST hits and a warning that public-database hit counts are not independent biological replicates.

Run
---
Double-click run_app.bat, or run from R:

  shiny::runApp('.', launch.browser = TRUE)

First run
---------
The application installs missing R packages automatically. v2.5 adds rentrez and taxize, so the first launch can take longer while their dependencies are installed.

Interpretation note
-------------------
The taxonomic stage is deliberately conservative. BLAST similarity, hit agreement and NCBI taxonomy support an identification hypothesis; they do not by themselves prove a species identification. The discriminatory power of ITS, LSU, TEF1, RPB2, beta-tubulin and other loci depends on the fungal group being examined.
