# ============================================================
# Sanger Sequence Pipeline v2.5
# Modular Shiny application
# ============================================================

required_cran <- c("shiny", "DT", "zip", "readxl", "httr2", "plotly", "xml2", "rentrez", "taxize")
for (pkg in required_cran) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
}
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("sangerseqR", quietly = TRUE)) BiocManager::install("sangerseqR")

library(shiny)
library(DT)
library(sangerseqR)
options(shiny.maxRequestSize = 500 * 1024^2)

source(file.path("R", "core_sanger.R"), local = TRUE)
source(file.path("R", "sequence_tools.R"), local = TRUE)
source(file.path("R", "export_tools.R"), local = TRUE)
source(file.path("R", "taxonomy_tools.R"), local = TRUE)

# ============================================================
# UI helpers
# ============================================================

panel_box <- function(...) div(class = "panel-box", ...)
section_title <- function(x) div(class = "section-title", x)

stage_topbar <- function(...) {
  div(class = "stage-topbar", ...)
}

pipeline_stage_footer <- function(current_step) {
  labels <- c(
    "Upload",
    "Assay & Trim",
    "QC",
    "Rename",
    "Export",
    "NCBI BLAST",
    "Taxonomic summary"
  )

  pieces <- list()
  for (i in seq_along(labels)) {
    state <- if (i < current_step) "done" else if (i == current_step) "current" else "future"
    pieces[[length(pieces) + 1]] <- div(
      class = paste("schema-stage", state),
      div(class = "schema-dot"),
      div(class = "schema-label", paste0(i, ". ", labels[[i]]))
    )
    if (i < length(labels)) {
      pieces[[length(pieces) + 1]] <- div(
        class = paste("schema-line", if (i < current_step) "done" else "")
      )
    }
  }

  div(
    class = "pipeline-schema-wrap",
    div(class = "pipeline-schema-title", "Workflow position"),
    div(class = "pipeline-schema", pieces)
  )
}

ui <- fluidPage(
  tags$head(
    tags$script(HTML("
      Shiny.addCustomMessageHandler('openUrl', function(message) {
        window.open(message.url, '_blank');
      });
      Shiny.addCustomMessageHandler('copyText', function(message) {
        navigator.clipboard.writeText(message.text);
      });

    ")),
    tags$style(HTML("
      body { background:#f5f7fa; }
      .pipeline-container { max-width:1450px; margin:auto; }
      .app-header { background:white; padding:22px 28px; margin:20px 0 18px; border-radius:12px; border:1px solid #e5e7eb; }
      .app-header h2 { margin:0 0 5px; }
      .app-header p { margin:0; color:#6b7280; }
      .panel-box { background:white; padding:22px; border-radius:12px; border:1px solid #e5e7eb; margin-bottom:18px; }
      .section-title { font-size:20px; font-weight:600; margin-bottom:16px; }
      .summary-card { background:#f8fafc; border:1px solid #e5e7eb; border-radius:10px; padding:15px; margin-bottom:10px; }
      .summary-number { font-size:26px; font-weight:700; }
      .summary-label { color:#6b7280; }
      .settings-note { color:#6b7280; font-size:13px; }
      .status-ok { color:#15803d; font-weight:600; }
      .status-warning { color:#b45309; font-weight:600; }
      .status-error { color:#b91c1c; font-weight:600; }
      .checkpoint { background:#fffaf0; border:1px solid #f3d7a0; }
      .mono { font-family:Consolas,Monaco,monospace; white-space:pre-wrap; word-break:break-all; background:#f8fafc; padding:12px; border-radius:8px; border:1px solid #e5e7eb; }
      table.dataTable td input { color:#111827 !important; background:#fff !important; }
      table.dataTable td input:focus { color:#111827 !important; background:#fff !important; }
      textarea.form-control { font-family:Consolas,Monaco,monospace; }
      .btn { border-radius:7px; margin-right:6px; margin-bottom:6px; }
      .experimental-box { background:#fffdf5; border:1px solid #f1dfae; border-radius:8px; padding:10px 12px; margin-top:8px; }
      .stage-topbar { background:#ffffff; border:1px solid #dbe3ee; border-radius:10px; padding:12px 14px; margin:0 0 16px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
      .stage-topbar .btn { margin-bottom:0; }
      .pipeline-schema-wrap { margin:30px 4px 12px; padding:8px 4px 4px; }
      .pipeline-schema-title { font-size:11px; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:.05em; margin-bottom:14px; }
      .pipeline-schema { display:flex; align-items:flex-start; width:100%; overflow-x:auto; padding:2px 2px 8px; }
      .schema-stage { min-width:92px; max-width:128px; display:flex; flex-direction:column; align-items:center; text-align:center; flex:0 0 auto; }
      .schema-dot { width:13px; height:13px; border-radius:50%; background:#cbd5e1; border:2px solid #f5f7fa; box-shadow:0 0 0 1px #cbd5e1; margin-top:0; }
      .schema-label { margin-top:8px; font-size:11px; line-height:1.25; color:#94a3b8; font-weight:500; }
      .schema-line { flex:1 1 42px; min-width:28px; height:2px; background:#cbd5e1; margin-top:6px; }
      .schema-stage.done .schema-dot { background:#65a30d; box-shadow:0 0 0 1px #65a30d; }
      .schema-stage.done .schema-label { color:#64748b; }
      .schema-line.done { background:#84cc16; }
      .schema-stage.current .schema-dot { width:17px; height:17px; margin-top:-2px; background:#2563eb; box-shadow:0 0 0 3px rgba(37,99,235,.14); border-color:#ffffff; }
      .schema-stage.current .schema-label { color:#1e3a8a; font-weight:700; }
      .taxonomy-hero { background:#f8fafc; border-left:4px solid #2563eb; padding:16px 18px; margin-bottom:16px; }
      .taxonomy-id { font-size:28px; font-weight:700; line-height:1.15; }
      .taxonomy-sub { color:#64748b; margin-top:4px; }
      .confidence-high { color:#15803d; font-weight:700; }
      .confidence-moderate { color:#a16207; font-weight:700; }
      .confidence-low { color:#b91c1c; font-weight:700; }
      .tax-note { background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; color:#475569; }
      table.dataTable td.dt-taxon { min-width:150px; max-width:230px; white-space:normal; line-height:1.25; vertical-align:top; font-style:italic; }
      .raw-response-details { margin-top:14px; }
      .raw-response-details summary { display:inline-block; cursor:pointer; user-select:none; padding:8px 12px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:7px; color:#334155; font-weight:600; }
      .raw-response-details summary:hover { background:#eef2f7; }
      .raw-response-details[open] summary { margin-bottom:10px; background:#eaf2f8; border-color:#9dbbd3; }
      table.dataTable td.dt-organism { min-width:170px; max-width:260px; white-space:nowrap; line-height:1.25; vertical-align:top; font-style:italic; }
      table.dataTable td.dt-hit-title { min-width:300px; max-width:520px; white-space:normal; line-height:1.25; vertical-align:top; }
      table.dataTable td.dt-nowrap { white-space:nowrap; vertical-align:top; }
    "))
  ),

  div(class = "pipeline-container",
    div(class = "app-header",
      h2("Sanger Sequence Pipeline v2.5"),
      p("AB1 processing → QC & chromatogram → rename → export → NCBI BLAST → taxonomic interpretation")
    ),

    tabsetPanel(id = "pipeline_step", type = "tabs",

      # --------------------------------------------------------
      # 1. Upload
      # --------------------------------------------------------
      tabPanel("1 · Upload", value = "upload",
        stage_topbar(
          actionButton("to_settings", "Continue to Settings →", class = "btn-primary")
        ),
        panel_box(
          section_title("Upload raw Sanger sequences"),
          fileInput("ab1_files", "Select AB1 files", multiple = TRUE,
                    accept = c(".ab1", ".AB1"), buttonLabel = "Select files"),
          p(class = "settings-note", "Multiple AB1 chromatogram files can be selected or dragged here."),
          DTOutput("uploaded_files_table")
        ),
        pipeline_stage_footer(1)
      ),

      # --------------------------------------------------------
      # 2. Assay & trimming settings
      # --------------------------------------------------------
      tabPanel("2 · Assay & Trim", value = "settings",
        stage_topbar(
          actionButton("back_upload", "← Back"),
          actionButton("run_trimming", "Run trimming →", class = "btn-primary")
        ),
        fluidRow(
          column(6,
            panel_box(
              section_title("Assay information"),
              selectInput("target", "Target / Gene",
                          c("ITS", "LSU", "TEF1 / EF1-alpha", "RPB2", "Beta-tubulin", "CYP51", "SDHB", "IGS", "Other"),
                          selected = "ITS"),
              textInput("forward_primer", "Forward primer name", ""),
              textInput("forward_primer_seq", "Forward primer sequence (5'→3')", ""),
              textInput("reverse_primer", "Reverse primer name", ""),
              textInput("reverse_primer_seq", "Reverse primer sequence (5'→3')", ""),
              radioButtons(
                "sequencing_primer", "Primer used for this Sanger read",
                choices = c("Forward" = "Forward", "Reverse" = "Reverse", "Unknown / infer" = "Unknown"),
                selected = "Forward", inline = TRUE
              ),
              checkboxInput("enable_primer_mapping", "Enable experimental primer-site mapping in QC", value = FALSE),
              div(class = "experimental-box",
                p(class = "settings-note", style="margin:0;",
                  "Experimental: Sanger base-calling often begins after the sequencing primer and the noisy read start can make primer-site inference unreliable. Keep this off unless primer-site inspection is specifically useful for the run.")),
              numericInput("expected_amplicon_len", "Expected amplicon length (bp)", 650, min = 1),
              numericInput("absolute_max_base_index", "Maximum sequence position (bp)", 680, min = 50)
            )
          ),
          column(6,
            panel_box(
              section_title("Advanced trimming settings"),
              numericInput("window", "Window size", 25, min = 5),
              numericInput("min_peak_ratio", "Minimum peak ratio", 3, min = 0, step = 0.1),
              numericInput("min_relative_signal", "Minimum relative signal", 0.20, min = 0, max = 1, step = 0.01),
              numericInput("min_len_before_collapse", "Minimum length before collapse search", 350, min = 1),
              numericInput("bad_run_windows", "Consecutive bad windows", 12, min = 1),
              numericInput("min_usable_len", "Minimum usable trimmed length", 400, min = 1)
            )
          )
        ),
        pipeline_stage_footer(2)
      ),

      # --------------------------------------------------------
      # 3. QC, chromatogram & sequence preview
      # --------------------------------------------------------
      tabPanel("3 · QC & Chromatogram", value = "qc",
        stage_topbar(
          actionButton("back_settings", "← Back to Settings"),
          actionButton("to_rename", "Continue to Rename →", class = "btn-primary")
        ),
        uiOutput("qc_summary_cards"),
        panel_box(
          section_title("Trimming results"),
          DTOutput("summary_table")
        ),
        fluidRow(
          column(4,
            panel_box(
              section_title("Sequence inspection"),
              selectInput("inspect_sample", "Sample", choices = NULL),
              p(class="settings-note",
                "The chromatogram is now interactive in the browser. Zoom with the mouse wheel or the Plotly zoom tool, pan horizontally, and use the range slider directly under the graph as a scrollbar."),
              DTOutput("sequence_metrics"),
              conditionalPanel(
                condition = "input.enable_primer_mapping === true",
                br(), h5("Experimental primer-site mapping"),
                DTOutput("primer_match_table")
              )
            )
          ),
          column(8,
            panel_box(
              section_title("Read / trim / primer overview"),
              plotOutput("amplicon_overview", height = "190px"),
              uiOutput("expected_amplicon_note")
            ),
            panel_box(
              section_title("Interactive chromatogram"),
              plotly::plotlyOutput("chromatogram_plot", height = "540px"),
              p(class = "settings-note",
                "X axis = called base position. The lower range slider is the horizontal scrollbar. Mouse-wheel zoom and pan happen client-side, so moving through the read does not request a new image from R.")
            )
          )
        ),
        panel_box(
          section_title("QC metrics"),
          plotOutput("qc_plot", height = "650px"),
          p(class = "settings-note",
            "These are the original trimming QC plots: called-base signal and called-peak / second-peak ratio. They are also included as PNG files in checkpoint and final ZIP exports.")
        ),
        conditionalPanel(
          condition = "input.enable_primer_mapping === true",
          panel_box(
            section_title("Experimental primer alignment"),
            verbatimTextOutput("primer_alignment")
          )
        ),
        panel_box(
          section_title("Processed sequence preview"),
          textAreaInput("trimmed_sequence_preview", NULL, value = "", rows = 8, width = "100%")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint A · Processed sequences"),
          p("Save an anchor after trimming/QC before renaming."),
          downloadButton("download_trim_checkpoint", "Download Trim checkpoint ZIP")
        ),
        pipeline_stage_footer(3)
      ),

      # --------------------------------------------------------
      # 4. Rename
      # --------------------------------------------------------
      tabPanel("4 · Rename", value = "rename",
        stage_topbar(
          actionButton("back_qc", "← Back to QC"),
          actionButton("to_export", "Continue to Export →", class = "btn-primary")
        ),
        panel_box(
          section_title("Rename key"),
          p("Edit New_name manually or import a key."),
          fluidRow(
            column(6, fileInput("rename_key_file", "Upload rename key", multiple = FALSE, accept = c(".xlsx", ".csv"))),
            column(6, br(), actionButton("apply_rename_key", "Apply rename key", class = "btn-primary"))
          ),
          p(class = "settings-note", "Required columns: old_id and new_id. Prefix matching is supported, e.g. 265DMAA000 matches 265DMAA000_customer."),
          uiOutput("rename_key_status")
        ),
        panel_box(
          section_title("Batch rename tools"),
          fluidRow(
            column(3, textInput("rename_remove_suffix", "Remove suffix", "_customer")),
            column(3, textInput("rename_prefix", "Add prefix", "")),
            column(3, textInput("rename_suffix", "Add suffix", "")),
            column(3, actionButton("apply_batch_affixes", "Apply suffix/prefix tools", class = "btn-primary"))
          ),
          fluidRow(
            column(4, textInput("rename_find", "Find text", "")),
            column(4, textInput("rename_replace", "Replace with", "")),
            column(4, br(), actionButton("apply_find_replace", "Find & Replace"))
          ),
          actionButton("reset_names", "Reset names to original")
        ),
        panel_box(
          section_title("Sequence names"),
          DTOutput("rename_table"), br(),
          uiOutput("rename_validation")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint B · Renamed sequences"),
          p("Save an anchor after sample names have been resolved."),
          downloadButton("download_rename_checkpoint", "Download Rename checkpoint ZIP")
        ),
        pipeline_stage_footer(4)
      ),

      # --------------------------------------------------------
      # 5. Export
      # --------------------------------------------------------
      tabPanel("5 · Export", value = "export",
        stage_topbar(
          actionButton("back_rename", "← Back to Rename"),
          actionButton("to_blast", "Continue to NCBI BLAST →", class = "btn-primary")
        ),
        panel_box(section_title("Run summary"), uiOutput("export_summary")),
        panel_box(
          section_title("Final data exports"),
          downloadButton("download_blast_fasta", "BLAST FASTA"),
          downloadButton("download_full_fasta", "FASTA + metadata"),
          downloadButton("download_summary_csv", "Summary CSV"),
          downloadButton("download_all_zip", "Final results ZIP")
        ),
        pipeline_stage_footer(5)
      ),

      # --------------------------------------------------------
      # 6. NCBI BLAST
      # --------------------------------------------------------
      tabPanel("6 · NCBI BLAST", value = "blast",
        stage_topbar(
          actionButton("back_export", "← Back to Export"),
          actionButton("to_taxonomy", "Continue to Taxonomic summary →", class = "btn-primary"),
          actionButton("reset_pipeline", "Start new run")
        ),
        panel_box(
          section_title("BLAST query workspace"),
          p("This stage uses the final processed and renamed sequence. The current version can submit a selected sequence to the official NCBI BLAST URL API and retrieve the result when it is ready."),
          fluidRow(
            column(4,
              selectInput("blast_sample", "Sequence", choices = NULL),
              selectInput("blast_database", "NCBI database", choices = c("core_nt", "nt"), selected = "core_nt"),
              numericInput("blast_hitlist", "Maximum hits", 10, min = 1, max = 100),
              actionButton("copy_blast_sequence", "Copy processed sequence"),
              actionButton("open_ncbi_blast", "Open NCBI Nucleotide BLAST"),
              downloadButton("download_selected_blast", "Download selected FASTA")
            ),
            column(8,
              h5("Processed query sequence"),
              textAreaInput("blast_sequence_preview", NULL, value = "", rows = 9, width = "100%")
            )
          )
        ),
        panel_box(
          section_title("NCBI automated submission · initial integration"),
          actionButton("submit_ncbi_blast", "Submit selected sequence to NCBI", class = "btn-primary"),
          actionButton("retrieve_ncbi_blast", "Check / retrieve result"),
          p(class = "settings-note",
            "NCBI asks automated clients not to poll the same RID more often than once per minute; the app enforces that interval."),
          uiOutput("blast_job_status"),
          DTOutput("blast_jobs_table")
        ),
        panel_box(
          section_title("Preliminary identification result"),
          p(class = "settings-note",
            "The summary uses the top retrieved hit. Organism / taxon is read from the NCBI BLAST XML2 result when available, with Nucleotide metadata as a fallback. Match support is technical only; multi-hit taxonomic confidence is the next interpretation layer."),
          DTOutput("blast_identification_table")
        ),
        panel_box(
          section_title("Retrieved BLAST hits"),
          p(class = "settings-note",
            "All returned hits for the selected RID are retained here so the next stage can compare agreement between hits and estimate genus/species-level confidence."),
          DTOutput("blast_hits_table"),
          tags$details(
            class = "raw-response-details",
            tags$summary("Show raw NCBI response ▾"),
            verbatimTextOutput("blast_raw_preview")
          )
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint C · Identification workspace"),
          downloadButton("download_blast_jobs", "Download BLAST job/results CSV"),
          downloadButton("download_blast_hits", "Download all BLAST hits CSV")
        ),
        pipeline_stage_footer(6)
      ),

      # --------------------------------------------------------
      # 7. Taxonomic interpretation
      # --------------------------------------------------------
      tabPanel("7 · Taxonomic summary", value = "taxonomy",
        stage_topbar(
          actionButton("back_blast", "← Back to NCBI BLAST"),
          actionButton("run_taxonomy", "Analyze multi-hit taxonomy", class = "btn-primary"),
          actionButton("reset_pipeline_tax", "Start new run")
        ),
        panel_box(
          section_title("Taxonomic consensus workspace"),
          fluidRow(
            column(5,
              selectInput("tax_sample", "Sequence with retrieved BLAST hits", choices = NULL),
              numericInput("tax_top_n", "Top BLAST hits to interpret", value = 10, min = 3, max = 50, step = 1),
              p(class = "settings-note",
                "The analysis resolves NCBI TaxIDs, retrieves NCBI taxonomy lineages, compares genus/species agreement and examines the set of near-tied top BLAST scores. Hit counts are agreement evidence, not independent biological replicates.")
            ),
            column(7,
              uiOutput("taxonomy_status")
            )
          )
        ),
        uiOutput("taxonomy_hero"),
        uiOutput("taxonomy_summary_cards"),
        fluidRow(
          column(6,
            panel_box(
              section_title("Taxonomic interpretation"),
              DTOutput("taxonomy_summary_table"),
              uiOutput("taxonomy_locus_note")
            )
          ),
          column(6,
            panel_box(
              section_title("Agreement among BLAST hits"),
              DTOutput("taxonomy_counts_table"),
              p(class = "settings-note",
                "Agreement is shown for the selected top-N hits. Database representation can inflate repeated taxa, so the app also evaluates the near-tied competitive-hit set.")
            )
          )
        ),
        panel_box(
          section_title("Taxonomy-enriched BLAST hits"),
          p(class = "settings-note",
            "NCBI taxonomy is attached to each usable BLAST hit. The table makes it possible to inspect whether competing hits differ at species, genus, or higher ranks."),
          DTOutput("taxonomy_hits_table")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint D · Taxonomic interpretation"),
          downloadButton("download_taxonomy_summary", "Download taxonomic summary CSV"),
          downloadButton("download_taxonomy_hits", "Download taxonomy-enriched hits CSV"),
          downloadButton("download_taxonomy_checkpoint", "Download Taxonomy checkpoint ZIP")
        ),
        pipeline_stage_footer(7)
      )
    )
  )
)

# ============================================================
# Server
# ============================================================

server <- function(input, output, session) {
  rv <- reactiveValues(
    results = list(), summary = NULL, rename = NULL, settings = NULL,
    blast_jobs = data.frame(
      final_name=character(), original_name=character(), rid=character(), rtoe=character(),
      status=character(), submitted_at=character(), last_checked_at=character(), stringsAsFactors=FALSE
    ),
    blast_raw = list(), blast_ids = data.frame(), blast_hits = data.frame(),
    taxonomy_summary = data.frame(), taxonomy_hits = data.frame(), taxonomy_counts = data.frame(),
    taxonomy_status_text = "No taxonomic analysis has been run yet."
  )

  # ---------------- Upload ----------------
  output$uploaded_files_table <- renderDT({
    req(input$ab1_files)
    datatable(data.frame(File=input$ab1_files$name, Size_KB=round(input$ab1_files$size/1024,1)),
              rownames=FALSE, options=list(pageLength=15, dom="tip"))
  })

  observeEvent(input$to_settings, {
    if (is.null(input$ab1_files) || nrow(input$ab1_files)==0) {
      showNotification("Please upload at least one AB1 file.", type="error"); return()
    }
    updateTabsetPanel(session, "pipeline_step", selected="settings")
  })
  observeEvent(input$back_upload, updateTabsetPanel(session,"pipeline_step",selected="upload"))
  observeEvent(input$back_settings, updateTabsetPanel(session,"pipeline_step",selected="settings"))
  observeEvent(input$back_qc, updateTabsetPanel(session,"pipeline_step",selected="qc"))
  observeEvent(input$back_rename, updateTabsetPanel(session,"pipeline_step",selected="rename"))
  observeEvent(input$back_export, updateTabsetPanel(session,"pipeline_step",selected="export"))
  observeEvent(input$back_blast, updateTabsetPanel(session,"pipeline_step",selected="blast"))

  # ---------------- Trimming ----------------
  observeEvent(input$run_trimming, {
    req(input$ab1_files)
    settings <- list(
      target=input$target,
      forward_primer=input$forward_primer,
      forward_primer_seq=sanitize_dna(input$forward_primer_seq),
      reverse_primer=input$reverse_primer,
      reverse_primer_seq=sanitize_dna(input$reverse_primer_seq),
      sequencing_primer=input$sequencing_primer,
      enable_primer_mapping=isTRUE(input$enable_primer_mapping),
      expected_amplicon_len=as.integer(input$expected_amplicon_len),
      absolute_max_base_index=as.integer(input$absolute_max_base_index),
      window=as.integer(input$window),
      min_peak_ratio=as.numeric(input$min_peak_ratio),
      min_relative_signal=as.numeric(input$min_relative_signal),
      min_len_before_collapse=as.integer(input$min_len_before_collapse),
      bad_run_windows=as.integer(input$bad_run_windows),
      min_usable_len=as.integer(input$min_usable_len)
    )
    rv$settings <- settings
    all_results <- list(); summaries <- list(); files <- input$ab1_files

    withProgress(message="Processing AB1 files", value=0, {
      for (i in seq_len(nrow(files))) {
        sample_id <- sub("\\.ab1$", "", files$name[i], ignore.case=TRUE)
        incProgress(1/nrow(files), detail=paste("Processing", files$name[i]))
        result <- tryCatch(
          trim_one_ab1(files$datapath[i], sample_id, settings),
          error=function(e) structure(list(error=conditionMessage(e)), class="ab1_error")
        )
        if (inherits(result,"ab1_error")) {
          summaries[[sample_id]] <- make_failure_summary(sample_id, settings, result$error)
        } else {
          all_results[[sample_id]] <- result
          summaries[[sample_id]] <- result$summary
        }
      }
    })

    rv$results <- all_results
    rv$summary <- do.call(rbind, summaries); rownames(rv$summary) <- NULL
    rv$rename <- data.frame(Original_name=rv$summary$sample_id, New_name=rv$summary$sample_id, stringsAsFactors=FALSE)
    choices <- names(rv$results)
    updateSelectInput(session,"inspect_sample",choices=choices,selected=if(length(choices)) choices[1] else character())
    updateTabsetPanel(session,"pipeline_step",selected="qc")
  })

  # ---------------- QC summary ----------------
  output$qc_summary_cards <- renderUI({
    req(rv$summary)
    vals <- c(
      Total=nrow(rv$summary),
      OK=sum(rv$summary$status=="OK",na.rm=TRUE),
      Warnings=sum(rv$summary$status=="SHORT_AFTER_TRIMMING",na.rm=TRUE),
      Failed=sum(rv$summary$status %in% c("FAILED_TRIMMING","ERROR"),na.rm=TRUE)
    )
    fluidRow(lapply(names(vals), function(nm) column(3, div(class="summary-card", div(class="summary-number",vals[[nm]]), div(class="summary-label",nm)))))
  })

  output$summary_table <- renderDT({
    req(rv$summary)
    df <- rv$summary[,c("sample_id","target","raw_length","trimmed_length","trim_start","trim_end","collapse_index","reason","median_peak_ratio_trimmed","status")]
    names(df) <- c("Sample","Target","Raw length","Trimmed length","Start","End","Collapse","Reason","Median peak ratio","Status")
    datatable(df, rownames=FALSE, filter="top", options=list(pageLength=15,scrollX=TRUE))
  })

  selected_result <- reactive({
    req(input$inspect_sample, rv$results[[input$inspect_sample]])
    rv$results[[input$inspect_sample]]
  })

  observeEvent(input$inspect_sample, {
    r <- selected_result()
    updateTextAreaInput(session, "trimmed_sequence_preview", value = r$seq)
  })

  output$sequence_metrics <- renderDT({
    datatable(make_sequence_preview(selected_result()), rownames = FALSE, options = list(dom = "t"))
  })
  output$primer_match_table <- renderDT({
    req(isTRUE(input$enable_primer_mapping))
    datatable(primer_match_table(selected_result(), rv$settings), rownames = FALSE,
              options = list(dom = "t", scrollX = TRUE))
  })
  output$primer_alignment <- renderText({
    req(isTRUE(input$enable_primer_mapping))
    primer_alignment_text(selected_result(), rv$settings)
  })
  output$amplicon_overview <- renderPlot({
    draw_amplicon_overview(selected_result(), rv$settings)
  })
  output$expected_amplicon_note <- renderUI({
    req(rv$settings)
    p(class = "settings-note",
      paste0("Expected PCR amplicon length: ", rv$settings$expected_amplicon_len,
             " bp. This is assay metadata, not a fixed coordinate on the Sanger read."))
  })

  output$chromatogram_plot <- plotly::renderPlotly({
    make_chromatogram_plotly(selected_result(), rv$settings)
  })

  output$qc_plot <- renderPlot({
    draw_qc_metrics(selected_result(), rv$settings)
  })

  observeEvent(input$to_rename, { req(rv$summary); updateTabsetPanel(session,"pipeline_step",selected="rename") })

  # ---------------- Rename key ----------------
  rename_key_data <- reactive({
    req(input$rename_key_file)
    f <- input$rename_key_file; ext <- tolower(tools::file_ext(f$name))
    key <- if (ext=="xlsx") readxl::read_excel(f$datapath) else if (ext=="csv") read.csv(f$datapath,stringsAsFactors=FALSE,check.names=FALSE) else stop("Rename key must be XLSX or CSV.")
    key <- as.data.frame(key,stringsAsFactors=FALSE)
    if (!all(c("old_id","new_id") %in% names(key))) stop("Rename key must contain old_id and new_id columns.")
    key$old_id <- trimws(as.character(key$old_id)); key$new_id <- trimws(as.character(key$new_id))
    key[key$old_id!="" & key$new_id!="",,drop=FALSE]
  })

  observeEvent(input$apply_rename_key, {
    req(rv$rename)
    key <- tryCatch(rename_key_data(), error=function(e){showNotification(conditionMessage(e),type="error");NULL})
    if (is.null(key)) return()
    matched <- 0L
    for(i in seq_len(nrow(rv$rename))) {
      original <- rv$rename$Original_name[i]
      idx <- which(key$old_id==original)
      if(!length(idx)) idx <- which(startsWith(original,key$old_id))
      if(length(idx)==1) { rv$rename$New_name[i] <- key$new_id[idx]; matched <- matched+1L }
    }
    showNotification(paste(matched,"of",nrow(rv$rename),"sample names matched."),type="message")
  })

  observeEvent(input$apply_batch_affixes, {
    req(rv$rename)
    x <- rv$rename$New_name
    rem <- input$rename_remove_suffix
    if(nzchar(rem)) x <- ifelse(endsWith(x, rem), substr(x, 1, nchar(x) - nchar(rem)), x)
    if(nzchar(input$rename_prefix)) x <- paste0(input$rename_prefix,x)
    if(nzchar(input$rename_suffix)) x <- paste0(x,input$rename_suffix)
    rv$rename$New_name <- x
  })
  observeEvent(input$apply_find_replace, {
    req(rv$rename)
    if(!nzchar(input$rename_find)) return()
    rv$rename$New_name <- gsub(input$rename_find,input$rename_replace,rv$rename$New_name,fixed=TRUE)
  })
  observeEvent(input$reset_names, { req(rv$rename); rv$rename$New_name <- rv$rename$Original_name })

  output$rename_table <- renderDT({
    req(rv$rename)
    datatable(rv$rename,rownames=FALSE,editable=list(target="cell",disable=list(columns=c(0))),options=list(pageLength=20,dom="tip"))
  })
  observeEvent(input$rename_table_cell_edit, {
    info <- input$rename_table_cell_edit
    if(info$col==1) rv$rename[info$row,"New_name"] <- as.character(info$value)
  })

  rename_error <- reactive({
    req(rv$rename)
    x <- trimws(rv$rename$New_name)
    if(any(x=="")) return("One or more sequence names are empty.")
    clean <- clean_fasta_name(x)
    if(anyDuplicated(clean)>0) return(paste0("Duplicate sequence name(s): ",paste(unique(clean[duplicated(clean)|duplicated(clean,fromLast=TRUE)]),collapse=", ")))
    NULL
  })
  output$rename_validation <- renderUI({
    e <- rename_error(); if(is.null(e)) div(class="status-ok","✓ Sequence names are valid.") else div(class="status-error",paste0("⚠ ",e))
  })

  # ---------------- Export records ----------------
  export_records <- reactive({
    req(rv$results,rv$rename)
    records <- list()
    for(original_name in names(rv$results)) {
      r <- rv$results[[original_name]]
      idx <- match(original_name,rv$rename$Original_name)
      r$final_name <- if(!is.na(idx)) rv$rename$New_name[idx] else original_name
      records[[original_name]] <- r
    }
    records
  })
  export_summary_df <- reactive({
    req(rv$summary,rv$rename)
    df <- rv$summary
    df$final_name <- rv$rename$New_name[match(df$sample_id,rv$rename$Original_name)]
    df
  })

  observeEvent(input$to_export, {
    e <- rename_error(); if(!is.null(e)){showNotification(e,type="error");return()}
    updateTabsetPanel(session,"pipeline_step",selected="export")
  })

  output$export_summary <- renderUI({
    req(rv$summary,rv$settings)
    tagList(
      p(strong("Target: "),rv$settings$target),
      p(strong("Forward primer: "),ifelse(rv$settings$forward_primer=="","Not specified",rv$settings$forward_primer)),
      p(strong("Reverse primer: "),ifelse(rv$settings$reverse_primer=="","Not specified",rv$settings$reverse_primer)),
      p(strong("Samples processed: "),nrow(rv$summary)),
      p(strong("Sequences available for export: "),sum(rv$summary$trimmed_length>0,na.rm=TRUE))
    )
  })

  # ---------------- Checkpoints ----------------
  output$download_trim_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_checkpoint_A_trim.zip"),
    content=function(file){
      rec <- export_records(); for(n in names(rec)) rec[[n]]$final_name <- n
      write_checkpoint_zip(file,"trim",rec,rv$summary,rv$settings,results=rv$results)
    })
  output$download_rename_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_checkpoint_B_rename.zip"),
    content=function(file) write_checkpoint_zip(file,"renamed",export_records(),export_summary_df(),rv$settings,rv$rename,results=rv$results))

  output$download_blast_fasta <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_BLAST.fasta"),
    content=function(file) writeLines(make_fasta(export_records(),FALSE),file))
  output$download_full_fasta <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_trimmed_sequences.fasta"),
    content=function(file) writeLines(make_fasta(export_records(),TRUE,export_summary_df()),file))
  output$download_summary_csv <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_trim_summary.csv"),
    content=function(file) write.csv(export_summary_df(),file,row.names=FALSE,fileEncoding="UTF-8"))
  output$download_all_zip <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_Sanger_pipeline_results.zip"),
    content=function(file) write_checkpoint_zip(file,"final",export_records(),export_summary_df(),rv$settings,rv$rename,results=rv$results))

  # ---------------- BLAST workspace ----------------
  observeEvent(input$to_blast, {
    rec <- export_records(); choices <- setNames(names(rec),vapply(rec,function(x)x$final_name,character(1)))
    updateSelectInput(session,"blast_sample",choices=choices,selected=if(length(choices)) names(choices)[1] else character())
    updateTabsetPanel(session,"pipeline_step",selected="blast")
  })

  blast_selected <- reactive({ req(input$blast_sample); export_records()[[input$blast_sample]] })
  observe({
    req(input$blast_sample)
    updateTextAreaInput(session,"blast_sequence_preview",value=blast_selected()$seq)
  })
  observeEvent(input$copy_blast_sequence, session$sendCustomMessage("copyText",list(text=blast_selected()$seq)))
  observeEvent(input$open_ncbi_blast, session$sendCustomMessage("openUrl",list(url="https://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE_TYPE=BlastSearch&PROGRAM=blastn")))
  output$download_selected_blast <- downloadHandler(
    filename=function() paste0(clean_fasta_name(blast_selected()$final_name),".fasta"),
    content=function(file) writeLines(paste0(">",clean_fasta_name(blast_selected()$final_name),"\n",wrap_sequence(blast_selected()$seq,80)),file))

  observeEvent(input$submit_ncbi_blast, {
    r <- blast_selected(); req(nzchar(r$seq))
    req_obj <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
      httr2::req_body_form(
        CMD="Put", PROGRAM="blastn", DATABASE=input$blast_database,
        QUERY=paste0(">",clean_fasta_name(r$final_name),"\n",r$seq),
        HITLIST_SIZE=as.integer(input$blast_hitlist)
      ) |>
      httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")
    txt <- tryCatch(
      httr2::resp_body_string(httr2::req_perform(req_obj)),
      error=function(e){showNotification(conditionMessage(e),type="error");NULL}
    )
    if(is.null(txt)) return()
    rid_match <- regmatches(txt, regexpr("RID = [A-Z0-9-]+", txt))
    rtoe_match <- regmatches(txt, regexpr("RTOE = [0-9]+", txt))
    rid <- if (length(rid_match) && nzchar(rid_match)) sub("RID = ", "", rid_match, fixed=TRUE) else ""
    rtoe <- if (length(rtoe_match) && nzchar(rtoe_match)) sub("RTOE = ", "", rtoe_match, fixed=TRUE) else NA_character_
    if(!nzchar(rid)) { showNotification("NCBI did not return a BLAST RID.",type="error"); return() }

    rv$blast_jobs <- rbind(rv$blast_jobs,data.frame(
      final_name=r$final_name,
      original_name=input$blast_sample,
      rid=rid,
      rtoe=rtoe,
      status="SUBMITTED",
      submitted_at=format(Sys.time(),"%Y-%m-%d %H:%M:%S"),
      last_checked_at="",
      stringsAsFactors=FALSE
    ))
    showNotification(paste("Submitted to NCBI. RID:",rid),type="message")
  })

  observeEvent(input$retrieve_ncbi_blast, {
    r <- blast_selected()
    idx_all <- which(rv$blast_jobs$original_name == input$blast_sample)
    if(!length(idx_all)){showNotification("Submit this sequence first.",type="warning");return()}
    job_idx <- tail(idx_all, 1)
    rid <- rv$blast_jobs$rid[job_idx]

    # NCBI asks automated clients not to poll the same RID more frequently than
    # once per minute. Enforce that interval locally to avoid accidental rapid
    # repeated requests from the button.
    reference_time <- rv$blast_jobs$last_checked_at[job_idx]
    if (!nzchar(reference_time)) reference_time <- rv$blast_jobs$submitted_at[job_idx]
    ref <- suppressWarnings(as.POSIXct(reference_time, format="%Y-%m-%d %H:%M:%S"))
    if (!is.na(ref)) {
      elapsed <- as.numeric(difftime(Sys.time(), ref, units="secs"))
      if (is.finite(elapsed) && elapsed < 60) {
        wait_left <- ceiling(60 - elapsed)
        showNotification(paste0("Please wait ", wait_left, " more seconds before checking this RID again."), type="warning")
        return()
      }
    }
    rv$blast_jobs$last_checked_at[job_idx] <- format(Sys.time(),"%Y-%m-%d %H:%M:%S")

    # XML2 is a supported BLAST URL API output format and carries structured hit
    # descriptions/accessions, unlike the headerless tabular CSV response.
    req_obj <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
      httr2::req_url_query(CMD="Get", RID=rid, FORMAT_TYPE="XML2") |>
      httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")
    txt <- tryCatch(
      httr2::resp_body_string(httr2::req_perform(req_obj)),
      error=function(e){showNotification(conditionMessage(e),type="error");NULL}
    )
    if(is.null(txt)) return()

    if(grepl("Status=WAITING",txt)) {
      rv$blast_jobs$status[job_idx] <- "WAITING"
      showNotification("NCBI BLAST is still running.",type="message")
      return()
    }
    if(grepl("Status=FAILED|Status=UNKNOWN",txt)) {
      rv$blast_jobs$status[job_idx] <- "FAILED/UNKNOWN"
      showNotification("NCBI reports failed or unknown job.",type="error")
      return()
    }

    rv$blast_jobs$status[job_idx] <- "READY"
    rv$blast_raw[[rid]] <- txt

    hits <- parse_blast_xml2_hits(
      txt,
      query_length = nchar(r$seq),
      max_hits = as.integer(input$blast_hitlist)
    )

    if (!nrow(hits)) {
      # Defensive fallback: NCBI's tabular CSV response is headerless. Parse its
      # documented 12-field order rather than treating the first hit as column names.
      csv_req <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
        httr2::req_url_query(CMD="Get", RID=rid, FORMAT_TYPE="CSV", ALIGNMENT_VIEW="Tabular") |>
        httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")
      csv_txt <- tryCatch(
        httr2::resp_body_string(httr2::req_perform(csv_req)),
        error=function(e) NULL
      )
      if (!is.null(csv_txt)) {
        hits <- parse_blast_csv_hits_fallback(csv_txt, query_length=nchar(r$seq))
        if (nrow(hits)) rv$blast_raw[[rid]] <- csv_txt
      }
    }

    if (!nrow(hits)) {
      showNotification(
        "The BLAST job is ready, but no hits could be parsed from either XML2 or the tabular fallback.",
        type="warning"
      )
      return()
    }

    # The headerless BLAST tabular fallback contains no organism/title fields.
    # Enrich every hit that is missing display metadata using a batched NCBI
    # Nucleotide EFetch request. This also makes all rows useful for the future
    # multi-hit taxonomic consensus stage.
    needs_meta <- which(
      (!nzchar(ifelse(is.na(hits$organism), "", hits$organism))) |
      (!nzchar(ifelse(is.na(hits$record_title), "", hits$record_title)))
    )

    if (length(needs_meta)) {
      accessions_needed <- unique(hits$accession[needs_meta])
      meta_df <- tryCatch(
        fetch_ncbi_nucleotide_metadata_batch(accessions_needed),
        error = function(e) {
          showNotification(
            paste("BLAST hits were retrieved, but NCBI metadata enrichment failed:", conditionMessage(e)),
            type = "warning"
          )
          data.frame()
        }
      )

      if (nrow(meta_df)) {
        strip_version <- function(x) sub("\\.[0-9]+$", "", as.character(x))
        for (i in needs_meta) {
          acc <- hits$accession[i]
          idx <- which(meta_df$accession == acc)
          if (!length(idx) && "primary_accession" %in% names(meta_df)) {
            idx <- which(meta_df$primary_accession == strip_version(acc))
          }
          if (!length(idx)) {
            idx <- which(strip_version(meta_df$accession) == strip_version(acc))
          }
          if (length(idx)) {
            m <- meta_df[idx[1], , drop = FALSE]
            if ((!nzchar(hits$organism[i]) || is.na(hits$organism[i])) && nzchar(m$organism[1])) {
              hits$organism[i] <- m$organism[1]
            }
            if ((!nzchar(hits$record_title[i]) || is.na(hits$record_title[i])) && nzchar(m$title[1])) {
              hits$record_title[i] <- m$title[1]
            }
            if ((is.na(hits$taxid[i]) || !is.finite(hits$taxid[i])) && !is.na(m$taxid[1])) {
              hits$taxid[i] <- m$taxid[1]
            }
          }
        }
      }
    }

    hits$final_name <- r$final_name
    hits$original_name <- input$blast_sample
    hits$rid <- rid

    hit_cols <- c(
      "final_name","original_name","rid","rank","organism","record_title","accession","taxid",
      "identity_percent","query_coverage_percent","evalue","bit_score","alignment_length","hsp_count","match_support"
    )
    for (nm in setdiff(hit_cols,names(hits))) hits[[nm]] <- NA
    hits <- hits[, hit_cols, drop=FALSE]

    if (nrow(rv$blast_hits) && "rid" %in% names(rv$blast_hits)) {
      rv$blast_hits <- rv$blast_hits[rv$blast_hits$rid != rid,,drop=FALSE]
    }
    rv$blast_hits <- rbind(rv$blast_hits, hits)

    top <- hits[1,,drop=FALSE]
    top_cols <- c(
      "final_name","original_name","rid","organism","record_title","accession","taxid",
      "identity_percent","query_coverage_percent","evalue","bit_score","match_support"
    )
    if (nrow(rv$blast_ids) && "rid" %in% names(rv$blast_ids)) {
      rv$blast_ids <- rv$blast_ids[rv$blast_ids$rid != rid,,drop=FALSE]
    }
    rv$blast_ids <- rbind(rv$blast_ids, top[,top_cols,drop=FALSE])

    showNotification(paste0("BLAST result retrieved: ", nrow(hits), " hit(s) parsed."),type="message")
  })

  output$blast_job_status <- renderUI({
    req(input$blast_sample)
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name==input$blast_sample,,drop=FALSE]
    if(!nrow(jobs)) return(p(class="settings-note","No NCBI submission yet for this sequence."))
    j <- jobs[nrow(jobs),]
    div(
      class=if(j$status=="READY") "status-ok" else "status-warning",
      paste("RID:",j$rid,"| Status:",j$status,"| Estimated wait (RTOE):",j$rtoe,"seconds")
    )
  })

  output$blast_jobs_table <- renderDT({
    df <- rv$blast_jobs
    if (!nrow(df)) return(datatable(data.frame(Message="No BLAST jobs submitted yet."), rownames=FALSE, options=list(dom="t")))
    keep <- c("final_name","original_name","rid","rtoe","status","submitted_at","last_checked_at")
    df <- df[, intersect(keep,names(df)), drop=FALSE]
    friendly <- c(
      final_name="Sample", original_name="Original sample", rid="RID", rtoe="Estimated wait (s)",
      status="Status", submitted_at="Submitted at", last_checked_at="Last checked at"
    )
    names(df) <- unname(friendly[names(df)])
    datatable(df,rownames=FALSE,options=list(pageLength=10,scrollX=TRUE))
  })

  output$blast_identification_table <- renderDT({
    df <- rv$blast_ids
    if (nrow(df) && !is.null(input$blast_sample)) {
      df <- df[df$original_name == input$blast_sample,,drop=FALSE]
    }
    if(!nrow(df)) {
      return(datatable(
        data.frame(Message="No parsed identification result yet. Submit and retrieve a BLAST job."),
        rownames=FALSE, options=list(dom="t")
      ))
    }

    keep <- intersect(c(
      "final_name","organism","accession","identity_percent","query_coverage_percent",
      "evalue","bit_score","match_support","record_title","taxid","rid"
    ), names(df))
    df <- df[, keep, drop=FALSE]
    friendly <- c(
      final_name="Sample", organism="Organism / taxon", accession="Accession",
      identity_percent="Identity (%)", query_coverage_percent="Query coverage (%)",
      evalue="E-value", bit_score="Bit score", match_support="Match support",
      record_title="NCBI hit title", taxid="NCBI TaxID", rid="RID"
    )
    names(df) <- unname(friendly[names(df)])

    datatable(
      df,
      rownames=FALSE,
      options=list(
        pageLength=10,
        scrollX=TRUE,
        autoWidth=TRUE,
        columnDefs=list(
          list(targets=1, className="dt-organism", width="190px"),
          list(targets=8, className="dt-hit-title", width="440px"),
          list(targets=c(0,2,3,4,5,6,7,9,10), className="dt-nowrap")
        )
      )
    )
  })

  output$blast_hits_table <- renderDT({
    df <- rv$blast_hits
    if (nrow(df) && !is.null(input$blast_sample)) {
      jobs <- rv$blast_jobs[rv$blast_jobs$original_name == input$blast_sample,,drop=FALSE]
      if (nrow(jobs)) {
        latest_rid <- jobs$rid[nrow(jobs)]
        df <- df[df$rid == latest_rid,,drop=FALSE]
      } else {
        df <- df[0,,drop=FALSE]
      }
    }
    if (!nrow(df)) {
      return(datatable(data.frame(Message="No retrieved hits yet."), rownames=FALSE, options=list(dom="t")))
    }

    # Keep the main table focused on identification. Alignment length and HSP
    # count remain in the downloadable all-hits CSV but do not compete with the
    # taxon/title columns for screen width.
    keep <- intersect(c(
      "rank","organism","accession","identity_percent","query_coverage_percent",
      "evalue","bit_score","match_support","record_title","taxid"
    ), names(df))
    df <- df[, keep, drop=FALSE]
    friendly <- c(
      rank="Rank", organism="Organism / taxon", accession="Accession",
      identity_percent="Identity (%)", query_coverage_percent="Query coverage (%)",
      evalue="E-value", bit_score="Bit score", match_support="Match support",
      record_title="NCBI hit title", taxid="NCBI TaxID"
    )
    names(df) <- unname(friendly[names(df)])

    datatable(
      df,
      rownames=FALSE,
      filter="top",
      options=list(
        pageLength=10,
        scrollX=TRUE,
        autoWidth=TRUE,
        columnDefs=list(
          list(targets=1, className="dt-organism", width="190px"),
          list(targets=8, className="dt-hit-title", width="440px"),
          list(targets=c(0,2,3,4,5,6,7,9), className="dt-nowrap")
        )
      )
    )
  })

  output$blast_raw_preview <- renderText({
    req(input$blast_sample)
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name==input$blast_sample,,drop=FALSE]
    if(!nrow(jobs)) return("")
    rid <- jobs$rid[nrow(jobs)]; txt <- rv$blast_raw[[rid]]
    if(is.null(txt)) return("")
    substr(txt,1,min(5000,nchar(txt)))
  })

  output$download_blast_jobs <- downloadHandler(
    filename=function() "NCBI_BLAST_jobs_and_identifications.csv",
    content=function(file){
      jobs <- rv$blast_jobs
      if(nrow(rv$blast_ids)) jobs <- merge(jobs,rv$blast_ids,by=c("final_name","original_name","rid"),all.x=TRUE)
      write.csv(jobs,file,row.names=FALSE,fileEncoding="UTF-8")
    })

  output$download_blast_hits <- downloadHandler(
    filename=function() "NCBI_BLAST_all_hits.csv",
    content=function(file) write.csv(rv$blast_hits,file,row.names=FALSE,fileEncoding="UTF-8")
  )


  # ---------------- Taxonomic interpretation ----------------
  latest_blast_rid_for_sample <- function(original_name) {
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name == original_name,,drop=FALSE]
    if (!nrow(jobs)) return("")
    jobs$rid[nrow(jobs)]
  }

  blast_hits_for_sample <- function(original_name) {
    rid <- latest_blast_rid_for_sample(original_name)
    if (!nzchar(rid) || !nrow(rv$blast_hits)) return(rv$blast_hits[0,,drop=FALSE])
    rv$blast_hits[rv$blast_hits$rid == rid,,drop=FALSE]
  }

  update_tax_sample_choices <- function(selected = NULL) {
    if (!nrow(rv$blast_hits)) {
      updateSelectInput(session, "tax_sample", choices = character())
      return(invisible(NULL))
    }
    pairs <- unique(rv$blast_hits[,c("original_name","final_name"),drop=FALSE])
    pairs <- pairs[nzchar(as.character(pairs$original_name)),,drop=FALSE]
    choices <- setNames(as.character(pairs$original_name), as.character(pairs$final_name))
    if (is.null(selected) || !selected %in% choices) selected <- if (length(choices)) choices[1] else character()
    updateSelectInput(session, "tax_sample", choices = choices, selected = selected)
  }

  observeEvent(input$pipeline_step, {
    if (identical(input$pipeline_step, "taxonomy") && nrow(rv$blast_hits)) {
      selected <- if (!is.null(input$tax_sample) && nzchar(input$tax_sample)) input$tax_sample else if (!is.null(input$blast_sample) && nzchar(input$blast_sample)) input$blast_sample else NULL
      update_tax_sample_choices(selected)
    }
  }, ignoreInit = TRUE)

  observeEvent(input$to_taxonomy, {
    if (!nrow(rv$blast_hits)) {
      showNotification("Retrieve at least one BLAST result before taxonomic interpretation.", type="warning")
      return()
    }
    selected <- if (!is.null(input$blast_sample) && nzchar(input$blast_sample)) input$blast_sample else NULL
    update_tax_sample_choices(selected)
    updateTabsetPanel(session, "pipeline_step", selected="taxonomy")
  })

  observeEvent(input$run_taxonomy, {
    req(input$tax_sample)
    src <- blast_hits_for_sample(input$tax_sample)
    if (!nrow(src)) {
      showNotification("No retrieved BLAST hits are available for this sequence.", type="warning")
      return()
    }

    rid <- unique(as.character(src$rid))[1]
    final_name <- unique(as.character(src$final_name))[1]
    top_n <- min(max(1L, as.integer(input$tax_top_n)), nrow(src))
    rv$taxonomy_status_text <- paste0("Resolving NCBI taxonomy for ", final_name, "...")

    enriched <- NULL
    result <- NULL
    err <- NULL

    withProgress(message="Taxonomic interpretation", value=0, {
      incProgress(0.15, detail="Resolving TaxIDs and NCBI lineages")
      enriched <- tryCatch(
        enrich_hits_with_taxonomy(src),
        error=function(e) { err <<- conditionMessage(e); NULL }
      )
      if (!is.null(enriched)) {
        incProgress(0.55, detail="Comparing genus and species agreement")
        result <- tryCatch(
          build_taxonomic_consensus(enriched, target=rv$settings$target, top_n=top_n),
          error=function(e) { err <<- conditionMessage(e); NULL }
        )
      }
      incProgress(0.30, detail="Preparing interpretation")
    })

    if (is.null(result) || !nrow(result$summary)) {
      rv$taxonomy_status_text <- if (!is.null(err)) paste("Taxonomic analysis failed:", err) else "Taxonomic analysis did not produce a summary."
      showNotification(rv$taxonomy_status_text, type="error")
      return()
    }

    tax_error <- attr(enriched, "taxonomy_error")

    sm <- result$summary
    sm$final_name <- final_name
    sm$original_name <- input$tax_sample
    sm$rid <- rid
    sm$target <- rv$settings$target
    sm$top_n_requested <- top_n
    sm$analyzed_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
    order_cols <- c("final_name","original_name","rid","target","recommended_identification","recommended_level","confidence")
    sm <- sm[,c(order_cols, setdiff(names(sm), order_cols)),drop=FALSE]

    th <- result$hits
    th$final_name <- final_name
    th$original_name <- input$tax_sample
    th$rid <- rid

    tc <- result$counts
    tc$final_name <- final_name
    tc$original_name <- input$tax_sample
    tc$rid <- rid

    if (nrow(rv$taxonomy_summary) && "rid" %in% names(rv$taxonomy_summary)) rv$taxonomy_summary <- rv$taxonomy_summary[rv$taxonomy_summary$rid != rid,,drop=FALSE]
    if (nrow(rv$taxonomy_hits) && "rid" %in% names(rv$taxonomy_hits)) rv$taxonomy_hits <- rv$taxonomy_hits[rv$taxonomy_hits$rid != rid,,drop=FALSE]
    if (nrow(rv$taxonomy_counts) && "rid" %in% names(rv$taxonomy_counts)) rv$taxonomy_counts <- rv$taxonomy_counts[rv$taxonomy_counts$rid != rid,,drop=FALSE]

    rv$taxonomy_summary <- rbind(rv$taxonomy_summary, sm)
    rv$taxonomy_hits <- rbind(rv$taxonomy_hits, th)
    rv$taxonomy_counts <- rbind(rv$taxonomy_counts, tc)

    rv$taxonomy_status_text <- paste0(
      "Analysis complete for ", final_name, ": ",
      sm$recommended_identification[1], " · ", sm$recommended_level[1],
      " · confidence ", sm$confidence[1], "."
    )
    if (!is.null(tax_error) && nzchar(tax_error)) {
      rv$taxonomy_status_text <- paste0(rv$taxonomy_status_text, " Some NCBI lineage lookups reported: ", tax_error)
    }
    showNotification("Taxonomic consensus completed.", type="message")
  })

  selected_tax_summary <- reactive({
    req(input$tax_sample)
    if (!nrow(rv$taxonomy_summary)) return(rv$taxonomy_summary[0,,drop=FALSE])
    rid <- latest_blast_rid_for_sample(input$tax_sample)
    rv$taxonomy_summary[rv$taxonomy_summary$rid == rid,,drop=FALSE]
  })

  selected_tax_hits <- reactive({
    req(input$tax_sample)
    if (!nrow(rv$taxonomy_hits)) return(rv$taxonomy_hits[0,,drop=FALSE])
    rid <- latest_blast_rid_for_sample(input$tax_sample)
    rv$taxonomy_hits[rv$taxonomy_hits$rid == rid,,drop=FALSE]
  })

  selected_tax_counts <- reactive({
    req(input$tax_sample)
    if (!nrow(rv$taxonomy_counts)) return(rv$taxonomy_counts[0,,drop=FALSE])
    rid <- latest_blast_rid_for_sample(input$tax_sample)
    rv$taxonomy_counts[rv$taxonomy_counts$rid == rid,,drop=FALSE]
  })

  output$taxonomy_status <- renderUI({
    div(class="tax-note", strong("Status: "), rv$taxonomy_status_text)
  })

  output$taxonomy_hero <- renderUI({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(NULL)
    conf <- tolower(as.character(sm$confidence[1]))
    conf_class <- if (grepl("high", conf)) "confidence-high" else if (grepl("moderate", conf)) "confidence-moderate" else "confidence-low"
    panel_box(
      div(class="taxonomy-hero",
        div(class="taxonomy-id", sm$recommended_identification[1]),
        div(class="taxonomy-sub",
          paste0("Recommended level: ", sm$recommended_level[1], " · "),
          span(class=conf_class, paste0("Confidence: ", sm$confidence[1]))
        )
      )
    )
  })

  output$taxonomy_summary_cards <- renderUI({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(NULL)
    val <- function(x, suffix="") if (is.na(x) || !nzchar(as.character(x))) "—" else paste0(x, suffix)
    fluidRow(
      column(3, div(class="summary-card", div(class="summary-number", val(sm$genus_agreement_percent[1], "%")), div(class="summary-label", "Genus agreement"))),
      column(3, div(class="summary-card", div(class="summary-number", val(sm$species_agreement_percent[1], "%")), div(class="summary-label", "Species agreement"))),
      column(3, div(class="summary-card", div(class="summary-number", val(sm$competitive_hits[1])), div(class="summary-label", "Near-tied hits"))),
      column(3, div(class="summary-card", div(class="summary-number", val(sm$lowest_common_taxon[1])), div(class="summary-label", paste0("Lowest common taxon", if(nzchar(sm$lowest_common_rank[1])) paste0(" (",sm$lowest_common_rank[1],")") else ""))))
    )
  })

  output$taxonomy_summary_table <- renderDT({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(datatable(data.frame(Message="Run multi-hit taxonomic analysis for this sequence."), rownames=FALSE, options=list(dom="t")))
    keep <- intersect(c(
      "recommended_identification","recommended_level","confidence","hits_used","taxonomy_resolved_hits","competitive_hits",
      "dominant_genus","genus_agreement_percent","competitive_genus_agreement_percent",
      "dominant_species","species_agreement_percent","competitive_species_agreement_percent",
      "best_identity_percent","median_identity_percent","median_query_coverage_percent","lowest_common_taxon","lowest_common_rank"
    ), names(sm))
    df <- sm[,keep,drop=FALSE]
    friendly <- c(
      recommended_identification="Recommended identification", recommended_level="Recommended level", confidence="Confidence",
      hits_used="Hits used", taxonomy_resolved_hits="Taxonomy-resolved hits", competitive_hits="Near-tied hits",
      dominant_genus="Dominant genus", genus_agreement_percent="Genus agreement (%)",
      competitive_genus_agreement_percent="Near-tied genus agreement (%)", dominant_species="Dominant species",
      species_agreement_percent="Species agreement (%)", competitive_species_agreement_percent="Near-tied species agreement (%)",
      best_identity_percent="Best identity (%)", median_identity_percent="Median identity (%)",
      median_query_coverage_percent="Median query coverage (%)", lowest_common_taxon="Lowest common taxon", lowest_common_rank="LCA rank"
    )
    names(df) <- unname(friendly[names(df)])
    datatable(df, rownames=FALSE, options=list(dom="t", scrollX=TRUE, autoWidth=TRUE))
  })

  output$taxonomy_locus_note <- renderUI({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(NULL)
    div(class="tax-note", strong(paste0("Locus-aware note (", sm$target[1], "): ")), sm$locus_note[1])
  })

  output$taxonomy_counts_table <- renderDT({
    df <- selected_tax_counts()
    if (!nrow(df)) return(datatable(data.frame(Message="No agreement summary yet."), rownames=FALSE, options=list(dom="t")))
    keep <- intersect(c("level","taxon","hit_count","agreement_percent"), names(df))
    df <- df[,keep,drop=FALSE]
    names(df) <- c("Level","Taxon","Hit count","Agreement (%)")[seq_along(names(df))]
    datatable(df, rownames=FALSE, options=list(pageLength=12, dom="tip", order=list(list(0,"asc"),list(2,"desc"))))
  })

  output$taxonomy_hits_table <- renderDT({
    df <- selected_tax_hits()
    if (!nrow(df)) return(datatable(data.frame(Message="No taxonomy-enriched hits yet."), rownames=FALSE, options=list(dom="t")))
    keep <- intersect(c(
      "rank","organism","genus","species","family","accession","taxid","identity_percent","query_coverage_percent","evalue","bit_score"
    ), names(df))
    df <- df[,keep,drop=FALSE]
    friendly <- c(
      rank="BLAST rank", organism="NCBI organism", genus="Genus", species="Species", family="Family",
      accession="Accession", taxid="NCBI TaxID", identity_percent="Identity (%)",
      query_coverage_percent="Query coverage (%)", evalue="E-value", bit_score="Bit score"
    )
    names(df) <- unname(friendly[names(df)])
    datatable(
      df, rownames=FALSE, filter="top",
      options=list(
        pageLength=10, scrollX=TRUE, autoWidth=TRUE,
        columnDefs=list(
          list(targets=c(1,2,3,4), className="dt-taxon"),
          list(targets=c(0,5,6,7,8,9,10), className="dt-nowrap")
        )
      )
    )
  })

  output$download_taxonomy_summary <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(input$tax_sample), "sample", input$tax_sample)), "_taxonomic_summary.csv"),
    content=function(file) write.csv(selected_tax_summary(), file, row.names=FALSE, fileEncoding="UTF-8")
  )

  output$download_taxonomy_hits <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(input$tax_sample), "sample", input$tax_sample)), "_taxonomy_enriched_hits.csv"),
    content=function(file) write.csv(selected_tax_hits(), file, row.names=FALSE, fileEncoding="UTF-8")
  )

  output$download_taxonomy_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(input$tax_sample), "sample", input$tax_sample)), "_checkpoint_D_taxonomy.zip"),
    content=function(file) {
      req(nrow(selected_tax_summary()))
      source_hits <- blast_hits_for_sample(input$tax_sample)
      make_taxonomy_checkpoint_zip(file, selected_tax_summary(), selected_tax_hits(), selected_tax_counts(), source_hits)
    }
  )

  # ---------------- Reset ----------------
  reset_pipeline_state <- function() {
    rv$results <- list(); rv$summary <- NULL; rv$rename <- NULL; rv$settings <- NULL
    rv$blast_jobs <- rv$blast_jobs[0,]; rv$blast_raw <- list(); rv$blast_ids <- data.frame(); rv$blast_hits <- data.frame()
    rv$taxonomy_summary <- data.frame(); rv$taxonomy_hits <- data.frame(); rv$taxonomy_counts <- data.frame()
    rv$taxonomy_status_text <- "No taxonomic analysis has been run yet."
    updateTabsetPanel(session,"pipeline_step",selected="upload")
  }
  observeEvent(input$reset_pipeline, reset_pipeline_state())
  observeEvent(input$reset_pipeline_tax, reset_pipeline_state())
}

shinyApp(ui=ui,server=server)
