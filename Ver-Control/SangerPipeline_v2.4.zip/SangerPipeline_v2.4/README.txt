Sanger Sequence Pipeline v2.4
=============================

Workflow
--------
1. Upload AB1 files
2. Assay & trimming settings
3. QC + interactive chromatogram
4. Optional rename
5. Export processed sequences
6. NCBI BLAST submission / retrieval

v2.4 changes
------------
- Back / Continue / Run navigation controls moved to the top of each stage.
- A pipeline-position diagram is shown at the bottom of every stage.
- Raw NCBI response is now a clearly styled disclosure button.
- Retrieved BLAST hit table is reorganized around identification fields so organism names and hit titles have usable column widths.
- Technical alignment-length and HSP-count fields remain in the all-hits CSV export but no longer crowd the on-screen identification table.
- When BLAST falls back to the headerless tabular result, metadata is enriched for ALL returned accessions using batched NCBI Nucleotide EFetch requests, rather than only enriching hit #1.
- Organism, record title and TaxID are filled from Nucleotide metadata when available.
- Existing QC plots and QC PNG checkpoint/final export behavior are retained.

Run
---
Double-click run_app.bat, or run from R:

  shiny::runApp('.', launch.browser = TRUE)

Notes
-----
The NCBI BLAST integration is still an identification workspace. Match support is a technical heuristic and is not yet the final multi-hit / locus-aware confidence interpretation layer.
