# ============================================================
# Taxonomic interpretation helpers
# Sanger Sequence Pipeline v2.10.2
# Score-aware, rank-aware identification logic
# ============================================================

as_num_safe <- function(x) suppressWarnings(as.numeric(as.character(x)))

clean_taxon_text <- function(x) {
  x <- ifelse(is.na(x), "", trimws(as.character(x)))
  gsub("\\s+", " ", x)
}

# ---------------------------------------------------------------------------
# NCBI taxonomy resolution
# ---------------------------------------------------------------------------

resolve_missing_taxids_rentrez <- function(hits, sleep_seconds = 0.35) {
  if (is.null(hits) || !nrow(hits)) return(hits)
  if (!"taxid" %in% names(hits)) hits$taxid <- NA_integer_
  if (!"organism" %in% names(hits)) hits$organism <- ""

  missing <- which(is.na(suppressWarnings(as.numeric(hits$taxid))) & nzchar(clean_taxon_text(hits$organism)))
  if (!length(missing)) return(hits)

  cache <- new.env(parent = emptyenv())
  for (i in missing) {
    org <- clean_taxon_text(hits$organism[i])
    if (!nzchar(org)) next

    if (exists(org, envir = cache, inherits = FALSE)) {
      hits$taxid[i] <- get(org, envir = cache, inherits = FALSE)
      next
    }

    srch <- tryCatch(
      rentrez::entrez_search(
        db = "taxonomy",
        term = paste0('"', org, '"[Scientific Name]'),
        retmax = 2
      ),
      error = function(e) NULL
    )

    tx <- NA_integer_
    if (!is.null(srch) && length(srch$ids) == 1) {
      tx <- suppressWarnings(as.integer(srch$ids[1]))
    }
    assign(org, tx, envir = cache)
    hits$taxid[i] <- tx
    Sys.sleep(sleep_seconds)
  }
  hits
}

classification_for_taxid <- function(class_list, taxid, fallback_index = NULL) {
  if (is.null(class_list) || !length(class_list)) return(NULL)
  tx <- as.character(taxid)

  if (!is.null(names(class_list))) {
    idx <- which(names(class_list) == tx)
    if (length(idx)) return(class_list[[idx[1]]])
  }

  for (i in seq_along(class_list)) {
    cl <- class_list[[i]]
    if (is.data.frame(cl) && nrow(cl) && "id" %in% names(cl)) {
      ids <- as.character(cl$id)
      if (tx %in% ids) return(cl)
    }
  }

  if (!is.null(fallback_index) && fallback_index <= length(class_list)) {
    return(class_list[[fallback_index]])
  }
  NULL
}

rank_value <- function(classification_df, rank_names) {
  if (is.null(classification_df) || !is.data.frame(classification_df) || !nrow(classification_df)) return("")
  if (!all(c("name", "rank") %in% names(classification_df))) return("")
  rr <- tolower(trimws(as.character(classification_df$rank)))
  nn <- trimws(as.character(classification_df$name))
  for (rk in tolower(rank_names)) {
    idx <- which(rr == rk)
    if (length(idx)) return(nn[idx[length(idx)]])
  }
  ""
}

# ---------------------------------------------------------------------------
# Reference-quality annotation
# ---------------------------------------------------------------------------

is_unresolved_taxon_label <- function(x, rank = c("any", "genus", "species")) {
  rank <- match.arg(rank)
  x <- clean_taxon_text(x)
  bad <- !nzchar(x) |
    grepl("(^|\\s)(sp\\.?|cf\\.?|aff\\.?)(\\s|$)", x, ignore.case = TRUE) |
    grepl("uncultured|unclassified|unidentified|unknown|environmental sample|metagenome", x, ignore.case = TRUE)
  if (rank == "species") bad <- bad | lengths(strsplit(x, "\\s+")) < 2
  bad
}

reference_quality_label <- function(accession, title = "", organism = "") {
  accession <- clean_taxon_text(accession)
  title <- clean_taxon_text(title)
  organism <- clean_taxon_text(organism)

  type_pattern <- paste(
    c("type material", "type strain", "ex-type", "ex type", "holotype", "isotype",
      "lectotype", "neotype", "epitype", "paratype", "syntype"),
    collapse = "|"
  )

  if (grepl(type_pattern, title, ignore.case = TRUE)) return("Type material")

  # RefSeq accessions contain an underscore (e.g. NR_, NG_, NC_, NM_). For
  # fungal ITS, NR_ is especially relevant. This marks RefSeq status; it does
  # not claim that every RefSeq record is type-derived.
  if (grepl("^[A-Z]{2}_[0-9]+", accession)) return("RefSeq")

  if (is_unresolved_taxon_label(organism, "any")) return("Low / unresolved annotation")
  "Standard GenBank"
}

reference_quality_rank <- function(x) {
  map <- c(
    "Low / unresolved annotation" = 0,
    "Standard GenBank" = 1,
    "RefSeq" = 2,
    "Type material" = 3
  )
  out <- unname(map[as.character(x)])
  out[is.na(out)] <- 0
  out
}

best_reference_quality <- function(x) {
  if (!length(x)) return("Unavailable")
  r <- reference_quality_rank(x)
  if (!length(r) || all(!is.finite(r))) return("Unavailable")
  as.character(x[which.max(r)][1])
}

# ---------------------------------------------------------------------------
# Attach NCBI taxonomy + reference annotation
# ---------------------------------------------------------------------------

enrich_hits_with_taxonomy <- function(hits) {
  if (is.null(hits) || !nrow(hits)) return(hits)

  hits <- resolve_missing_taxids_rentrez(hits)
  ids <- unique(as.character(hits$taxid[!is.na(suppressWarnings(as.numeric(hits$taxid)))]))
  ids <- ids[nzchar(ids)]

  empty_cols <- c("kingdom", "phylum", "class", "order", "family", "genus", "species")
  for (nm in empty_cols) if (!nm %in% names(hits)) hits[[nm]] <- ""

  if (length(ids)) {
    classes <- tryCatch(
      taxize::classification(ids, db = "ncbi"),
      error = function(e) {
        x <- list()
        attr(x, "taxonomy_error") <- conditionMessage(e)
        x
      }
    )

    for (i in seq_len(nrow(hits))) {
      tx <- suppressWarnings(as.integer(hits$taxid[i]))
      if (is.na(tx)) next
      idx_id <- match(as.character(tx), ids)
      cl <- classification_for_taxid(classes, tx, fallback_index = idx_id)
      if (is.null(cl) || !is.data.frame(cl)) next

      hits$kingdom[i] <- rank_value(cl, c("kingdom", "superkingdom"))
      hits$phylum[i]  <- rank_value(cl, "phylum")
      hits$class[i]   <- rank_value(cl, "class")
      hits$order[i]   <- rank_value(cl, "order")
      hits$family[i]  <- rank_value(cl, "family")
      hits$genus[i]   <- rank_value(cl, "genus")
      hits$species[i] <- rank_value(cl, "species")
    }
  } else {
    classes <- list()
  }

  # Taxonomy services can occasionally fail while BLAST already supplied a
  # usable scientific name. Recover genus/species conservatively from the
  # NCBI organism label so a transient lineage lookup does not erase evidence.
  if ("organism" %in% names(hits)) {
    org <- clean_taxon_text(hits$organism)
    for (i in seq_len(nrow(hits))) {
      if (!nzchar(hits$genus[i]) && !is_unresolved_taxon_label(org[i], "any")) {
        tok <- strsplit(org[i], "\\s+")[[1]]
        if (length(tok)) hits$genus[i] <- tok[1]
      }
      if (!nzchar(hits$species[i]) && !is_unresolved_taxon_label(org[i], "species")) {
        tok <- strsplit(org[i], "\\s+")[[1]]
        if (length(tok) >= 2) hits$species[i] <- paste(tok[1:2], collapse = " ")
      }
    }
  }

  if (!"record_title" %in% names(hits)) hits$record_title <- ""
  if (!"accession" %in% names(hits)) hits$accession <- ""
  if (!"organism" %in% names(hits)) hits$organism <- ""
  hits$reference_quality <- mapply(
    reference_quality_label,
    hits$accession,
    hits$record_title,
    hits$organism,
    USE.NAMES = FALSE
  )

  attr(hits, "classification_list") <- classes
  attr(hits, "classification_ids") <- ids
  attr(hits, "taxonomy_error") <- attr(classes, "taxonomy_error")
  hits
}

# ---------------------------------------------------------------------------
# Locus context
# ---------------------------------------------------------------------------

locus_interpretation_note <- function(target) {
  target <- toupper(clean_taxon_text(target))
  if (grepl("^ITS$", target)) {
    return("ITS species-level resolution is taxon-dependent. Review difficult species complexes with an additional locus and/or curated type/reference evidence; methodological details are in Help / About.")
  }
  if (grepl("LSU", target)) {
    return("LSU can provide strong higher-level placement, but species-level resolution varies among groups. See Help / About for interpretation details.")
  }
  if (grepl("TEF1|EF1|RPB2|BETA|TUBULIN|CYP51|SDHB", target)) {
    return("Species-level discriminatory power for this locus is clade-dependent. See Help / About for interpretation details.")
  }
  "Species-level resolution depends on locus, clade and reference-database quality. See Help / About for interpretation details."
}

locus_benchmark <- function(target) {
  target_up <- toupper(clean_taxon_text(target))
  if (identical(target_up, "ITS")) {
    return(list(
      name = "ITS fungal broad benchmark",
      species_identity = 99.6,
      genus_identity = 94.3,
      source = "Vu et al. (2018), broad filamentous-fungi benchmark",
      universal = FALSE
    ))
  }
  list(
    name = "No universal identity cutoff applied",
    species_identity = NA_real_,
    genus_identity = NA_real_,
    source = "Score separation + taxonomic agreement + sequence/reference evidence",
    universal = FALSE
  )
}

# ---------------------------------------------------------------------------
# Score-aware helper functions
# ---------------------------------------------------------------------------

resolved_taxon_values <- function(x, rank = c("genus", "species")) {
  rank <- match.arg(rank)
  x <- clean_taxon_text(x)
  x[is_unresolved_taxon_label(x, rank)] <- ""
  x
}

mode_resolved <- function(vals) {
  vals <- clean_taxon_text(vals)
  vals <- vals[nzchar(vals)]
  if (!length(vals)) return(list(name = "", count = 0L, agreement = NA_real_, n_resolved = 0L))
  tt <- sort(table(vals), decreasing = TRUE)
  list(
    name = names(tt)[1],
    count = as.integer(tt[1]),
    agreement = as.numeric(tt[1]) / length(vals),
    n_resolved = length(vals)
  )
}

order_hits_by_score <- function(hits) {
  bits <- as_num_safe(hits$bit_score)
  ev <- as_num_safe(hits$evalue)
  id <- as_num_safe(hits$identity_percent)
  cov <- as_num_safe(hits$query_coverage_percent)
  ord <- order(-bits, ev, -cov, -id, na.last = TRUE)
  hits[ord, , drop = FALSE]
}

# The primary score cluster is deliberately transparent and adaptive.
# 1) Sort unique accession-level hits by bit score.
# 2) Consider score gaps after at least 3 hits while the hit above the gap is
#    still >=70% of the best bit score (to ignore dramatic gaps deep in a weak
#    tail).
# 3) Choose the LARGEST such gap. If it is >= max(20 bits, 3% of the best bit
#    score), the hits above that gap form the primary score cluster.
# 4) If no qualifying cliff is found, retain hits with >=90% of the best score.
# This is an application heuristic, not a published taxonomic threshold.
derive_primary_score_cluster <- function(hits) {
  if (is.null(hits) || !nrow(hits)) return(list(hits = hits, cutoff_rank = 0L, method = "none", gap = NA_real_, threshold = NA_real_))
  h <- order_hits_by_score(hits)
  bits <- as_num_safe(h$bit_score)
  finite_idx <- which(is.finite(bits))
  if (!length(finite_idx)) {
    n <- min(5L, nrow(h))
    return(list(hits = h[seq_len(n), , drop = FALSE], cutoff_rank = n, method = "top-five fallback", gap = NA_real_, threshold = NA_real_))
  }

  best_bit <- bits[finite_idx[1]]
  threshold <- max(20, 0.03 * best_bit)
  cutoff <- NA_integer_
  cliff_gap <- NA_real_

  candidate_i <- integer()
  candidate_gap <- numeric()
  if (length(finite_idx) >= 4) {
    for (k in 3:(length(finite_idx) - 1L)) {
      i <- finite_idx[k]
      j <- finite_idx[k + 1L]
      a <- bits[i]
      b <- bits[j]
      if (is.finite(a) && is.finite(b) && a >= 0.70 * best_bit) {
        candidate_i <- c(candidate_i, i)
        candidate_gap <- c(candidate_gap, a - b)
      }
    }
  }

  if (length(candidate_gap)) {
    m <- which.max(candidate_gap)
    if (candidate_gap[m] >= threshold) {
      cutoff <- candidate_i[m]
      cliff_gap <- candidate_gap[m]
    }
  }

  if (!is.na(cutoff)) {
    method <- "largest leading bit-score cliff"
  } else {
    keep <- which(is.finite(bits) & bits >= 0.90 * best_bit)
    cutoff <- if (length(keep)) max(keep) else min(5L, nrow(h))
    cutoff <- max(1L, min(cutoff, nrow(h)))
    method <- ">=90% of best bit score (no qualifying cliff)"
  }

  list(
    hits = h[seq_len(cutoff), , drop = FALSE],
    cutoff_rank = cutoff,
    method = method,
    gap = cliff_gap,
    threshold = threshold
  )
}

best_hit_for_taxon <- function(hits, tax_col, taxon) {
  if (is.null(hits) || !nrow(hits) || !tax_col %in% names(hits) || !nzchar(clean_taxon_text(taxon))) return(NULL)
  vals <- resolved_taxon_values(hits[[tax_col]], if (tax_col == "species") "species" else "genus")
  g <- hits[vals == taxon, , drop = FALSE]
  if (!nrow(g)) return(NULL)
  order_hits_by_score(g)[1, , drop = FALSE]
}

best_competitor_for_taxon <- function(hits, tax_col, candidate) {
  if (is.null(hits) || !nrow(hits) || !tax_col %in% names(hits) || !nzchar(clean_taxon_text(candidate))) return(NULL)
  vals <- resolved_taxon_values(hits[[tax_col]], if (tax_col == "species") "species" else "genus")
  g <- hits[nzchar(vals) & vals != candidate, , drop = FALSE]
  if (!nrow(g)) return(NULL)
  order_hits_by_score(g)[1, , drop = FALSE]
}

separation_metrics <- function(candidate_hit, competitor_hit) {
  if (is.null(candidate_hit) || !nrow(candidate_hit)) {
    return(list(delta_bit = NA_real_, relative_percent = NA_real_, strength = "Unavailable", competitor = ""))
  }
  cb <- as_num_safe(candidate_hit$bit_score[1])
  if (is.null(competitor_hit) || !nrow(competitor_hit)) {
    return(list(delta_bit = NA_real_, relative_percent = NA_real_, strength = "No resolved competitor", competitor = ""))
  }
  bb <- as_num_safe(competitor_hit$bit_score[1])
  delta <- if (is.finite(cb) && is.finite(bb)) cb - bb else NA_real_
  rel <- if (is.finite(delta) && is.finite(cb) && cb > 0) 100 * delta / cb else NA_real_

  strength <- "Weak"
  if (is.finite(rel) && (rel >= 5 || (is.finite(delta) && delta >= 50))) {
    strength <- "Strong"
  } else if (is.finite(rel) && (rel >= 2 || (is.finite(delta) && delta >= 20))) {
    strength <- "Moderate"
  }

  comp_name <- ""
  if ("species" %in% names(competitor_hit) && nzchar(clean_taxon_text(competitor_hit$species[1]))) comp_name <- clean_taxon_text(competitor_hit$species[1])
  if (!nzchar(comp_name) && "genus" %in% names(competitor_hit)) comp_name <- clean_taxon_text(competitor_hit$genus[1])
  if (!nzchar(comp_name) && "organism" %in% names(competitor_hit)) comp_name <- clean_taxon_text(competitor_hit$organism[1])

  list(delta_bit = delta, relative_percent = rel, strength = strength, competitor = comp_name)
}

sequence_evidence_from_hit <- function(hit, target = "", rank = c("species", "genus")) {
  rank <- match.arg(rank)
  if (is.null(hit) || !nrow(hit)) return(list(level = "Unavailable", identity = NA_real_, coverage = NA_real_, benchmark = ""))
  identity <- as_num_safe(hit$identity_percent[1])
  coverage <- as_num_safe(hit$query_coverage_percent[1])
  bm <- locus_benchmark(target)

  level <- "Low"
  if (is.finite(identity) && is.finite(coverage)) {
    if (rank == "species" && is.finite(bm$species_identity)) {
      if (identity >= bm$species_identity && coverage >= 90) level <- "High"
      else if (identity >= max(bm$genus_identity, 97) && coverage >= 80) level <- "Moderate"
    } else if (rank == "genus" && is.finite(bm$genus_identity)) {
      if (identity >= bm$genus_identity && coverage >= 90) level <- "High"
      else if (identity >= bm$genus_identity && coverage >= 70) level <- "Moderate"
    } else {
      if (identity >= 99 && coverage >= 90) level <- "High"
      else if (identity >= 95 && coverage >= 80) level <- "Moderate"
    }
  }

  list(level = level, identity = identity, coverage = coverage, benchmark = bm$name)
}

support_label <- function(agreement, n_resolved, separation_strength = "") {
  if (!is.finite(agreement) || n_resolved < 1) return("Insufficient")
  if (agreement >= 0.95 && separation_strength %in% c("Strong", "No resolved competitor")) return("Very high")
  if (agreement >= 0.90) return("High")
  if (agreement >= 0.80) return("Moderate")
  "Low / review"
}

confidence_for_rank <- function(tax_support, seq_evidence, separation_strength, ref_quality) {
  if (tax_support == "Insufficient") return("Insufficient")
  ref_ok <- reference_quality_rank(ref_quality) >= 1
  sep_strong <- separation_strength %in% c("Strong", "No resolved competitor")
  sep_ok <- separation_strength %in% c("Strong", "Moderate", "No resolved competitor")

  if (tax_support %in% c("Very high", "High") && seq_evidence == "High" && sep_strong && ref_ok) return("High")
  if (tax_support %in% c("Very high", "High", "Moderate") && seq_evidence %in% c("High", "Moderate") && sep_ok && ref_ok) return("Moderate")
  "Low / review"
}

# ---------------------------------------------------------------------------
# Multi-hit score-aware consensus
# ---------------------------------------------------------------------------

build_taxonomic_consensus <- function(enriched_hits, target = "", top_n = 25L) {
  if (is.null(enriched_hits) || !nrow(enriched_hits)) {
    return(list(summary = data.frame(), hits = data.frame(), counts = data.frame(), lca = data.frame(), score_cluster = data.frame()))
  }

  hits <- order_hits_by_score(enriched_hits)
  top_n <- max(1L, min(as.integer(top_n), nrow(hits)))
  hits <- hits[seq_len(top_n), , drop = FALSE]
  hits$analysis_rank <- seq_len(nrow(hits))

  if (!"reference_quality" %in% names(hits)) {
    if (!"record_title" %in% names(hits)) hits$record_title <- ""
    hits$reference_quality <- mapply(reference_quality_label, hits$accession, hits$record_title, hits$organism, USE.NAMES = FALSE)
  }

  bits <- as_num_safe(hits$bit_score)
  best_bit <- if (any(is.finite(bits))) max(bits, na.rm = TRUE) else NA_real_
  hits$delta_bit_from_best <- if (is.finite(best_bit)) round(best_bit - bits, 3) else NA_real_
  hits$relative_bit_score_percent <- if (is.finite(best_bit) && best_bit > 0) round(100 * bits / best_bit, 2) else NA_real_

  cluster_info <- derive_primary_score_cluster(hits)
  cluster <- cluster_info$hits
  hits$primary_score_cluster <- seq_len(nrow(hits)) <= nrow(cluster)

  genus_all_vals <- resolved_taxon_values(hits$genus, "genus")
  species_all_vals <- resolved_taxon_values(hits$species, "species")
  genus_cluster_vals <- resolved_taxon_values(cluster$genus, "genus")
  species_cluster_vals <- resolved_taxon_values(cluster$species, "species")

  genus_all <- mode_resolved(genus_all_vals)
  species_all <- mode_resolved(species_all_vals)
  genus_cluster <- mode_resolved(genus_cluster_vals)
  species_cluster <- mode_resolved(species_cluster_vals)

  # Candidate is the best-scoring resolved hit at each rank. Agreement is then
  # measured independently so a database-abundant taxon cannot replace the
  # strongest match merely by having more low-scoring records.
  first_resolved_name <- function(vals) {
    idx <- which(nzchar(vals))
    if (length(idx)) vals[idx[1]] else ""
  }
  candidate_genus <- first_resolved_name(genus_all_vals)
  candidate_species <- first_resolved_name(species_all_vals)

  genus_candidate_hit <- best_hit_for_taxon(hits, "genus", candidate_genus)
  species_candidate_hit <- best_hit_for_taxon(hits, "species", candidate_species)
  genus_competitor_hit <- best_competitor_for_taxon(hits, "genus", candidate_genus)
  species_competitor_hit <- best_competitor_for_taxon(hits, "species", candidate_species)

  genus_sep <- separation_metrics(genus_candidate_hit, genus_competitor_hit)
  species_sep <- separation_metrics(species_candidate_hit, species_competitor_hit)

  cluster_agreement_for <- function(vals, candidate) {
    resolved <- vals[nzchar(vals)]
    if (!length(resolved) || !nzchar(candidate)) return(list(count=0L, n=length(resolved), agreement=NA_real_))
    count <- sum(resolved == candidate)
    list(count=count, n=length(resolved), agreement=count/length(resolved))
  }
  genus_cluster_candidate <- cluster_agreement_for(genus_cluster_vals, candidate_genus)
  species_cluster_candidate <- cluster_agreement_for(species_cluster_vals, candidate_species)
  genus_all_candidate <- cluster_agreement_for(genus_all_vals, candidate_genus)
  species_all_candidate <- cluster_agreement_for(species_all_vals, candidate_species)

  genus_ref <- if (!is.null(genus_candidate_hit)) {
    candidate_rows <- hits[genus_all_vals == candidate_genus, , drop=FALSE]
    best_reference_quality(candidate_rows$reference_quality)
  } else "Unavailable"
  species_ref <- if (!is.null(species_candidate_hit)) {
    candidate_rows <- hits[species_all_vals == candidate_species, , drop=FALSE]
    best_reference_quality(candidate_rows$reference_quality)
  } else "Unavailable"

  genus_seq <- sequence_evidence_from_hit(genus_candidate_hit, target, "genus")
  species_seq <- sequence_evidence_from_hit(species_candidate_hit, target, "species")

  genus_support <- support_label(genus_cluster_candidate$agreement, genus_cluster_candidate$n, genus_sep$strength)
  species_support <- support_label(species_cluster_candidate$agreement, species_cluster_candidate$n, species_sep$strength)
  genus_conf <- confidence_for_rank(genus_support, genus_seq$level, genus_sep$strength, genus_ref)
  species_conf <- confidence_for_rank(species_support, species_seq$level, species_sep$strength, species_ref)

  bm <- locus_benchmark(target)
  target_up <- toupper(clean_taxon_text(target))

  # Rank recommendation and sequence quality are intentionally separated.
  # Taxonomic agreement + competitor separation determine whether a rank is
  # supported. Identity/coverage benchmarks influence confidence and whether a
  # species consensus is reported as the primary identification, but they do
  # not erase a strong genus consensus. This avoids the previous failure mode
  # where a unanimous score cluster could still become Unresolved solely
  # because an ITS identity benchmark was missed by a small margin.
  species_consensus <- nzchar(candidate_species) &&
    species_cluster_candidate$n >= 2 &&
    is.finite(species_cluster_candidate$agreement) && species_cluster_candidate$agreement >= 0.80 &&
    species_sep$strength %in% c("Strong", "Moderate", "No resolved competitor")

  genus_consensus <- nzchar(candidate_genus) &&
    genus_cluster_candidate$n >= 2 &&
    is.finite(genus_cluster_candidate$agreement) && genus_cluster_candidate$agreement >= 0.80 &&
    genus_sep$strength %in% c("Strong", "Moderate", "No resolved competitor")

  # Species is promoted only when sequence evidence is High. A strong species
  # consensus with Moderate/Low/Unavailable sequence evidence is retained as a
  # species candidate for review, while the primary recommendation falls back
  # to genus when genus consensus is available. This preserves the agreed
  # distinction between taxonomic agreement and sequence-level evidence.
  species_promotable <- species_consensus && identical(species_seq$level, "High")

  recommendation <- "Unresolved"
  rec_rank <- "unresolved"
  confidence <- "Insufficient"
  taxonomic_support <- "Insufficient"
  sequence_evidence <- "Unavailable"
  selected_sep <- list(delta_bit=NA_real_, relative_percent=NA_real_, strength="Unavailable", competitor="")
  selected_ref <- "Unavailable"

  if (species_promotable) {
    recommendation <- candidate_species
    rec_rank <- "species candidate"
    confidence <- species_conf
    taxonomic_support <- species_support
    sequence_evidence <- species_seq$level
    selected_sep <- species_sep
    selected_ref <- species_ref
  } else if (genus_consensus) {
    recommendation <- candidate_genus
    rec_rank <- "genus"
    confidence <- genus_conf
    taxonomic_support <- genus_support
    sequence_evidence <- genus_seq$level
    selected_sep <- genus_sep
    selected_ref <- genus_ref
  } else if (species_consensus) {
    # Rare fallback when species taxonomy resolved but genus lineage lookup did
    # not. Keep the candidate visible rather than discarding the evidence.
    recommendation <- candidate_species
    rec_rank <- "species candidate · review"
    confidence <- "Low / review"
    taxonomic_support <- species_support
    sequence_evidence <- species_seq$level
    selected_sep <- species_sep
    selected_ref <- species_ref
  }

  # LCA remains contextual only. It is not allowed to erase a clear rank-level
  # recommendation, and a failed LCA lookup does not imply unresolved evidence.
  classes <- attr(enriched_hits, "classification_list")
  ids <- unique(as.character(hits$taxid[!is.na(suppressWarnings(as.numeric(hits$taxid)))]))
  ids <- ids[nzchar(ids)]
  lca_df <- data.frame(name = "", rank = "", id = "", stringsAsFactors = FALSE)
  if (length(ids) >= 2 && !is.null(classes) && length(classes)) {
    class_subset <- lapply(seq_along(ids), function(i) {
      classification_for_taxid(classes, ids[i], fallback_index = match(ids[i], attr(enriched_hits, "classification_ids")))
    })
    names(class_subset) <- ids
    class(class_subset) <- class(classes)
    lca_try <- tryCatch(taxize::lowest_common(ids, class_list = class_subset), error = function(e) NULL)
    if (!is.null(lca_try) && is.data.frame(lca_try) && nrow(lca_try)) {
      lca_df <- data.frame(
        name = as.character(lca_try$name[1]),
        rank = as.character(lca_try$rank[1]),
        id = if ("id" %in% names(lca_try)) as.character(lca_try$id[1]) else "",
        stringsAsFactors = FALSE
      )
    }
  }

  if (identical(rec_rank, "unresolved") && nzchar(lca_df$name[1])) {
    recommendation <- lca_df$name[1]
    rec_rank <- paste0("LCA: ", lca_df$rank[1])
    confidence <- "Low / review"
    taxonomic_support <- "Low / review"
  }

  species_candidate_display <- if (nzchar(candidate_species)) candidate_species else ""
  species_candidate_confidence <- if (nzchar(candidate_species)) {
    if (species_consensus && species_seq$level == "Low") "Low / review"
    else if (species_consensus && species_seq$level == "Unavailable") "Insufficient sequence evidence"
    else species_conf
  } else "Insufficient"

  fmt_sep <- function(x) {
    if (identical(x$strength, "No resolved competitor")) return("no resolved competitor in evaluated hits")
    if (is.finite(x$delta_bit)) return(paste0("ΔBit=", round(x$delta_bit,1), " (", round(x$relative_percent,1), "%) vs ", ifelse(nzchar(x$competitor), x$competitor, "competitor")))
    "separation unavailable"
  }

  decision_reason <- if (rec_rank == "species candidate") {
    paste0(
      "Primary score cluster: ", species_cluster_candidate$count, "/", species_cluster_candidate$n,
      " species-resolved hits support ", candidate_species, " (", round(100*species_cluster_candidate$agreement,1), "%). ",
      "Best competing species: ", ifelse(nzchar(species_sep$competitor), species_sep$competitor, "no alternative resolved species found"), "; ", fmt_sep(species_sep), ". ",
      "Candidate hit identity/coverage: ", round(species_seq$identity,2), "% / ", round(species_seq$coverage,1), "%. ",
      "Reference support: ", species_ref, "."
    )
  } else if (rec_rank == "genus") {
    species_note <- if (nzchar(candidate_species)) paste0(" Species candidate retained for review: ", candidate_species, " (", species_conf, ").") else ""
    paste0(
      "Primary score cluster: ", genus_cluster_candidate$count, "/", genus_cluster_candidate$n,
      " genus-resolved hits support ", candidate_genus, " (", round(100*genus_cluster_candidate$agreement,1), "%). ",
      "Best competing genus: ", ifelse(nzchar(genus_sep$competitor), genus_sep$competitor, "no alternative resolved genus found"), "; ", fmt_sep(genus_sep), ". ",
      "Candidate hit identity/coverage: ", round(genus_seq$identity,2), "% / ", round(genus_seq$coverage,1), "%. ",
      "Reference support: ", genus_ref, ".", species_note
    )
  } else if (grepl("^LCA:", rec_rank)) {
    paste0("No stable genus/species recommendation was supported by the competitive-hit pattern. Lowest common taxon: ", recommendation, ".")
  } else {
    "No stable genus/species recommendation was supported by the competitive-hit pattern. Review the score cluster, best competitors, sequence coverage and reference quality."
  }

  # Agreement table focuses on the primary competitive score cluster. The full
  # set of retrieved accession-level hits remains available in the enriched-hit
  # table and score landscape, but weak tail hits are not presented as an equal
  # voting pool.
  count_rows <- list()
  add_counts <- function(vals, scope, level, denominator_total) {
    resolved <- vals[nzchar(vals)]
    if (!length(resolved)) return(NULL)
    tt <- sort(table(resolved), decreasing = TRUE)
    data.frame(
      scope = scope,
      level = level,
      taxon = names(tt),
      hit_count = as.integer(tt),
      resolved_hits = length(resolved),
      agreement_percent = round(100 * as.integer(tt) / length(resolved), 1),
      share_of_scope_percent = round(100 * as.integer(tt) / denominator_total, 1),
      stringsAsFactors = FALSE
    )
  }
  count_rows[[1]] <- add_counts(genus_cluster_vals, "Primary score cluster", "genus", nrow(cluster))
  count_rows[[2]] <- add_counts(species_cluster_vals, "Primary score cluster", "species", nrow(cluster))
  count_rows <- Filter(Negate(is.null), count_rows)
  counts <- if (length(count_rows)) do.call(rbind, count_rows) else data.frame(
    scope=character(), level=character(), taxon=character(), hit_count=integer(), resolved_hits=integer(),
    agreement_percent=numeric(), share_of_scope_percent=numeric(), stringsAsFactors=FALSE
  )
  rownames(counts) <- NULL

  top_identity <- if (!is.null(species_candidate_hit) && nrow(species_candidate_hit)) as_num_safe(species_candidate_hit$identity_percent[1]) else if (!is.null(genus_candidate_hit) && nrow(genus_candidate_hit)) as_num_safe(genus_candidate_hit$identity_percent[1]) else NA_real_
  top_coverage <- if (!is.null(species_candidate_hit) && nrow(species_candidate_hit)) as_num_safe(species_candidate_hit$query_coverage_percent[1]) else if (!is.null(genus_candidate_hit) && nrow(genus_candidate_hit)) as_num_safe(genus_candidate_hit$query_coverage_percent[1]) else NA_real_

  summary <- data.frame(
    algorithm_version = "score-aware-v2.10.2",
    recommended_identification = recommendation,
    recommended_level = rec_rank,
    confidence = confidence,
    taxonomic_support = taxonomic_support,
    sequence_evidence = sequence_evidence,
    reference_support = selected_ref,
    decision_reason = decision_reason,
    hits_used = nrow(hits),
    primary_score_cluster_hits = nrow(cluster),
    score_cluster_method = cluster_info$method,
    score_cliff_gap = ifelse(is.finite(cluster_info$gap), round(cluster_info$gap, 2), NA_real_),
    score_cliff_threshold = ifelse(is.finite(cluster_info$threshold), round(cluster_info$threshold, 2), NA_real_),
    candidate_genus = candidate_genus,
    genus_cluster_agreement_percent = ifelse(is.finite(genus_cluster_candidate$agreement), round(100*genus_cluster_candidate$agreement,1), NA_real_),
    genus_reference_support = genus_ref,
    genus_best_competitor = genus_sep$competitor,
    genus_delta_bit = ifelse(is.finite(genus_sep$delta_bit), round(genus_sep$delta_bit,2), NA_real_),
    genus_delta_bit_percent = ifelse(is.finite(genus_sep$relative_percent), round(genus_sep$relative_percent,2), NA_real_),
    genus_separation = genus_sep$strength,
    species_candidate = species_candidate_display,
    species_candidate_confidence = species_candidate_confidence,
    species_cluster_agreement_percent = ifelse(is.finite(species_cluster_candidate$agreement), round(100*species_cluster_candidate$agreement,1), NA_real_),
    species_reference_support = species_ref,
    species_best_competitor = species_sep$competitor,
    species_delta_bit = ifelse(is.finite(species_sep$delta_bit), round(species_sep$delta_bit,2), NA_real_),
    species_delta_bit_percent = ifelse(is.finite(species_sep$relative_percent), round(species_sep$relative_percent,2), NA_real_),
    species_separation = species_sep$strength,
    candidate_identity_percent = ifelse(is.finite(top_identity), round(top_identity,3), NA_real_),
    candidate_query_coverage_percent = ifelse(is.finite(top_coverage), round(top_coverage,2), NA_real_),
    its_species_identity_benchmark = ifelse(is.finite(bm$species_identity), bm$species_identity, NA_real_),
    its_genus_identity_benchmark = ifelse(is.finite(bm$genus_identity), bm$genus_identity, NA_real_),
    benchmark_note = paste0(bm$name, "; ", bm$source, "; not a universal hard cutoff"),
    genus_resolved_hits = genus_all$n_resolved,
    species_resolved_hits = species_all$n_resolved,
    lowest_common_taxon = lca_df$name[1],
    lowest_common_rank = lca_df$rank[1],
    locus_note = locus_interpretation_note(target),
    stringsAsFactors = FALSE
  )

  list(summary = summary, hits = hits, counts = counts, lca = lca_df, score_cluster = cluster)
}

# ---------------------------------------------------------------------------
# Export taxonomic checkpoint
# ---------------------------------------------------------------------------

make_taxonomy_checkpoint_zip <- function(file, tax_summary, tax_hits, tax_counts, blast_hits = NULL) {
  temp_dir <- tempfile("sanger_taxonomy_")
  dir.create(temp_dir, recursive = TRUE)
  on.exit(unlink(temp_dir, recursive = TRUE, force = TRUE), add = TRUE)

  write.csv(tax_summary, file.path(temp_dir, "taxonomic_summary.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(tax_hits, file.path(temp_dir, "taxonomic_hits_enriched.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  write.csv(tax_counts, file.path(temp_dir, "taxonomic_agreement_counts.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  if (!is.null(blast_hits) && nrow(blast_hits)) {
    write.csv(blast_hits, file.path(temp_dir, "BLAST_hits_source.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  }

  app_version <- tryCatch(get("APP_VERSION", inherits = TRUE), error = function(e) "unknown")
  note <- c(
    paste0("Application version: ", app_version),
    paste0("Exported at: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
    "v2.10.2 uses score-aware accession-level BLAST evidence.",
    "Primary score cluster: largest leading bit-score cliff after >=3 hits while the pre-gap hit is >=70% of best; cliff must be >= max(20 bits, 3% of best); fallback >=90% of best bit score.",
    "Best competing species/genus and Delta-Bit are evaluated separately from weak tail hits.",
    "Reference quality (type-material wording / RefSeq / standard GenBank / unresolved annotation) is reported explicitly.",
    "For ITS, 99.6% species and 94.3% genus identity values are broad literature benchmarks, not universal hard cutoffs.",
    "Hit frequencies are not independent biological replicates and can reflect database sampling bias.",
    "Species-level resolution is locus- and clade-dependent; review the decision explanation and locus note."
  )
  writeLines(note, file.path(temp_dir, "README_taxonomic_interpretation.txt"))

  files <- list.files(temp_dir, recursive = TRUE, full.names = TRUE)
  zip::zipr(file, files, root = temp_dir)
}
