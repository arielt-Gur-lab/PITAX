# v2.11.1

- Fixed taxonomic recommendation gating: a weak Delta-Bit to one resolved competitor now lowers confidence but no longer erases an >=80% primary-cluster genus/species consensus.
- Species promotion still requires High sequence evidence plus non-weak species separation; otherwise the species remains a review candidate and the result falls back to genus when supported.
- Candidate sequence/reference evidence remains visible even when no rank is recommended, avoiding misleading `Unavailable` labels caused only by decision branching.
- Added regression coverage for a 24/25 Pleurotus primary cluster with a near-tied Lentinus competitor.
- Relaxed the manual-curation smoke test from an exact proposal-count assertion to testing the scientifically relevant expected proposal; failures now print the detected flag table for diagnosis.

# v2.11.0
- Added an auditable **manual sequence curation layer** on top of the original AB1/base calls and automatic trim.
- Right-clicking an Ambiguous peak flag now opens curation actions: manual base change, IUPAC two-base ambiguity code, trim from the left/right through the flagged position, or keep/mark reviewed.
- All sequence-changing actions require a confirmation step showing the chromatogram evidence and the resulting trim/sequence effect.
- Added conservative **Auto-correct high-confidence** preview. A proposal is made only when the alternative channel is locally dominant, alternative/current signal ≥1.80, alternative/third-channel signal ≥2.00, the alternative peak is within ±2 trace samples of the called position, and the alternative signal is ≥50% of the retained-region median. Nothing is changed until the preview is confirmed.
- Bulk auto-corrections are applied as one undoable transaction while retaining one audit row per corrected position.
- Added per-sample **Undo**, **Redo**, **History**, and **Reset to auto** controls. Undo/redo operations are also recorded in the audit trail.
- Manual curation logs sample, raw base position, before/after value, method, evidence, timestamp, transaction ID and revision. The log is included in checkpoint/final ZIPs and the team Excel workbook.
- Previous BLAST/taxonomic results are invalidated when the curated sequence changes. Old RIDs are marked `STALE` and cannot be retrieved into the active result set; the current sequence must be resubmitted.
- Ambiguous-peak review now distinguishes Active versus Reviewed flags; reviewed positions can be shown on demand.
- Expanded QC flag evidence with competitor peak offset and ratios used by the high-confidence proposal rule.
- Reworked the QC layout so the flag table uses the full panel width. Long explanatory paragraphs were removed from the working view and replaced with compact hover tooltips; the detailed method remains in Help / About.
- Updated Help / About with the complete manual-curation, provenance, high-confidence correction and BLAST-invalidation logic.
- Added `tests/manual_curation_smoke.R`; `run_tests.bat` now runs taxonomy, peak-flag and curation/undo-redo regression checks.

# v2.10.4
- Added **Ambiguous peak / channel competition review** to the QC & Chromatogram stage.
- Flags Strong/Moderate channel competition, called-base-not-dominant positions, and N base calls using a narrow local trace window.
- Added a small review table with position, called base, strongest competing channel, called/competitor signal, peak ratio, competitor percentage, severity and flag reason.
- Clicking a flagged table row centers the interactive chromatogram around that base for human inspection.
- Added optional flag markers directly on the Plotly chromatogram.
- Default flag scope is the retained/trimmed sequence, with an option to inspect the full raw read.
- Added QC flag counts to the team summary and a dedicated **QC Flags** worksheet in the Excel report.
- Added `*_QC_ambiguous_peak_flags.csv` to processing/final checkpoint ZIP exports.
- Documented the flagging logic and heuristic thresholds in Help / About.

# v2.10.3
- Fixed Shiny startup failure in Help/About: `class` was passed into `tabsetPanel()` as if it were a tab, which Shiny rejects. Styling now targets the tabset ID.
- Restored the intended species-promotion policy: Moderate species sequence evidence keeps the species as a candidate while a supported genus remains the primary recommendation; automatic species promotion requires High sequence evidence.
- Clarified the wording used when no alternative resolved species/genus competitor exists.
- Updated taxonomy smoke-test version labels.

# Sanger Sequence Pipeline — Version History

## v2.10.2 — Taxonomic fallback and analysis-view cleanup
- Fixed a decision bug where a strong, unanimous primary score cluster could still become `Unresolved` because an ITS identity benchmark was treated as a hard eligibility gate.
- Taxonomic consensus and sequence evidence are now separated: Identity/Coverage affect confidence and species promotion, but do not erase a stable genus consensus.
- A strong species consensus with weak sequence evidence now falls back to the supported genus while retaining the species as a review candidate.
- Removed Top-N voting rows/columns and the separate taxonomy Top-N control. Taxonomic analysis now uses all unique accession-level hits retrieved in the BLAST stage; the BLAST-stage maximum-hit setting remains the retrieval limit.
- Removed Decision explanation from the Taxonomic interpretation table; the explanation remains directly below the table.
- Shortened locus notes in the analysis page; benchmark details remain in Help / About.
- Simplified the BLAST score landscape toolbar by removing Lasso, box-select, and compare-hover controls.
- Added an explanatory paragraph describing how to read the BLAST score landscape and interpret plateaus versus score cliffs.

## v2.10.1 — About/Methods readability and test-path patch
- Reorganized **Help / About** into separate tabs: Overview, Trimming & QC, NCBI BLAST, Taxonomic algorithm, Scientific references, and Version history.
- Added a stepwise, spaced presentation of the v2.10 taxonomic algorithm and explicit labels separating published biological context from application heuristics.
- Added clickable external links to the main scientific/NCBI references used by the application, plus UNITE as a documented future curated-reference direction.
- Clarified that Vu et al. ITS identity values are broad literature benchmarks rather than universal hard cutoffs, and added Garnica et al. as evidence for lineage-dependent thresholds.
- Fixed `tests/taxonomy_logic_smoke.R` so it resolves `R/taxonomy_tools.R` relative to the test file rather than the current working directory.

## v2.10.0 — Score-aware taxonomic identification
- Replaced flat Top-N voting with a transparent **score-aware primary BLAST cluster**.
- Added direct comparison to the best different species and best different genus using **ΔBit** and relative ΔBit.
- Added conservative rank fallback: weak species evidence can fall back to a supported genus instead of becoming `Unresolved`.
- For ITS, the broad 99.6% species / 94.3% genus identity benchmarks reported by Vu et al. are used as context, not universal hard cutoffs.
- Added explicit **reference-quality context**: type-material wording, RefSeq, standard GenBank, and unresolved/environmental annotation.
- Added a BLAST score-landscape graph showing the primary score cluster versus the weaker tail.
- Added candidate species, best taxonomic competitors, score separation, candidate Identity/Coverage and reference support to the taxonomic summary and team export.
- Improved accession-level BLAST parsing: subject Bit score comes from the strongest HSP, while representative Identity comes from the broadest HSP; query coverage remains the union of HSP query intervals.
- Expanded Help / About with the complete decision algorithm, heuristic thresholds, limitations, and scientific basis.
- Save/Load remains compatible with v2.9 project files; newly analyzed samples use the v2.10 interpretation schema.

## v2.9.0 — Save / Load projects and accession-level BLAST evidence
- Added **Save project** and **Load project** using a portable `.sangerproject` file.
- Project files preserve processed chromatograms/traces, trimming/QC state, rename mapping, BLAST jobs/RIDs, retrieved BLAST results, and taxonomic analyses.
- Loading restores the last workflow stage and key UI selections without re-running completed trimming or BLAST steps.
- Added a project schema/version marker for forward compatibility checks.
- Reworked the BLAST fallback parser so multiple **HSPs (High-scoring Segment Pairs)** belonging to one accession are aggregated into one database hit.
- Added normalization of stored BLAST data to one row per RID/accession before taxonomy/confidence calculations.
- Query coverage for headerless CSV fallback results is now calculated from the union of HSP query intervals for the accession.
- Sequence evidence now uses the near-tied competitive unique-hit set (or the top five unique hits as fallback), rather than the weak tail of all requested Top-N rows.
- Updated Help / About documentation for project files, HSP aggregation, and sequence-evidence calculation.

## v2.8.0 — Reporting, documentation and batch taxonomy
- Added a dedicated **Help / About** page explaining the workflow, trimming/QC terminology, NCBI BLAST metrics and taxonomic interpretation.
- Added a visible application version read from `VERSION.txt`.
- Added this `CHANGELOG.md` version-history file and exposed it inside the Help / About page.
- Added **Analyze ALL retrieved sequences** in the Taxonomic summary stage.
- Added a consolidated **Team identification summary** with one row per processed sequence.
- Added team-summary export as both CSV and formatted Excel (`.xlsx`).
- Excel export includes separate sheets for Summary, BLAST Hits, Taxonomy Details, QC, Rename Map and Run Settings.
- Added run provenance to exports: application version, export time, target/locus and trimming/run settings.
- Preserved QC evidence in checkpoint/final ZIP exports.

## v2.7.0 — Taxonomic consensus correction
- Separated taxonomic consensus from sequence-evidence quality.
- Strong genus/species agreement is no longer erased by missing or weaker identity/coverage metrics.
- Species-unresolved records such as `sp.`, uncultured or unclassified taxa are not treated as conflicting named species.
- Added explicit taxonomic support, sequence evidence and a decision explanation.

## v2.6.0 — Batch BLAST
- Added batch submission of all processed sequences to NCBI BLAST.
- Added batch retrieval while preserving a one-to-one Sample → RID → Hit set relationship.
- Increased default BLAST/taxonomic interpretation depth to 25 hits, with support for up to 100.
- Preliminary BLAST overview now includes all retrieved sequences.

## v2.5.0 — Multi-hit taxonomic interpretation
- Added NCBI taxonomy lineage resolution with `rentrez` and `taxize`.
- Added multi-hit genus/species agreement and lowest-common-taxon context.
- Added locus-aware interpretation notes.

## v2.4.0 — BLAST metadata and workflow navigation
- Improved BLAST hit metadata enrichment from NCBI records.
- Improved hit-table readability and raw-response disclosure.
- Moved workflow actions to the top of each stage and added a workflow-position diagram.

## v2.3.0 — Interactive chromatogram and BLAST parsing
- Moved chromatogram inspection toward an interactive browser plot.
- Restored QC plots and retained them in exports.
- Improved BLAST result parsing and storage of multiple hits.

## v2.2.0 — QC/navigation refinements
- Reworked chromatogram navigation and reduced emphasis on experimental primer-site mapping.
- Improved NCBI result metadata display.

## v2.1.0 — Primer-aware QC experiment
- Added chromatogram inspection, sequence preview and experimental primer-site mapping.

## v2.0.0 — Modular application
- Split the Shiny application into modular R source files.
- Added staged workflow: Upload → Settings → QC → Rename → Export → NCBI BLAST.

## v1.x — Initial Shiny workflow
- Initial AB1 trimming pipeline wrapped in a Shiny interface.
- Added configurable trimming settings, optional rename mapping and FASTA/CSV export.
