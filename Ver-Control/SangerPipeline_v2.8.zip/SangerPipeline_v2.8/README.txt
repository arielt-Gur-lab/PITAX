Sanger Sequence Pipeline v2.8.0
===============================

Purpose
-------
Local Shiny application for Sanger AB1 processing and sequence identification:

AB1 upload -> Assay & trimming -> QC -> Rename -> Export -> NCBI BLAST -> Taxonomic summary

Key v2.8 additions
------------------
- Help / About page with workflow and terminology explanations.
- VERSION.txt + CHANGELOG.md version tracking.
- Analyze ALL retrieved BLAST sequences in the taxonomic stage.
- Team identification summary: one row per sequence combining QC, identification and confidence.
- Team summary export as CSV and Excel (.xlsx).
- Excel workbook sheets: Summary, BLAST Hits, Taxonomy Details, QC, Rename Map, Run Settings.
- Run provenance (application version, export time and settings) included in exports.

Run
---
Double-click run_app.bat, or from R:

  shiny::runApp('.', launch.browser = TRUE)

First run
---------
Missing R packages are installed automatically. v2.8 additionally uses `openxlsx` to create team-facing Excel reports.

Scientific interpretation
-------------------------
BLAST similarity and agreement among database hits support an identification hypothesis. They are not by themselves formal taxonomic validation. Species-level resolution depends on the target locus, taxonomic group and reference-database representation.

Roadmap
-------
v2.9: Save / Load complete analysis sessions.
v3.0: planned major workflow expansion; see project discussion/roadmap.
