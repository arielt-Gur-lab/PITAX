# Sanger Sequence Pipeline — Version History

## v2.8.0 — Reporting, documentation and batch taxonomy
- Added a dedicated **Help / About** page explaining the workflow, trimming/QC terminology, NCBI BLAST metrics and taxonomic interpretation.
- Added a visible application version read from `VERSION.txt`.
- Added this `CHANGELOG.md` version-history file and exposed it inside the Help / About page.
- Added **Analyze ALL retrieved sequences** in the Taxonomic summary stage.
- Added a consolidated **Team identification summary** with one row per processed sequence.
- Added team-summary export as both CSV and formatted Excel (`.xlsx`).
- Excel export includes separate sheets for Summary, BLAST Hits, Taxonomy Details, QC, Rename Map and Run Settings.
- Added run provenance to exports: application version, export time, target/locus and trimming/run settings.
- Preserved QC evidence in checkpoint/final ZIP exports.

## v2.7.0 — Taxonomic consensus correction
- Separated taxonomic consensus from sequence-evidence quality.
- Strong genus/species agreement is no longer erased by missing or weaker identity/coverage metrics.
- Species-unresolved records such as `sp.`, uncultured or unclassified taxa are not treated as conflicting named species.
- Added explicit taxonomic support, sequence evidence and a decision explanation.

## v2.6.0 — Batch BLAST
- Added batch submission of all processed sequences to NCBI BLAST.
- Added batch retrieval while preserving a one-to-one Sample → RID → Hit set relationship.
- Increased default BLAST/taxonomic interpretation depth to 25 hits, with support for up to 100.
- Preliminary BLAST overview now includes all retrieved sequences.

## v2.5.0 — Multi-hit taxonomic interpretation
- Added NCBI taxonomy lineage resolution with `rentrez` and `taxize`.
- Added multi-hit genus/species agreement and lowest-common-taxon context.
- Added locus-aware interpretation notes.

## v2.4.0 — BLAST metadata and workflow navigation
- Improved BLAST hit metadata enrichment from NCBI records.
- Improved hit-table readability and raw-response disclosure.
- Moved workflow actions to the top of each stage and added a workflow-position diagram.

## v2.3.0 — Interactive chromatogram and BLAST parsing
- Moved chromatogram inspection toward an interactive browser plot.
- Restored QC plots and retained them in exports.
- Improved BLAST result parsing and storage of multiple hits.

## v2.2.0 — QC/navigation refinements
- Reworked chromatogram navigation and reduced emphasis on experimental primer-site mapping.
- Improved NCBI result metadata display.

## v2.1.0 — Primer-aware QC experiment
- Added chromatogram inspection, sequence preview and experimental primer-site mapping.

## v2.0.0 — Modular application
- Split the Shiny application into modular R source files.
- Added staged workflow: Upload → Settings → QC → Rename → Export → NCBI BLAST.

## v1.x — Initial Shiny workflow
- Initial AB1 trimming pipeline wrapped in a Shiny interface.
- Added configurable trimming settings, optional rename mapping and FASTA/CSV export.
