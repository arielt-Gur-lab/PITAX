# ============================================================
# Sanger Sequence Pipeline v2.11.0
# Modular Shiny application
# ============================================================

required_cran <- c("shiny", "DT", "zip", "readxl", "httr2", "plotly", "xml2", "rentrez", "taxize", "openxlsx")
for (pkg in required_cran) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
}
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("sangerseqR", quietly = TRUE)) BiocManager::install("sangerseqR")

library(shiny)
library(DT)
library(sangerseqR)
options(shiny.maxRequestSize = 500 * 1024^2)

source(file.path("R", "core_sanger.R"), local = TRUE)
source(file.path("R", "sequence_tools.R"), local = TRUE)
source(file.path("R", "export_tools.R"), local = TRUE)
source(file.path("R", "taxonomy_tools.R"), local = TRUE)

APP_VERSION <- tryCatch(trimws(readLines("VERSION.txt", warn = FALSE)[1]), error = function(e) "2.11.0")
APP_VERSION <- ifelse(is.na(APP_VERSION) || !nzchar(APP_VERSION), "2.11.0", APP_VERSION)
PROJECT_SCHEMA_VERSION <- 1L

# ============================================================
# UI helpers
# ============================================================

panel_box <- function(...) div(class = "panel-box", ...)
section_title <- function(x) div(class = "section-title", x)
info_tip <- function(text) tags$span(class = "info-tip", title = text, "ⓘ")

rbind_fill <- function(a, b) {
  if (is.null(a) || !is.data.frame(a) || !nrow(a)) return(b)
  if (is.null(b) || !is.data.frame(b) || !nrow(b)) return(a)
  cols <- union(names(a), names(b))
  for (nm in setdiff(cols, names(a))) a[[nm]] <- NA
  for (nm in setdiff(cols, names(b))) b[[nm]] <- NA
  a <- a[, cols, drop = FALSE]
  b <- b[, cols, drop = FALSE]
  rbind(a, b)
}

stage_topbar <- function(...) {
  div(class = "stage-topbar", ...)
}

pipeline_stage_footer <- function(current_step) {
  labels <- c(
    "Upload",
    "Assay & Trim",
    "QC",
    "Rename",
    "Export",
    "NCBI BLAST",
    "Taxonomic summary"
  )

  pieces <- list()
  for (i in seq_along(labels)) {
    state <- if (i < current_step) "done" else if (i == current_step) "current" else "future"
    pieces[[length(pieces) + 1]] <- div(
      class = paste("schema-stage", state),
      div(class = "schema-dot"),
      div(class = "schema-label", paste0(i, ". ", labels[[i]]))
    )
    if (i < length(labels)) {
      pieces[[length(pieces) + 1]] <- div(
        class = paste("schema-line", if (i < current_step) "done" else "")
      )
    }
  }

  div(
    class = "pipeline-schema-wrap",
    div(class = "pipeline-schema-title", "Workflow position"),
    div(class = "pipeline-schema", pieces)
  )
}

ui <- fluidPage(
  tags$head(
    tags$script(HTML("
      Shiny.addCustomMessageHandler('openUrl', function(message) {
        window.open(message.url, '_blank');
      });
      Shiny.addCustomMessageHandler('copyText', function(message) {
        navigator.clipboard.writeText(message.text);
      });

    ")),
    tags$style(HTML("
      body { background:#f5f7fa; }
      .pipeline-container { max-width:1450px; margin:auto; }
      .app-header { background:white; padding:22px 28px; margin:20px 0 18px; border-radius:12px; border:1px solid #e5e7eb; }
      .app-header h2 { margin:0 0 5px; }
      .app-header p { margin:0; color:#6b7280; }
      .panel-box { background:white; padding:22px; border-radius:12px; border:1px solid #e5e7eb; margin-bottom:18px; }
      .section-title { font-size:20px; font-weight:600; margin-bottom:16px; }
      .summary-card { background:#f8fafc; border:1px solid #e5e7eb; border-radius:10px; padding:15px; margin-bottom:10px; }
      .summary-number { font-size:26px; font-weight:700; }
      .summary-label { color:#6b7280; }
      .settings-note { color:#6b7280; font-size:13px; }
      .status-ok { color:#15803d; font-weight:600; }
      .status-warning { color:#b45309; font-weight:600; }
      .status-error { color:#b91c1c; font-weight:600; }
      .blast-action-row { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:10px; }
      .checkpoint { background:#fffaf0; border:1px solid #f3d7a0; }
      .mono { font-family:Consolas,Monaco,monospace; white-space:pre-wrap; word-break:break-all; background:#f8fafc; padding:12px; border-radius:8px; border:1px solid #e5e7eb; }
      table.dataTable td input { color:#111827 !important; background:#fff !important; }
      table.dataTable td input:focus { color:#111827 !important; background:#fff !important; }
      textarea.form-control { font-family:Consolas,Monaco,monospace; }
      .btn { border-radius:7px; margin-right:6px; margin-bottom:6px; }
      .experimental-box { background:#fffdf5; border:1px solid #f1dfae; border-radius:8px; padding:10px 12px; margin-top:8px; }
      .stage-topbar { background:#ffffff; border:1px solid #dbe3ee; border-radius:10px; padding:12px 14px; margin:0 0 16px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
      .stage-topbar .btn { margin-bottom:0; }
      .pipeline-schema-wrap { margin:30px 4px 12px; padding:8px 4px 4px; }
      .pipeline-schema-title { font-size:11px; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:.05em; margin-bottom:14px; }
      .pipeline-schema { display:flex; align-items:flex-start; width:100%; overflow-x:auto; padding:2px 2px 8px; }
      .schema-stage { min-width:92px; max-width:128px; display:flex; flex-direction:column; align-items:center; text-align:center; flex:0 0 auto; }
      .schema-dot { width:13px; height:13px; border-radius:50%; background:#cbd5e1; border:2px solid #f5f7fa; box-shadow:0 0 0 1px #cbd5e1; margin-top:0; }
      .schema-label { margin-top:8px; font-size:11px; line-height:1.25; color:#94a3b8; font-weight:500; }
      .schema-line { flex:1 1 42px; min-width:28px; height:2px; background:#cbd5e1; margin-top:6px; }
      .schema-stage.done .schema-dot { background:#65a30d; box-shadow:0 0 0 1px #65a30d; }
      .schema-stage.done .schema-label { color:#64748b; }
      .schema-line.done { background:#84cc16; }
      .schema-stage.current .schema-dot { width:17px; height:17px; margin-top:-2px; background:#2563eb; box-shadow:0 0 0 3px rgba(37,99,235,.14); border-color:#ffffff; }
      .schema-stage.current .schema-label { color:#1e3a8a; font-weight:700; }
      .taxonomy-hero { background:#f8fafc; border-left:4px solid #2563eb; padding:16px 18px; margin-bottom:16px; }
      .taxonomy-id { font-size:28px; font-weight:700; line-height:1.15; }
      .taxonomy-sub { color:#64748b; margin-top:4px; }
      .confidence-high { color:#15803d; font-weight:700; }
      .confidence-moderate { color:#a16207; font-weight:700; }
      .confidence-low { color:#b91c1c; font-weight:700; }
      .tax-note { background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; color:#475569; }
      table.dataTable td.dt-taxon { min-width:150px; max-width:230px; white-space:normal; line-height:1.25; vertical-align:top; font-style:italic; }
      .raw-response-details { margin-top:14px; }
      .raw-response-details summary { display:inline-block; cursor:pointer; user-select:none; padding:8px 12px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:7px; color:#334155; font-weight:600; }
      .raw-response-details summary:hover { background:#eef2f7; }
      .raw-response-details[open] summary { margin-bottom:10px; background:#eaf2f8; border-color:#9dbbd3; }
      table.dataTable td.dt-organism { min-width:170px; max-width:260px; white-space:nowrap; line-height:1.25; vertical-align:top; font-style:italic; }
      table.dataTable td.dt-hit-title { min-width:300px; max-width:520px; white-space:normal; line-height:1.25; vertical-align:top; }
      table.dataTable td.dt-nowrap { white-space:nowrap; vertical-align:top; }
      .help-card { background:#ffffff; border:1px solid #e2e8f0; border-radius:10px; padding:20px 22px; margin-bottom:18px; line-height:1.55; }
      .help-card h3 { margin-top:0; margin-bottom:14px; font-size:19px; }
      .help-card p { margin-bottom:10px; }
      .help-flow { font-family:Consolas,Monaco,monospace; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px; white-space:pre-wrap; line-height:1.7; }
      #about_tabs { margin-bottom:20px; border-bottom:1px solid #cbd5e1; }
      #about_tabs > li > a { padding:10px 16px; font-weight:600; color:#475569; }
      #about_tabs > li.active > a { color:#0f172a; background:#f8fafc; border-bottom-color:#f8fafc; }
      .about-section { max-width:1080px; margin:0 auto; padding:4px 2px 12px 2px; }
      .about-lead { font-size:15px; color:#475569; line-height:1.65; margin-bottom:16px; }
      .method-step { display:grid; grid-template-columns:46px 1fr; gap:14px; padding:16px 0; border-bottom:1px solid #e2e8f0; }
      .method-step:last-child { border-bottom:none; }
      .method-num { width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; background:#e2e8f0; color:#0f172a; font-weight:700; }
      .method-step h4 { margin:0 0 6px 0; font-size:16px; }
      .method-step p { margin:0; color:#475569; line-height:1.55; }
      .evidence-badge { display:inline-block; padding:3px 8px; border-radius:999px; font-size:11px; font-weight:700; margin-left:6px; vertical-align:1px; }
      .evidence-published { background:#dcfce7; color:#166534; }
      .evidence-heuristic { background:#fef3c7; color:#92400e; }
      .reference-card { background:#ffffff; border:1px solid #e2e8f0; border-left:4px solid #94a3b8; border-radius:8px; padding:15px 17px; margin-bottom:12px; }
      .landscape-explainer { background:#f8fafc; border-left:4px solid #64748b; border-radius:6px; padding:10px 14px; margin:4px 0 12px 0; color:#475569; line-height:1.5; }
      .landscape-explainer p { margin:0; }
      .reference-card h4 { margin:0 0 7px 0; font-size:15px; }
      .reference-card p { margin:0 0 8px 0; color:#475569; line-height:1.5; }
      .reference-card a { font-weight:600; }
      .about-callout { background:#f8fafc; border:1px solid #cbd5e1; border-radius:9px; padding:14px 16px; margin:14px 0; line-height:1.55; }
      .team-summary-note { background:#eef7ff; border:1px solid #bfdbfe; border-radius:8px; padding:12px 14px; color:#334155; }
      .peak-flag-summary { display:flex; gap:10px; flex-wrap:wrap; margin:8px 0 12px 0; }
      .peak-flag-pill { border:1px solid #dbe3ec; border-radius:999px; padding:5px 10px; background:#f8fafc; font-size:12px; color:#334155; }
      .peak-flag-pill strong { color:#111827; }
      .peak-flag-help { background:#fffaf0; border:1px solid #fed7aa; border-radius:8px; padding:10px 12px; color:#7c2d12; font-size:12px; }
      .info-tip { display:inline-flex; align-items:center; justify-content:center; width:18px; height:18px; margin-left:6px; border:1px solid #94a3b8; border-radius:50%; color:#64748b; font-size:11px; font-weight:700; cursor:help; vertical-align:1px; }
      .curation-toolbar { display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap; margin:2px 0 8px; }
      .curation-toolbar .form-group { margin-bottom:0; }
      .curation-toolbar .shiny-input-radiogroup { min-width:250px; }
      .curation-actions { display:flex; gap:7px; flex-wrap:wrap; align-items:center; }
      .curation-history-note { color:#64748b; font-size:12px; margin-top:6px; }
      .manual-edit-badge { display:inline-block; padding:3px 8px; border-radius:999px; background:#eef2ff; color:#4338ca; font-size:11px; font-weight:700; }
      .status-note { background:#f8fafc; border-left:3px solid #94a3b8; padding:8px 10px; margin:8px 0; color:#475569; font-size:12px; }
      .project-bar { background:#ffffff; border:1px solid #dbe3ee; border-radius:10px; padding:12px 14px; margin:-2px 0 18px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
      .project-bar-title { font-weight:700; color:#334155; margin-right:4px; }
      .project-bar .form-group { margin-bottom:0; }
      .project-bar .shiny-input-container { width:300px; max-width:100%; }
      .project-status { color:#64748b; font-size:12px; flex:1 1 260px; }
    "))
  ),

  div(class = "pipeline-container",
    div(class = "app-header",
      h2(paste0("Sanger Sequence Pipeline v", APP_VERSION)),
      p("AB1 processing → QC & chromatogram → rename → export → NCBI BLAST → taxonomic interpretation")
    ),

    div(class = "project-bar",
      div(class = "project-bar-title", "Project"),
      downloadButton("save_project", "Save project"),
      fileInput("load_project", NULL, multiple = FALSE, accept = c(".sangerproject", ".rds"),
                buttonLabel = "Load project", placeholder = "No project selected"),
      div(class = "project-status", uiOutput("project_status"))
    ),

    tabsetPanel(id = "pipeline_step", type = "tabs",

      # --------------------------------------------------------
      # 1. Upload
      # --------------------------------------------------------
      tabPanel("1 · Upload", value = "upload",
        stage_topbar(
          actionButton("to_settings", "Continue to Settings →", class = "btn-primary")
        ),
        panel_box(
          section_title("Upload raw Sanger sequences"),
          fileInput("ab1_files", "Select AB1 files", multiple = TRUE,
                    accept = c(".ab1", ".AB1"), buttonLabel = "Select files"),
          p(class = "settings-note", "Multiple AB1 chromatogram files can be selected or dragged here."),
          DTOutput("uploaded_files_table")
        ),
        pipeline_stage_footer(1)
      ),

      # --------------------------------------------------------
      # 2. Assay & trimming settings
      # --------------------------------------------------------
      tabPanel("2 · Assay & Trim", value = "settings",
        stage_topbar(
          actionButton("back_upload", "← Back"),
          actionButton("run_trimming", "Run trimming →", class = "btn-primary")
        ),
        fluidRow(
          column(6,
            panel_box(
              section_title("Assay information"),
              selectInput("target", "Target / Gene",
                          c("ITS", "LSU", "TEF1 / EF1-alpha", "RPB2", "Beta-tubulin", "CYP51", "SDHB", "IGS", "Other"),
                          selected = "ITS"),
              textInput("forward_primer", "Forward primer name", ""),
              textInput("forward_primer_seq", "Forward primer sequence (5'→3')", ""),
              textInput("reverse_primer", "Reverse primer name", ""),
              textInput("reverse_primer_seq", "Reverse primer sequence (5'→3')", ""),
              radioButtons(
                "sequencing_primer", "Primer used for this Sanger read",
                choices = c("Forward" = "Forward", "Reverse" = "Reverse", "Unknown / infer" = "Unknown"),
                selected = "Forward", inline = TRUE
              ),
              checkboxInput("enable_primer_mapping", "Enable experimental primer-site mapping in QC", value = FALSE),
              div(class = "experimental-box",
                p(class = "settings-note", style="margin:0;",
                  "Experimental: Sanger base-calling often begins after the sequencing primer and the noisy read start can make primer-site inference unreliable. Keep this off unless primer-site inspection is specifically useful for the run.")),
              numericInput("expected_amplicon_len", "Expected amplicon length (bp)", 650, min = 1),
              numericInput("absolute_max_base_index", "Maximum sequence position (bp)", 680, min = 50)
            )
          ),
          column(6,
            panel_box(
              section_title("Advanced trimming settings"),
              numericInput("window", "Window size", 25, min = 5),
              numericInput("min_peak_ratio", "Minimum peak ratio", 3, min = 0, step = 0.1),
              numericInput("min_relative_signal", "Minimum relative signal", 0.20, min = 0, max = 1, step = 0.01),
              numericInput("min_len_before_collapse", "Minimum length before collapse search", 350, min = 1),
              numericInput("bad_run_windows", "Consecutive bad windows", 12, min = 1),
              numericInput("min_usable_len", "Minimum usable trimmed length", 400, min = 1)
            )
          )
        ),
        pipeline_stage_footer(2)
      ),

      # --------------------------------------------------------
      # 3. QC, chromatogram & sequence preview
      # --------------------------------------------------------
      tabPanel("3 · QC & Chromatogram", value = "qc",
        stage_topbar(
          actionButton("back_settings", "← Back to Settings"),
          actionButton("to_rename", "Continue to Rename →", class = "btn-primary")
        ),
        uiOutput("qc_summary_cards"),
        panel_box(
          section_title("Trimming results"),
          DTOutput("summary_table")
        ),
        fluidRow(
          column(4,
            panel_box(
              section_title(tagList("Sequence inspection", info_tip("Inspect the selected read, its current curated sequence and QC metrics. The chromatogram supports mouse-wheel zoom, pan and a horizontal range slider."))),
              selectInput("inspect_sample", "Sample", choices = NULL),
              DTOutput("sequence_metrics"),
              conditionalPanel(
                condition = "input.enable_primer_mapping === true",
                br(), h5("Experimental primer-site mapping"),
                DTOutput("primer_match_table")
              )
            )
          ),
          column(8,
            panel_box(
              section_title("Read / trim / primer overview"),
              plotOutput("amplicon_overview", height = "190px"),
              uiOutput("expected_amplicon_note")
            ),
            panel_box(
              section_title(tagList("Interactive chromatogram", info_tip("X axis = raw called-base position. Use the range slider, mouse-wheel zoom and pan. Flag markers are navigation/review cues; manual edits never change the original AB1 trace."))),
              plotly::plotlyOutput("chromatogram_plot", height = "540px")
            )
          )
        ),
        panel_box(
          section_title(tagList("Ambiguous peak review", info_tip("Flags mark positions where dye channels compete or the current call is not locally dominant. Left-click centers the chromatogram. Right-click opens manual curation actions. All sequence changes require confirmation, remain reversible, and are written to the curation audit log."))),
          div(class = "curation-toolbar",
            radioButtons(
              "peak_flag_scope", "Positions",
              choices = c("Trimmed sequence" = "trimmed", "Entire raw read" = "raw"),
              selected = "trimmed", inline = TRUE
            ),
            checkboxInput("show_peak_flags", "Show markers", value = TRUE),
            checkboxInput("show_reviewed_flags", "Show reviewed", value = FALSE),
            div(class = "curation-actions",
              actionButton("auto_correct_preview", "Auto-correct high-confidence", icon = icon("magic"), title = "Preview only positions that meet all very-high-confidence channel/peak criteria. No base is changed before confirmation."),
              actionButton("curation_undo", "Undo", icon = icon("undo"), title = "Undo the most recent curation transaction for this sample."),
              actionButton("curation_redo", "Redo", icon = icon("repeat"), title = "Redo the most recently undone curation transaction."),
              actionButton("curation_history", "History", icon = icon("history"), title = "Open the full per-sample manual curation audit log."),
              actionButton("curation_reset", "Reset to auto", icon = icon("refresh"), title = "Restore automatic trim/base calls as the active curated sequence. The reset is logged and undoable.")
            )
          ),
          uiOutput("ambiguous_peak_summary"),
          DTOutput("ambiguous_peak_table")
        ),
        panel_box(
          section_title(tagList("QC metrics", info_tip("Original trimming QC plots: called-base signal and called-peak / second-peak ratio. These plots are also exported as PNG evidence."))),
          plotOutput("qc_plot", height = "650px")
        ),
        conditionalPanel(
          condition = "input.enable_primer_mapping === true",
          panel_box(
            section_title("Experimental primer alignment"),
            verbatimTextOutput("primer_alignment")
          )
        ),
        panel_box(
          section_title(tagList("Curated sequence preview", info_tip("This is the sequence that will be exported and submitted to BLAST. It starts from the automatic trim and includes any confirmed manual curation edits."))),
          textAreaInput("trimmed_sequence_preview", NULL, value = "", rows = 8, width = "100%")
        ),
        div(class = "panel-box checkpoint",
          section_title(tagList("Checkpoint A · Processed sequences", info_tip("Save an auditable checkpoint after QC/curation and before renaming."))),
          downloadButton("download_trim_checkpoint", "Download Trim checkpoint ZIP")
        ),
        pipeline_stage_footer(3)
      ),

      # --------------------------------------------------------
      # 4. Rename
      # --------------------------------------------------------
      tabPanel("4 · Rename", value = "rename",
        stage_topbar(
          actionButton("back_qc", "← Back to QC"),
          actionButton("to_export", "Continue to Export →", class = "btn-primary")
        ),
        panel_box(
          section_title("Rename key"),
          p("Edit New_name manually or import a key."),
          fluidRow(
            column(6, fileInput("rename_key_file", "Upload rename key", multiple = FALSE, accept = c(".xlsx", ".csv"))),
            column(6, br(), actionButton("apply_rename_key", "Apply rename key", class = "btn-primary"))
          ),
          p(class = "settings-note", "Required columns: old_id and new_id. Prefix matching is supported, e.g. 265DMAA000 matches 265DMAA000_customer."),
          uiOutput("rename_key_status")
        ),
        panel_box(
          section_title("Batch rename tools"),
          fluidRow(
            column(3, textInput("rename_remove_suffix", "Remove suffix", "_customer")),
            column(3, textInput("rename_prefix", "Add prefix", "")),
            column(3, textInput("rename_suffix", "Add suffix", "")),
            column(3, actionButton("apply_batch_affixes", "Apply suffix/prefix tools", class = "btn-primary"))
          ),
          fluidRow(
            column(4, textInput("rename_find", "Find text", "")),
            column(4, textInput("rename_replace", "Replace with", "")),
            column(4, br(), actionButton("apply_find_replace", "Find & Replace"))
          ),
          actionButton("reset_names", "Reset names to original")
        ),
        panel_box(
          section_title("Sequence names"),
          DTOutput("rename_table"), br(),
          uiOutput("rename_validation")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint B · Renamed sequences"),
          p("Save an anchor after sample names have been resolved."),
          downloadButton("download_rename_checkpoint", "Download Rename checkpoint ZIP")
        ),
        pipeline_stage_footer(4)
      ),

      # --------------------------------------------------------
      # 5. Export
      # --------------------------------------------------------
      tabPanel("5 · Export", value = "export",
        stage_topbar(
          actionButton("back_rename", "← Back to Rename"),
          actionButton("to_blast", "Continue to NCBI BLAST →", class = "btn-primary")
        ),
        panel_box(section_title("Run summary"), uiOutput("export_summary")),
        panel_box(
          section_title("Final data exports"),
          downloadButton("download_blast_fasta", "BLAST FASTA"),
          downloadButton("download_full_fasta", "FASTA + metadata"),
          downloadButton("download_summary_csv", "Summary CSV"),
          downloadButton("download_all_zip", "Final results ZIP")
        ),
        pipeline_stage_footer(5)
      ),

      # --------------------------------------------------------
      # 6. NCBI BLAST
      # --------------------------------------------------------
      tabPanel("6 · NCBI BLAST", value = "blast",
        stage_topbar(
          actionButton("back_export", "← Back to Export"),
          actionButton("to_taxonomy", "Continue to Taxonomic summary →", class = "btn-primary"),
          actionButton("reset_pipeline", "Start new run")
        ),
        panel_box(
          section_title("BLAST query workspace"),
          p("This stage uses the final processed and renamed sequence. The current version can submit a selected sequence to the official NCBI BLAST URL API and retrieve the result when it is ready."),
          fluidRow(
            column(4,
              selectInput("blast_sample", "Sequence", choices = NULL),
              selectInput("blast_database", "NCBI database", choices = c("core_nt", "nt"), selected = "core_nt"),
              numericInput("blast_hitlist", "Maximum hits per sequence", 25, min = 1, max = 100),
              p(class = "settings-note", "25 hits is the default for interpretation; increase up to 100 when you want a broader competitive-hit set."),
              actionButton("copy_blast_sequence", "Copy processed sequence"),
              actionButton("open_ncbi_blast", "Open NCBI Nucleotide BLAST"),
              downloadButton("download_selected_blast", "Download selected FASTA")
            ),
            column(8,
              h5("Processed query sequence"),
              textAreaInput("blast_sequence_preview", NULL, value = "", rows = 9, width = "100%")
            )
          )
        ),
        panel_box(
          section_title("NCBI automated submission"),
          div(class = "blast-action-row",
            actionButton("submit_ncbi_blast", "Submit selected sequence", class = "btn-primary"),
            actionButton("submit_all_ncbi_blast", "Submit ALL processed sequences", class = "btn-success"),
            actionButton("retrieve_ncbi_blast", "Check selected result"),
            actionButton("retrieve_all_ncbi_blast", "Check / retrieve ALL submitted")
          ),
          p(class = "settings-note",
            "Batch mode keeps one RID per sequence so each sample remains traceable through BLAST and taxonomy. The app spaces automated NCBI contacts by at least 10 seconds and does not poll the same RID more often than once per minute."),
          uiOutput("blast_batch_status"),
          uiOutput("blast_job_status"),
          DTOutput("blast_jobs_table")
        ),
        panel_box(
          section_title("Preliminary identification overview · top hit per sequence"),
          p(class = "settings-note",
            "One row is shown for every sequence whose BLAST result has been retrieved. This is only the top-hit overview; the multi-hit evidence used for taxonomic confidence is retained below and interpreted in the next stage."),
          DTOutput("blast_identification_table")
        ),
        panel_box(
          section_title("Retrieved BLAST hits"),
          p(class = "settings-note",
            "All returned hits for the selected RID are retained here so the next stage can compare agreement between hits and estimate genus/species-level confidence."),
          DTOutput("blast_hits_table"),
          tags$details(
            class = "raw-response-details",
            tags$summary("Show raw NCBI response ▾"),
            verbatimTextOutput("blast_raw_preview")
          )
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint C · Identification workspace"),
          downloadButton("download_blast_jobs", "Download BLAST job/results CSV"),
          downloadButton("download_blast_hits", "Download all BLAST hits CSV")
        ),
        pipeline_stage_footer(6)
      ),

      # --------------------------------------------------------
      # 7. Taxonomic interpretation
      # --------------------------------------------------------
      tabPanel("7 · Taxonomic summary", value = "taxonomy",
        stage_topbar(
          actionButton("back_blast", "← Back to NCBI BLAST"),
          actionButton("run_taxonomy", "Analyze selected sequence", class = "btn-primary"),
          actionButton("run_taxonomy_all", "Analyze ALL retrieved sequences", class = "btn-success"),
          actionButton("reset_pipeline_tax", "Start new run")
        ),
        panel_box(
          section_title("Taxonomic consensus workspace"),
          fluidRow(
            column(5,
              selectInput("tax_sample", "Sequence with retrieved BLAST hits", choices = NULL),
              p(class = "settings-note",
                "Only sequences with retrieved BLAST hits appear here. The analysis uses all unique accession-level hits retrieved in the NCBI BLAST stage, identifies the competitive high-scoring cluster, compares the best competing species/genus by Bit score, and evaluates sequence and reference evidence separately.")
            ),
            column(7,
              uiOutput("taxonomy_status")
            )
          )
        ),
        uiOutput("taxonomy_hero"),
        uiOutput("taxonomy_summary_cards"),
        fluidRow(
          column(6,
            panel_box(
              section_title("Taxonomic interpretation"),
              DTOutput("taxonomy_summary_table"),
              uiOutput("taxonomy_locus_note")
            )
          ),
          column(6,
            panel_box(
              section_title("Agreement among BLAST hits"),
              DTOutput("taxonomy_counts_table"),
              p(class = "settings-note",
                "Agreement is calculated inside the primary score cluster — the high-scoring set considered genuinely competitive. Weaker tail hits remain available below for inspection, while the best different species/genus is evaluated separately as the direct taxonomic competitor.")
            )
          )
        ),
        panel_box(
          section_title("BLAST score landscape"),
          div(class = "landscape-explainer",
            p(
              "Read the graph from left to right: each point is one unique NCBI accession ordered from the strongest to weaker BLAST matches. The Y-axis is Bit score, so a flat high-scoring plateau means several records provide very similar alignment support. A sharp drop indicates a natural separation between the competitive hit group and weaker database matches. Hover over a point to see its taxon, accession, Identity, Query coverage and reference category. Taxonomic agreement is calculated from the primary high-scoring cluster, while the weaker tail remains visible so you can judge whether the separation is convincing."
            )
          ),
          plotly::plotlyOutput("taxonomy_score_plot", height = "380px")
        ),
        panel_box(
          section_title("Taxonomy-enriched BLAST hits"),
          p(class = "settings-note",
            "NCBI taxonomy is attached to each usable BLAST hit. The table makes it possible to inspect whether competing hits differ at species, genus, or higher ranks."),
          DTOutput("taxonomy_hits_table")
        ),
        panel_box(
          section_title("Team identification summary"),
          div(class = "team-summary-note",
              "One row per processed sequence. This view combines QC, BLAST and taxonomic interpretation so it can be reviewed or shared with the team."),
          br(),
          DTOutput("team_summary_table"),
          br(),
          downloadButton("download_team_summary_csv", "Team summary CSV"),
          downloadButton("download_team_summary_xlsx", "Team summary Excel (.xlsx)")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint D · Taxonomic interpretation"),
          downloadButton("download_taxonomy_summary", "Download taxonomic summary CSV"),
          downloadButton("download_taxonomy_hits", "Download taxonomy-enriched hits CSV"),
          downloadButton("download_taxonomy_checkpoint", "Download Taxonomy checkpoint ZIP")
        ),
        pipeline_stage_footer(7)
      ),

      # --------------------------------------------------------
      # Help / About (documentation, not a pipeline stage)
      # --------------------------------------------------------
      tabPanel("Help / About", value = "help",
        panel_box(
          section_title(paste0("Sanger Sequence Pipeline v", APP_VERSION)),
          p(class="about-lead",
            "Documentation for the laboratory workflow, the BLAST/taxonomy interpretation logic, and the scientific sources used to guide the application. Published evidence and application-specific heuristics are labeled separately."),
          div(class="help-flow",
              "AB1 upload  →  Assay & trimming  →  QC  →  Rename  →  Export  →  NCBI BLAST  →  Taxonomic interpretation")
        ),

        div(class="about-section",
          tabsetPanel(
            id="about_tabs",
            type="tabs",

            tabPanel("Overview",
              div(class="help-card",
                h3("What the application does"),
                p("The application converts raw Sanger AB1 chromatograms into auditable processed sequences and then supports sequence-based identification using NCBI BLAST and multi-hit taxonomic interpretation."),
                div(class="about-callout",
                  strong("Core principle: "),
                  "the application separates what the database hits agree on from how strong the sequence evidence is. A weak species-level result can therefore fall back to a supported genus instead of becoming automatically Unresolved."
                )
              ),
              fluidRow(
                column(6,
                  div(class="help-card",
                    h3("Workflow"),
                    p(strong("1. Upload"), " — raw AB1 chromatograms."),
                    p(strong("2. Assay & Trim"), " — locus metadata and trimming parameters."),
                    p(strong("3. QC"), " — Quality Control plots, chromatogram inspection and processed sequence."),
                    p(strong("4. Rename"), " — manual or key-based sample naming."),
                    p(strong("5. Export"), " — processed FASTA, CSV/Excel summaries and checkpoints."),
                    p(strong("6. NCBI BLAST"), " — submit processed sequences and retrieve accession-level hits."),
                    p(strong("7. Taxonomic summary"), " — compare competitive hits and report identification plus confidence.")
                  )
                ),
                column(6,
                  div(class="help-card",
                    h3("Auditability"),
                    p("The QC plots, automatic trimming parameters, manual curation audit log, BLAST hits, taxonomy-enriched hits, decision components and application version are retained in exports."),
                    p(strong("Save / Load project"), " stores the workflow state in a .sangerproject file so completed processing and retrieved BLAST results do not need to be repeated."),
                    p("The final identification is decision-support. It does not replace locus-specific taxonomy, type/reference inspection, morphology or additional loci when those are required.")
                  )
                )
              )
            ),

            tabPanel("Trimming & QC",
              div(class="help-card",
                h3("Trimming terminology"),
                div(class="method-step",
                  div(class="method-num", "1"),
                  div(h4("Peak ratio"), p("Ratio between the signal of the called base and the second-highest channel at that base call. Larger values indicate a clearer dominant peak."))
                ),
                div(class="method-step",
                  div(class="method-num", "2"),
                  div(h4("Good start"), p("The first sustained window that satisfies the configured signal/peak-ratio rule. Bases before this point are excluded from the processed sequence."))
                ),
                div(class="method-step",
                  div(class="method-num", "3"),
                  div(h4("Collapse"), p("The first sustained region where relative signal or peak-ratio behavior indicates deterioration. The processed read is normally ended before this point."))
                ),
                div(class="method-step",
                  div(class="method-num", "4"),
                  div(h4("Minimum usable length"), p("A workflow threshold used to flag a processed sequence as SHORT_AFTER_TRIMMING rather than OK."))
                ),
                div(class="method-step",
                  div(class="method-num", "5"),
                  div(h4("Ambiguous peak review"),
                      p("The app flags individual called-base positions where another A/C/G/T dye channel competes strongly with the current call, where the current call is not locally dominant, or where the call is ambiguous."),
                      p("The comparison uses a narrow trace window around each called peak and suppresses weak-signal competition using a run-specific signal baseline. By default, a called/competitor peak ratio ≤1.25 is Strong and ≤1.75 is Moderate; the local signal must be at least 20% of the retained-region median called signal. These are application review heuristics, not biological diagnoses."),
                      p("Flags are review targets. Left-click centers the chromatogram; right-click opens manual curation actions. No sequence-changing action is applied without an explicit confirmation step."))
                ),
                div(class="method-step",
                  div(class="method-num", "6"),
                  div(h4("Manual curation and provenance"),
                      p("The raw AB1 trace and original automatic base calls are never overwritten. The app maintains a curated sequence layer on top of the automatic trim. A user can change a base, set a two-base IUPAC ambiguity code, trim from either side through a flagged position, or mark the call as reviewed and unchanged."),
                      p("Every confirmed action is written to the Manual Curation audit log with sample, raw base position, before/after values, method, chromatogram evidence, timestamp, transaction ID and revision. Undo and redo are logged as well. Automatic trim boundaries are retained separately so the curated result can always be compared with the automatic result."),
                      p("For a flagged position inside the retained read, the curation menu shows both left- and right-trim actions. A directional recommendation is displayed only when the flag is near a current trim edge: within 15% of the retained length, bounded to 8–40 bases. The recommendation never performs a trim by itself and still requires explicit confirmation."))
                ),
                div(class="method-step",
                  div(class="method-num", "7"),
                  div(h4("High-confidence bulk correction"),
                      p("The bulk correction tool is intentionally conservative and always shows a preview before applying changes. A position is proposed only when the current called base is not locally dominant, the alternative channel is the strongest local channel, alternative/current signal is at least 1.80, alternative/third-channel signal is at least 2.00, the alternative peak maximum lies within ±2 trace samples of the called-base peak position, and the alternative signal is at least 50% of the retained-region median called signal."),
                      p("All thresholds in this bulk correction rule are application heuristics designed to make automatic correction rare. The complete batch is applied as one undoable transaction after user confirmation. Ambiguous double peaks are not bulk-corrected merely because two channels are similar."))
                )
              ),
              div(class="help-card",
                h3("QC evidence"),
                p(strong("QC"), " means Quality Control. Called-base signal and peak-ratio plots are retained in checkpoint/final ZIP exports."),
                p("The ambiguous-peak table links directly to the interactive chromatogram. Right-clicking a row opens the curation actions, while the History view exposes the complete per-sample audit trail."),
                p("If a curated sequence is changed after BLAST has already been run, the previous BLAST/taxonomic result for that sample is marked stale and removed from active interpretation until BLAST is rerun on the new curated sequence.")
              )
            ),

            tabPanel("NCBI BLAST",
              div(class="help-card",
                h3("How BLAST evidence is represented"),
                div(class="method-step",
                  div(class="method-num", "1"),
                  div(h4("RID — Request ID"), p("Identifier returned by NCBI for an individual BLAST job. The app keeps Sample ↔ RID ↔ retrieved hits linked."))
                ),
                div(class="method-step",
                  div(class="method-num", "2"),
                  div(h4("Identity"), p("Percentage of identical positions in the representative alignment for the accession."))
                ),
                div(class="method-step",
                  div(class="method-num", "3"),
                  div(h4("Query coverage"), p("Percentage of the processed query covered by the subject hit. Multiple local segments from the same accession are combined rather than counted as separate database hits."))
                ),
                div(class="method-step",
                  div(class="method-num", "4"),
                  div(h4("E-value and Bit score"), p("E-value describes the expected chance occurrence of a match of similar quality; Bit score is a normalized alignment score used here to compare the leading taxon with competing hits."))
                ),
                div(class="method-step",
                  div(class="method-num", "5"),
                  div(h4("HSP — High-scoring Segment Pair"), p("A local alignment segment within a BLAST hit. Multiple HSPs for the same accession are aggregated so that one NCBI record contributes one accession-level hit."))
                )
              ),
              div(class="about-callout",
                strong("Why accession-level aggregation matters: "),
                "without aggregation, one NCBI record containing several HSPs could receive several votes and distort both query-coverage statistics and taxonomic consensus."
              )
            ),

            tabPanel("Taxonomic algorithm",
              div(class="help-card",
                h3("Decision logic"),
                p(class="about-lead",
                  "The algorithm combines published biological context with application-specific decision rules. The rules are documented here so they can be reviewed and calibrated against known isolates rather than treated as universal species-delimitation rules."),

                div(class="method-step",
                  div(class="method-num", "1"),
                  div(
                    h4("One accession = one hit", span(class="evidence-badge evidence-published", "BLAST structure")),
                    p("HSPs are collapsed at accession level before taxonomy is interpreted. The decision engine does not give extra taxonomic weight to an accession merely because it contains several local alignment segments.")
                  )
                ),
                div(class="method-step",
                  div(class="method-num", "2"),
                  div(
                    h4("Primary score cluster", span(class="evidence-badge evidence-heuristic", "App heuristic")),
                    p("Hits are sorted by Bit score. After at least three hits, the app searches for the largest leading score cliff while the hit above the gap remains ≥70% of the best score. The gap must be ≥ max(20 bits, 3% of the best Bit score). If no qualifying cliff is found, hits with ≥90% of the best Bit score form the primary cluster.")
                  )
                ),
                div(class="method-step",
                  div(class="method-num", "3"),
                  div(
                    h4("Rank-specific agreement", span(class="evidence-badge evidence-heuristic", "App heuristic")),
                    p("Species and genus are evaluated separately inside the competitive score cluster. Unresolved labels such as sp., uncultured or unclassified are not treated as named competing species.")
                  )
                ),
                div(class="method-step",
                  div(class="method-num", "4"),
                  div(
                    h4("Best taxonomic competitor and ΔBit", span(class="evidence-badge evidence-heuristic", "App heuristic")),
                    p("The strongest different species and strongest different genus are identified explicitly. Their Bit scores are compared with the leading candidate so a large database majority cannot hide a nearly tied alternative taxon.")
                  )
                ),
                div(class="method-step",
                  div(class="method-num", "5"),
                  div(
                    h4("Sequence evidence", span(class="evidence-badge evidence-published", "Literature context")),
                    p("Identity and query coverage are evaluated on the leading accession-level evidence. For ITS, the app displays the broad 99.6% species and 94.3% genus identity benchmarks reported by Vu et al. as context for sequence-evidence strength, not as hard eligibility gates. A strong genus consensus is therefore retained even when Identity falls below the broad genus benchmark; the confidence is reduced instead. Published work also shows that optimal ITS thresholds vary among fungal lineages.")
                  )
                ),
                div(class="method-step",
                  div(class="method-num", "6"),
                  div(
                    h4("Reference context", span(class="evidence-badge evidence-published", "Reference quality")),
                    p("Type-material wording, RefSeq status, ordinary GenBank records and unresolved/environmental annotations are shown separately. Curated/type-associated reference evidence is more informative than simple database frequency.")
                  )
                ),
                div(class="method-step",
                  div(class="method-num", "7"),
                  div(
                    h4("Conservative rank fallback", span(class="evidence-badge evidence-heuristic", "App heuristic")),
                    p("If the evidence does not justify the species rank but clearly supports the genus, the recommendation falls back to genus while retaining the leading species as a candidate for review. Failure at species level therefore does not automatically mean Unresolved.")
                  )
                )
              ),
              div(class="about-callout",
                strong("Overall confidence: "),
                "reported confidence combines taxonomic agreement within the competitive score cluster, separation from the nearest taxonomic competitor, sequence evidence and reference context. The component values remain visible in the Taxonomic summary so the conclusion can be audited."
              )
            ),

            tabPanel("Scientific references",
              p(class="about-lead",
                "The links below are the main scientific and NCBI sources used to justify the biological context of the workflow. External links open in a new browser tab."),

              div(class="reference-card",
                h4("Schoch et al. 2012 — ITS as the primary fungal DNA barcode"),
                p("Compared candidate fungal barcode regions and proposed the nuclear ribosomal ITS region as the universal DNA barcode marker for Fungi."),
                tags$a(href="https://www.pnas.org/doi/10.1073/pnas.1117018109", target="_blank", rel="noopener noreferrer", "Open PNAS article ↗")
              ),

              div(class="reference-card",
                h4("Vu et al. 2018 — large-scale fungal barcode thresholds"),
                p("Large-scale analysis of filamentous fungal DNA barcodes. The broad ITS benchmarks used as context in the app (approximately 99.6% species and 94.3% genus) come from this work."),
                tags$a(href="https://pmc.ncbi.nlm.nih.gov/articles/PMC6020082/", target="_blank", rel="noopener noreferrer", "Open full text at NCBI/PMC ↗")
              ),

              div(class="reference-card",
                h4("Garnica et al. 2016 — lineage-dependent ITS thresholds"),
                p("Shows that optimal ITS similarity thresholds vary among lineages and that no single identity cutoff is universally reliable even within a diverse fungal genus."),
                tags$a(href="https://academic.oup.com/femsec/article/92/4/fiw045/2197947", target="_blank", rel="noopener noreferrer", "Open FEMS Microbiology Ecology article ↗")
              ),

              div(class="reference-card",
                h4("Stielow et al. 2015 — secondary fungal DNA barcodes"),
                p("Evaluated secondary fungal barcode loci and universal primers, supporting the use of additional loci when ITS alone does not provide sufficient resolution."),
                tags$a(href="https://pmc.ncbi.nlm.nih.gov/articles/PMC4713107/", target="_blank", rel="noopener noreferrer", "Open full text at NCBI/PMC ↗")
              ),

              div(class="reference-card",
                h4("NCBI RefSeq Targeted Loci — fungal ITS"),
                p("Describes NCBI's curated fungal ITS reference collection. Sequences are mostly derived from type material and are maintained with specimen/taxonomic context."),
                tags$a(href="https://www.ncbi.nlm.nih.gov/refseq/targetedloci/", target="_blank", rel="noopener noreferrer", "Open NCBI RefSeq Targeted Loci ↗")
              ),

              div(class="reference-card",
                h4("NCBI BLAST documentation"),
                p("Technical definitions for BLAST output fields including Bit score, HSPs and query-coverage measures used by the application parser."),
                tags$a(href="https://www.ncbi.nlm.nih.gov/books/NBK279684/", target="_blank", rel="noopener noreferrer", "Open NCBI BLAST+ manual ↗")
              ),

              div(class="reference-card",
                h4("UNITE — fungal ITS reference and Species Hypotheses"),
                p("A fungal ITS-centered identification resource and Species Hypotheses system. It is included here as scientific context and a possible future curated-reference extension; the current app does not query UNITE directly."),
                tags$a(href="https://unite.ut.ee/", target="_blank", rel="noopener noreferrer", "Open UNITE ↗")
              ),

              div(class="about-callout",
                strong("Important distinction: "),
                "the score-cluster thresholds, ΔBit interpretation and confidence categories are application-specific heuristics. They are not published species-delimitation thresholds. Published sources guide the biological context, while these rules should be calibrated against known isolates."
              )
            ),

            tabPanel("Version history",
              div(class="help-card",
                h3("CHANGELOG"),
                p("Every version records changes to processing, BLAST parsing, taxonomic interpretation and reporting so exported results can be traced back to the software logic used at the time."),
                verbatimTextOutput("changelog_text")
              )
            )
          )
        )
      )
    )
  )
)

# ============================================================
# Server
# ============================================================

server <- function(input, output, session) {
  rv <- reactiveValues(
    results = list(), summary = NULL, rename = NULL, settings = NULL,
    blast_jobs = data.frame(
      final_name=character(), original_name=character(), rid=character(), rtoe=character(),
      hitlist_size=integer(), status=character(), submitted_at=character(), last_checked_at=character(), stringsAsFactors=FALSE
    ),
    ncbi_last_contact = as.POSIXct(NA),
    blast_batch_status_text = "No batch operation has been run yet.",
    blast_raw = list(), blast_ids = data.frame(), blast_hits = data.frame(),
    taxonomy_summary = data.frame(), taxonomy_hits = data.frame(), taxonomy_counts = data.frame(),
    taxonomy_status_text = "No taxonomic analysis has been run yet.",
    taxonomy_batch_status_text = "No batch taxonomic analysis has been run yet.",
    project_status_text = "Current session has not been saved as a project.",
    project_loaded_name = "",
    context_peak_flag = NULL,
    pending_curation = NULL,
    auto_correct_preview_df = data.frame()
  )

  sync_summary_from_results <- function() {
    if (is.null(rv$summary) || !is.data.frame(rv$summary) || !nrow(rv$summary) || is.null(rv$results) || !length(rv$results)) return(invisible(NULL))
    for (nm in names(rv$results)) {
      r <- ensure_curation_state(rv$results[[nm]])
      r <- curation_rebuild(r, rv$settings)
      rv$results[[nm]] <- r
      sm <- r$summary
      idx <- which(as.character(rv$summary$sample_id) == nm)
      if (!length(idx) || !nrow(sm)) next
      for (col in names(sm)) {
        if (!col %in% names(rv$summary)) rv$summary[[col]] <- NA
        rv$summary[idx[1], col] <- sm[1, col]
      }
    }
    invisible(NULL)
  }

  # ---------------- Project Save / Load ----------------
  output$project_status <- renderUI({
    span(rv$project_status_text)
  })

  make_project_bundle <- function() {
    list(
      format = "SangerSequencePipelineProject",
      schema_version = PROJECT_SCHEMA_VERSION,
      app_version = APP_VERSION,
      saved_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
      active_tab = if (!is.null(input$pipeline_step)) input$pipeline_step else "upload",
      ui_state = list(
        inspect_sample = input$inspect_sample,
        blast_sample = input$blast_sample,
        tax_sample = input$tax_sample,
        blast_database = input$blast_database,
        blast_hitlist = input$blast_hitlist
      ),
      state = list(
        results = rv$results,
        summary = rv$summary,
        rename = rv$rename,
        settings = rv$settings,
        blast_jobs = rv$blast_jobs,
        blast_raw = rv$blast_raw,
        blast_ids = rv$blast_ids,
        blast_hits = normalize_blast_hits_unique_accession(rv$blast_hits),
        blast_batch_status_text = rv$blast_batch_status_text,
        taxonomy_summary = rv$taxonomy_summary,
        taxonomy_hits = rv$taxonomy_hits,
        taxonomy_counts = rv$taxonomy_counts,
        taxonomy_status_text = rv$taxonomy_status_text,
        taxonomy_batch_status_text = rv$taxonomy_batch_status_text
      )
    )
  }

  output$save_project <- downloadHandler(
    filename = function() {
      target <- if (!is.null(rv$settings) && !is.null(rv$settings$target) && nzchar(rv$settings$target)) rv$settings$target else "Sanger"
      paste0(clean_fasta_name(target), "_", format(Sys.Date(), "%Y%m%d"), ".sangerproject")
    },
    content = function(file) {
      saveRDS(make_project_bundle(), file = file, compress = "xz")
      rv$project_status_text <- paste0("Project saved from v", APP_VERSION, " at ", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), ".")
    }
  )

  rebuild_blast_ids <- function() {
    if (!is.data.frame(rv$blast_hits) || !nrow(rv$blast_hits)) {
      rv$blast_ids <- data.frame()
      return(invisible(NULL))
    }
    hits <- normalize_blast_hits_unique_accession(rv$blast_hits)
    rv$blast_hits <- hits
    if (!all(c("original_name", "rid") %in% names(hits))) {
      rv$blast_ids <- data.frame()
      return(invisible(NULL))
    }
    parts <- split(seq_len(nrow(hits)), paste(hits$original_name, hits$rid, sep = "\r"))
    tops <- lapply(parts, function(idx) {
      g <- hits[idx, , drop = FALSE]
      if ("rank" %in% names(g)) g <- g[order(suppressWarnings(as.numeric(g$rank)), na.last = TRUE), , drop = FALSE]
      g[1, , drop = FALSE]
    })
    top <- do.call(rbind, tops)
    keep <- intersect(c(
      "final_name","original_name","rid","organism","record_title","accession","taxid",
      "identity_percent","query_coverage_percent","evalue","bit_score","match_support"
    ), names(top))
    rv$blast_ids <- top[, keep, drop = FALSE]
    rownames(rv$blast_ids) <- NULL
  }

  invalidate_downstream_for_sample <- function(original_name, reason = "Curated sequence changed") {
    if (is.null(original_name) || !nzchar(original_name)) return(invisible(NULL))
    stale_rids <- character()
    if (is.data.frame(rv$blast_jobs) && nrow(rv$blast_jobs) && "original_name" %in% names(rv$blast_jobs)) {
      idx <- which(rv$blast_jobs$original_name == original_name)
      if (length(idx)) {
        stale_rids <- unique(as.character(rv$blast_jobs$rid[idx]))
        rv$blast_jobs$status[idx] <- "STALE"
      }
    }
    if (is.data.frame(rv$blast_hits) && nrow(rv$blast_hits)) {
      if ("original_name" %in% names(rv$blast_hits)) {
        stale_rids <- unique(c(stale_rids, as.character(rv$blast_hits$rid[rv$blast_hits$original_name == original_name])))
        rv$blast_hits <- rv$blast_hits[rv$blast_hits$original_name != original_name, , drop = FALSE]
      } else if (length(stale_rids) && "rid" %in% names(rv$blast_hits)) {
        rv$blast_hits <- rv$blast_hits[!rv$blast_hits$rid %in% stale_rids, , drop = FALSE]
      }
    }
    rebuild_blast_ids()
    filter_stale_tax <- function(df) {
      if (!is.data.frame(df) || !nrow(df)) return(df)
      if ("original_name" %in% names(df)) return(df[df$original_name != original_name, , drop = FALSE])
      if (length(stale_rids) && "rid" %in% names(df)) return(df[!df$rid %in% stale_rids, , drop = FALSE])
      df
    }
    rv$taxonomy_summary <- filter_stale_tax(rv$taxonomy_summary)
    rv$taxonomy_hits <- filter_stale_tax(rv$taxonomy_hits)
    rv$taxonomy_counts <- filter_stale_tax(rv$taxonomy_counts)
    rv$blast_batch_status_text <- paste0("Sequence ", original_name, " changed after curation; previous BLAST results for this sample are stale and must be rerun.")
    rv$taxonomy_status_text <- paste0("Sequence ", original_name, " changed after curation; taxonomic interpretation was invalidated.")
    invisible(NULL)
  }

  commit_curated_result <- function(sample_name, new_result, label = "Manual curation") {
    old_result <- rv$results[[sample_name]]
    old_seq <- if (!is.null(old_result$seq)) as.character(old_result$seq) else ""
    new_seq <- if (!is.null(new_result$seq)) as.character(new_result$seq) else ""
    rv$results[[sample_name]] <- new_result
    sync_summary_from_results()
    if (identical(input$inspect_sample, sample_name)) {
      updateTextAreaInput(session, "trimmed_sequence_preview", value = new_seq)
    }
    if (!identical(old_seq, new_seq)) {
      invalidate_downstream_for_sample(sample_name, label)
    }
    rv$project_status_text <- paste0("Unsaved curation change: ", sample_name, " · ", label, ".")
    invisible(!identical(old_seq, new_seq))
  }

  restore_settings_inputs <- function(settings) {
    if (is.null(settings) || !is.list(settings)) return(invisible(NULL))
    if (!is.null(settings$target)) updateSelectInput(session, "target", selected = settings$target)
    if (!is.null(settings$forward_primer)) updateTextInput(session, "forward_primer", value = settings$forward_primer)
    if (!is.null(settings$forward_primer_seq)) updateTextInput(session, "forward_primer_seq", value = settings$forward_primer_seq)
    if (!is.null(settings$reverse_primer)) updateTextInput(session, "reverse_primer", value = settings$reverse_primer)
    if (!is.null(settings$reverse_primer_seq)) updateTextInput(session, "reverse_primer_seq", value = settings$reverse_primer_seq)
    if (!is.null(settings$sequencing_primer)) updateRadioButtons(session, "sequencing_primer", selected = settings$sequencing_primer)
    if (!is.null(settings$enable_primer_mapping)) updateCheckboxInput(session, "enable_primer_mapping", value = isTRUE(settings$enable_primer_mapping))
    if (!is.null(settings$expected_amplicon_len)) updateNumericInput(session, "expected_amplicon_len", value = settings$expected_amplicon_len)
    if (!is.null(settings$absolute_max_base_index)) updateNumericInput(session, "absolute_max_base_index", value = settings$absolute_max_base_index)
    if (!is.null(settings$window)) updateNumericInput(session, "window", value = settings$window)
    if (!is.null(settings$min_peak_ratio)) updateNumericInput(session, "min_peak_ratio", value = settings$min_peak_ratio)
    if (!is.null(settings$min_relative_signal)) updateNumericInput(session, "min_relative_signal", value = settings$min_relative_signal)
    if (!is.null(settings$min_len_before_collapse)) updateNumericInput(session, "min_len_before_collapse", value = settings$min_len_before_collapse)
    if (!is.null(settings$bad_run_windows)) updateNumericInput(session, "bad_run_windows", value = settings$bad_run_windows)
    if (!is.null(settings$min_usable_len)) updateNumericInput(session, "min_usable_len", value = settings$min_usable_len)
  }

  observeEvent(input$load_project, {
    req(input$load_project$datapath)
    obj <- tryCatch(readRDS(input$load_project$datapath), error = function(e) structure(list(error = conditionMessage(e)), class = "project_load_error"))
    if (inherits(obj, "project_load_error")) {
      showNotification(paste("Could not load project:", obj$error), type = "error", duration = 10)
      return()
    }
    if (!is.list(obj) || !identical(obj$format, "SangerSequencePipelineProject") || is.null(obj$state)) {
      showNotification("This file is not a valid Sanger Sequence Pipeline project.", type = "error", duration = 10)
      return()
    }
    if (!is.null(obj$schema_version) && as.integer(obj$schema_version) > PROJECT_SCHEMA_VERSION) {
      showNotification("This project was created by a newer project schema and cannot be loaded safely.", type = "error", duration = 10)
      return()
    }

    st <- obj$state
    rv$results <- if (!is.null(st$results)) st$results else list()
    if (length(rv$results)) {
      for (nm in names(rv$results)) {
        rv$results[[nm]] <- ensure_curation_state(rv$results[[nm]])
        rv$results[[nm]] <- curation_rebuild(rv$results[[nm]], st$settings)
      }
    }
    rv$summary <- st$summary
    rv$rename <- st$rename
    rv$settings <- st$settings
    rv$blast_jobs <- if (is.data.frame(st$blast_jobs)) st$blast_jobs else rv$blast_jobs[0, , drop = FALSE]
    rv$blast_raw <- if (is.list(st$blast_raw)) st$blast_raw else list()
    rv$blast_hits <- if (is.data.frame(st$blast_hits)) normalize_blast_hits_unique_accession(st$blast_hits) else data.frame()
    rv$blast_batch_status_text <- if (!is.null(st$blast_batch_status_text)) st$blast_batch_status_text else "Loaded project."
    rv$taxonomy_summary <- if (is.data.frame(st$taxonomy_summary)) st$taxonomy_summary else data.frame()
    rv$taxonomy_hits <- if (is.data.frame(st$taxonomy_hits)) st$taxonomy_hits else data.frame()
    rv$taxonomy_counts <- if (is.data.frame(st$taxonomy_counts)) st$taxonomy_counts else data.frame()
    rv$taxonomy_status_text <- if (!is.null(st$taxonomy_status_text)) st$taxonomy_status_text else "No taxonomic analysis has been run yet."
    rv$taxonomy_batch_status_text <- if (!is.null(st$taxonomy_batch_status_text)) st$taxonomy_batch_status_text else "No batch taxonomic analysis has been run yet."
    rv$ncbi_last_contact <- as.POSIXct(NA)
    sync_summary_from_results()
    rebuild_blast_ids()

    restore_settings_inputs(rv$settings)

    result_names <- names(rv$results)
    saved_ui <- obj$ui_state
    inspect_selected <- if (!is.null(saved_ui$inspect_sample) && saved_ui$inspect_sample %in% result_names) saved_ui$inspect_sample else if (length(result_names)) result_names[1] else character()
    updateSelectInput(session, "inspect_sample", choices = result_names, selected = inspect_selected)

    final_names <- if (!is.null(rv$rename) && nrow(rv$rename)) setNames(rv$rename$Original_name, rv$rename$New_name) else setNames(result_names, result_names)
    blast_selected <- if (!is.null(saved_ui$blast_sample) && saved_ui$blast_sample %in% unname(final_names)) saved_ui$blast_sample else if (length(final_names)) unname(final_names)[1] else character()
    updateSelectInput(session, "blast_sample", choices = final_names, selected = blast_selected)
    if (!is.null(saved_ui$blast_database)) updateSelectInput(session, "blast_database", selected = saved_ui$blast_database)
    if (!is.null(saved_ui$blast_hitlist)) updateNumericInput(session, "blast_hitlist", value = saved_ui$blast_hitlist)

    if (nrow(rv$blast_hits)) {
      pairs <- unique(rv$blast_hits[, intersect(c("original_name","final_name"), names(rv$blast_hits)), drop = FALSE])
      if (all(c("original_name","final_name") %in% names(pairs))) {
        tax_choices <- setNames(as.character(pairs$original_name), as.character(pairs$final_name))
        tax_selected <- if (!is.null(saved_ui$tax_sample) && saved_ui$tax_sample %in% unname(tax_choices)) saved_ui$tax_sample else if (length(tax_choices)) unname(tax_choices)[1] else character()
        updateSelectInput(session, "tax_sample", choices = tax_choices, selected = tax_selected)
      }
    } else {
      updateSelectInput(session, "tax_sample", choices = character())
    }

    active <- if (!is.null(obj$active_tab) && obj$active_tab %in% c("upload","settings","qc","rename","export","blast","taxonomy","help")) obj$active_tab else if (nrow(rv$taxonomy_summary)) "taxonomy" else if (nrow(rv$blast_hits)) "blast" else if (length(rv$results)) "qc" else "upload"
    updateTabsetPanel(session, "pipeline_step", selected = active)

    rv$project_loaded_name <- input$load_project$name
    rv$project_status_text <- paste0(
      "Loaded ", input$load_project$name,
      " · saved with app v", ifelse(is.null(obj$app_version), "unknown", obj$app_version),
      if (!is.null(obj$saved_at)) paste0(" · saved ", obj$saved_at) else "",
      ". BLAST hits were normalized to one row per accession."
    )
    showNotification("Project loaded successfully.", type = "message", duration = 6)
  })

  # ---------------- Upload ----------------
  output$uploaded_files_table <- renderDT({
    req(input$ab1_files)
    datatable(data.frame(File=input$ab1_files$name, Size_KB=round(input$ab1_files$size/1024,1)),
              rownames=FALSE, options=list(pageLength=15, dom="tip"))
  })

  observeEvent(input$to_settings, {
    if (is.null(input$ab1_files) || nrow(input$ab1_files)==0) {
      showNotification("Please upload at least one AB1 file.", type="error"); return()
    }
    updateTabsetPanel(session, "pipeline_step", selected="settings")
  })
  observeEvent(input$back_upload, updateTabsetPanel(session,"pipeline_step",selected="upload"))
  observeEvent(input$back_settings, updateTabsetPanel(session,"pipeline_step",selected="settings"))
  observeEvent(input$back_qc, updateTabsetPanel(session,"pipeline_step",selected="qc"))
  observeEvent(input$back_rename, updateTabsetPanel(session,"pipeline_step",selected="rename"))
  observeEvent(input$back_export, updateTabsetPanel(session,"pipeline_step",selected="export"))
  observeEvent(input$back_blast, updateTabsetPanel(session,"pipeline_step",selected="blast"))

  # ---------------- Trimming ----------------
  observeEvent(input$run_trimming, {
    req(input$ab1_files)
    settings <- list(
      target=input$target,
      forward_primer=input$forward_primer,
      forward_primer_seq=sanitize_dna(input$forward_primer_seq),
      reverse_primer=input$reverse_primer,
      reverse_primer_seq=sanitize_dna(input$reverse_primer_seq),
      sequencing_primer=input$sequencing_primer,
      enable_primer_mapping=isTRUE(input$enable_primer_mapping),
      expected_amplicon_len=as.integer(input$expected_amplicon_len),
      absolute_max_base_index=as.integer(input$absolute_max_base_index),
      window=as.integer(input$window),
      min_peak_ratio=as.numeric(input$min_peak_ratio),
      min_relative_signal=as.numeric(input$min_relative_signal),
      min_len_before_collapse=as.integer(input$min_len_before_collapse),
      bad_run_windows=as.integer(input$bad_run_windows),
      min_usable_len=as.integer(input$min_usable_len),
      ambiguous_peak_strong_ratio=1.25,
      ambiguous_peak_moderate_ratio=1.75,
      ambiguous_peak_min_relative_signal=0.20,
      auto_correct_min_alt_to_called=1.80,
      auto_correct_min_alt_to_third=2.00,
      auto_correct_max_peak_offset=2L,
      auto_correct_min_relative_signal=0.50
    )
    rv$settings <- settings
    all_results <- list(); summaries <- list(); files <- input$ab1_files

    withProgress(message="Processing AB1 files", value=0, {
      for (i in seq_len(nrow(files))) {
        sample_id <- sub("\\.ab1$", "", files$name[i], ignore.case=TRUE)
        incProgress(1/nrow(files), detail=paste("Processing", files$name[i]))
        result <- tryCatch(
          trim_one_ab1(files$datapath[i], sample_id, settings),
          error=function(e) structure(list(error=conditionMessage(e)), class="ab1_error")
        )
        if (inherits(result,"ab1_error")) {
          summaries[[sample_id]] <- make_failure_summary(sample_id, settings, result$error)
        } else {
          result <- ensure_curation_state(result)
          result <- curation_rebuild(result, settings)
          all_results[[sample_id]] <- result
          summaries[[sample_id]] <- result$summary
        }
      }
    })

    rv$results <- all_results
    rv$summary <- Reduce(rbind_fill, summaries); rownames(rv$summary) <- NULL
    rv$rename <- data.frame(Original_name=rv$summary$sample_id, New_name=rv$summary$sample_id, stringsAsFactors=FALSE)
    choices <- names(rv$results)
    updateSelectInput(session,"inspect_sample",choices=choices,selected=if(length(choices)) choices[1] else character())
    updateTabsetPanel(session,"pipeline_step",selected="qc")
  })

  # ---------------- QC summary ----------------
  output$qc_summary_cards <- renderUI({
    req(rv$summary)
    vals <- c(
      Total=nrow(rv$summary),
      OK=sum(rv$summary$status=="OK",na.rm=TRUE),
      Warnings=sum(rv$summary$status=="SHORT_AFTER_TRIMMING",na.rm=TRUE),
      Failed=sum(rv$summary$status %in% c("FAILED_TRIMMING","ERROR"),na.rm=TRUE)
    )
    fluidRow(lapply(names(vals), function(nm) column(3, div(class="summary-card", div(class="summary-number",vals[[nm]]), div(class="summary-label",nm)))))
  })

  output$summary_table <- renderDT({
    req(rv$summary)
    df <- rv$summary[,c("sample_id","target","raw_length","trimmed_length","trim_start","trim_end","collapse_index","reason","median_peak_ratio_trimmed","status")]
    names(df) <- c("Sample","Target","Raw length","Trimmed length","Start","End","Collapse","Reason","Median peak ratio","Status")
    datatable(df, rownames=FALSE, filter="top", options=list(pageLength=15,scrollX=TRUE))
  })

  selected_result <- reactive({
    req(input$inspect_sample, rv$results[[input$inspect_sample]])
    rv$results[[input$inspect_sample]]
  })

  observeEvent(input$inspect_sample, {
    r <- selected_result()
    updateTextAreaInput(session, "trimmed_sequence_preview", value = r$seq)
  })

  output$sequence_metrics <- renderDT({
    datatable(make_sequence_preview(selected_result()), rownames = FALSE, options = list(dom = "t"))
  })
  output$primer_match_table <- renderDT({
    req(isTRUE(input$enable_primer_mapping))
    datatable(primer_match_table(selected_result(), rv$settings), rownames = FALSE,
              options = list(dom = "t", scrollX = TRUE))
  })
  output$primer_alignment <- renderText({
    req(isTRUE(input$enable_primer_mapping))
    primer_alignment_text(selected_result(), rv$settings)
  })
  output$amplicon_overview <- renderPlot({
    draw_amplicon_overview(selected_result(), rv$settings)
  })
  output$expected_amplicon_note <- renderUI({
    req(rv$settings)
    span(class = "peak-flag-pill", title = "Assay metadata only; not a fixed coordinate on the Sanger read.",
         paste0("Expected amplicon: ", rv$settings$expected_amplicon_len, " bp"))
  })

  all_current_peak_flags <- reactive({
    req(selected_result())
    scope <- if (!is.null(input$peak_flag_scope) && input$peak_flag_scope %in% c("trimmed", "raw")) input$peak_flag_scope else "trimmed"
    df <- ambiguous_peak_flags(selected_result(), scope = scope, params = ambiguous_peak_params_from_settings(rv$settings))
    if (!nrow(df)) return(df)
    r <- ensure_curation_state(selected_result())
    reviewed <- as.integer(r$curation$reviewed_positions)
    df$Review_status <- ifelse(df$Position %in% reviewed, "Reviewed", "Active")
    df
  })

  current_peak_flags <- reactive({
    df <- all_current_peak_flags()
    if (!nrow(df)) return(df)
    if (!isTRUE(input$show_reviewed_flags)) df <- df[df$Review_status != "Reviewed", , drop = FALSE]
    rownames(df) <- NULL
    df
  })

  center_chromatogram_at <- function(pos, half_window = 20) {
    n <- length(selected_result()$peak_pos)
    pos <- suppressWarnings(as.numeric(pos))
    if (!is.finite(pos) || n < 1) return(invisible(NULL))
    range <- c(max(1, pos - half_window), min(n, pos + half_window))
    proxy <- plotly::plotlyProxy("chromatogram_plot", session)
    plotly::plotlyProxyInvoke(proxy, "relayout", list(xaxis.range = range))
    invisible(NULL)
  }

  output$ambiguous_peak_summary <- renderUI({
    all_df <- all_current_peak_flags()
    active <- if (nrow(all_df)) all_df[all_df$Review_status == "Active", , drop = FALSE] else all_df
    total <- nrow(active)
    strong_count <- if (total) sum(active$Severity == "Strong", na.rm = TRUE) else 0L
    moderate_count <- if (total) sum(active$Severity == "Moderate", na.rm = TRUE) else 0L
    auto_count <- if (total && "Auto_correct_candidate" %in% names(active)) sum(active$Auto_correct_candidate %in% TRUE, na.rm = TRUE) else 0L
    reviewed_count <- if (nrow(all_df)) sum(all_df$Review_status == "Reviewed", na.rm = TRUE) else 0L
    r <- ensure_curation_state(selected_result())
    div(class = "peak-flag-summary",
        div(class = "peak-flag-pill", tags$strong(total), " active"),
        div(class = "peak-flag-pill", tags$strong(strong_count), " strong"),
        div(class = "peak-flag-pill", tags$strong(moderate_count), " moderate"),
        if (auto_count > 0) div(class = "peak-flag-pill", tags$strong(auto_count), " high-confidence proposals") else NULL,
        if (reviewed_count > 0) div(class = "peak-flag-pill", tags$strong(reviewed_count), " reviewed") else NULL,
        if (r$curation$revision > 0) div(class = "manual-edit-badge", paste0("Curation revision ", r$curation$revision)) else NULL)
  })

  output$ambiguous_peak_table <- renderDT({
    df <- current_peak_flags()
    if (!nrow(df)) {
      return(datatable(
        data.frame(Message = "No active ambiguous channel-competition positions in the selected scope."),
        rownames = FALSE, selection = "none", options = list(dom = "t")
      ))
    }
    show <- df[, c("Position", "Call", "Competing_channel", "Peak_ratio", "Competitor_percent",
                   "Competitor_peak_offset", "Severity", "Flag", "Auto_correct_candidate", "Review_status"), drop = FALSE]
    show$Auto_correct_candidate <- ifelse(show$Auto_correct_candidate %in% TRUE, "Yes", "")
    names(show) <- c("Position", "Call", "Competing channel", "Peak ratio", "Competitor / called (%)",
                     "Peak offset", "Severity", "Flag", "Auto", "Status")
    datatable(
      show,
      rownames = FALSE,
      selection = list(mode = "single", selected = NULL, target = "row"),
      filter = "none",
      callback = JS("
        table.on('contextmenu', 'tbody tr', function(e) {
          e.preventDefault();
          var row = table.row(this).data();
          if (!row || row.length < 1) return;
          Shiny.setInputValue('peak_flag_context', {position: row[0], nonce: Math.random()}, {priority: 'event'});
        });
      "),
      options = list(pageLength = 10, lengthChange = FALSE, scrollX = TRUE, dom = "tip", order = list(list(0, "asc")))
    )
  })

  observeEvent(input$ambiguous_peak_table_rows_selected, {
    idx <- input$ambiguous_peak_table_rows_selected
    df <- current_peak_flags()
    if (!length(idx) || !nrow(df) || idx[1] < 1 || idx[1] > nrow(df)) return()
    center_chromatogram_at(df$Position[idx[1]])
  }, ignoreInit = TRUE)

  flag_evidence_text <- function(flag_row) {
    if (is.null(flag_row) || !nrow(flag_row)) return("")
    paste0(
      "Call ", flag_row$Call[1], "; competitor ", flag_row$Competing_channel[1],
      "; called signal ", flag_row$Called_signal[1],
      "; competitor signal ", flag_row$Competitor_signal[1],
      "; peak ratio ", flag_row$Peak_ratio[1],
      "; competitor/called ", flag_row$Competitor_percent[1], "%",
      if ("Competitor_peak_offset" %in% names(flag_row) && is.finite(flag_row$Competitor_peak_offset[1])) paste0("; peak offset ", flag_row$Competitor_peak_offset[1]) else "",
      "; flag: ", flag_row$Flag[1]
    )
  }

  show_peak_curation_menu <- function(flag_row) {
    if (is.null(flag_row) || !nrow(flag_row)) return()
    rv$context_peak_flag <- flag_row[1, , drop = FALSE]
    pos <- as.integer(flag_row$Position[1])
    call <- as.character(flag_row$Call[1])
    comp <- as.character(flag_row$Competing_channel[1])
    r <- ensure_curation_state(selected_result())
    st <- as.integer(r$summary$trim_start[1]); en <- as.integer(r$summary$trim_end[1])
    in_trim <- is.finite(st) && is.finite(en) && pos >= st && pos <= en
    trim_len <- if (in_trim) en - st + 1L else NA_integer_
    edge_zone <- if (in_trim) max(8L, min(40L, ceiling(trim_len * 0.15))) else NA_integer_
    recommendation <- ""
    if (in_trim) {
      dl <- pos - st; dr <- en - pos
      if (dl <= edge_zone || dr <= edge_zone) recommendation <- if (dl <= dr) "Recommended: trim the left edge through this position." else "Recommended: trim the right edge from this position."
    }
    comp_candidates <- unique(strsplit(gsub("[^ACGT/]", "", comp), "/", fixed = TRUE)[[1]])
    comp_candidates <- comp_candidates[comp_candidates %in% c("A","C","G","T")]
    base_choices <- unique(c(comp_candidates, c("A","C","G","T","N")))
    base_choices <- setNames(base_choices, base_choices)
    pair_code <- if (call %in% c("A","C","G","T") && length(comp_candidates) && comp_candidates[1] != call) iupac_for_pair(call, comp_candidates[1]) else NA_character_

    showModal(modalDialog(
      title = paste0("Review chromatogram position ", pos),
      easyClose = TRUE, size = "m",
      div(class = "about-callout",
          tags$strong(paste0(call, "  ↔  ", comp)), tags$br(),
          span(flag_evidence_text(flag_row))),
      if (nzchar(recommendation)) div(class = "status-note", recommendation) else NULL,
      selectInput("manual_base_choice", "Change current base to", choices = base_choices, selected = if (length(comp_candidates)) comp_candidates[1] else "N"),
      div(class = "curation-actions",
          actionButton("context_change_base_preview", "Review base change", class = "btn-primary"),
          if (!is.na(pair_code)) actionButton("context_iupac_preview", paste0("Set ambiguity ", pair_code)) else NULL,
          actionButton("context_mark_reviewed", "Keep call / mark reviewed")),
      if (in_trim) tagList(
        tags$hr(),
        div(class = "curation-actions",
            actionButton("context_trim_left", paste0("Trim left through ", pos)),
            actionButton("context_trim_right", paste0("Trim right from ", pos)))
      ) else NULL,
      footer = modalButton("Close")
    ))
  }

  observeEvent(input$peak_flag_context, {
    pos <- suppressWarnings(as.integer(input$peak_flag_context$position))
    df <- all_current_peak_flags()
    row <- df[df$Position == pos, , drop = FALSE]
    if (!nrow(row)) return()
    center_chromatogram_at(pos)
    show_peak_curation_menu(row[1, , drop = FALSE])
  }, ignoreInit = TRUE)

  show_curation_confirmation <- function(type, position, value = NULL) {
    r <- ensure_curation_state(selected_result())
    pos <- as.integer(position)
    flag_row <- rv$context_peak_flag
    evidence <- flag_evidence_text(flag_row)
    if (type == "base") {
      calls <- curated_raw_calls(r); before <- if (pos >= 1 && pos <= length(calls)) calls[pos] else ""
      after <- toupper(as.character(value))
      title <- "Confirm base edit"
      body <- tagList(
        h4(paste0("Position ", pos, ": ", before, " → ", after)),
        p(evidence),
        div(class = "status-note", "The raw AB1 trace and original base call are preserved. This edit changes only the curated sequence and will be recorded in the audit log."))
    } else {
      st <- as.integer(r$summary$trim_start[1]); en <- as.integer(r$summary$trim_end[1])
      side <- as.character(value)
      new_len <- if (side == "left") en - pos else pos - st
      title <- "Confirm manual trimming"
      body <- tagList(
        h4(if (side == "left") paste0("Remove positions ", st, "–", pos) else paste0("Remove positions ", pos, "–", en)),
        p(paste0("Current length: ", en - st + 1L, " bp · New length: ", max(0, new_len), " bp")),
        p(evidence),
        div(class = "status-note", "The automatic trimming boundaries remain stored separately. This manual boundary change is reversible and logged."))
    }
    rv$pending_curation <- list(type = type, position = pos, value = value, evidence = evidence)
    showModal(modalDialog(
      title = title, body,
      footer = tagList(modalButton("Cancel"), actionButton("confirm_curation_action", "Confirm change", class = "btn-danger")),
      easyClose = FALSE
    ))
  }

  observeEvent(input$context_change_base_preview, {
    req(rv$context_peak_flag, input$manual_base_choice)
    show_curation_confirmation("base", rv$context_peak_flag$Position[1], input$manual_base_choice)
  }, ignoreInit = TRUE)

  observeEvent(input$context_iupac_preview, {
    req(rv$context_peak_flag)
    call <- as.character(rv$context_peak_flag$Call[1])
    comp <- strsplit(as.character(rv$context_peak_flag$Competing_channel[1]), "/", fixed = TRUE)[[1]][1]
    code <- iupac_for_pair(call, comp)
    if (is.na(code)) { showNotification("No two-base IUPAC ambiguity code is available for this pair.", type = "warning"); return() }
    show_curation_confirmation("base", rv$context_peak_flag$Position[1], code)
  }, ignoreInit = TRUE)

  observeEvent(input$context_trim_left, {
    req(rv$context_peak_flag)
    show_curation_confirmation("trim", rv$context_peak_flag$Position[1], "left")
  }, ignoreInit = TRUE)

  observeEvent(input$context_trim_right, {
    req(rv$context_peak_flag)
    show_curation_confirmation("trim", rv$context_peak_flag$Position[1], "right")
  }, ignoreInit = TRUE)

  observeEvent(input$context_mark_reviewed, {
    req(rv$context_peak_flag, input$inspect_sample)
    r <- ensure_curation_state(selected_result())
    pos <- as.integer(rv$context_peak_flag$Position[1])
    snap <- curation_review_snapshot(r, pos)
    row <- data.frame(Action = "Mark reviewed / keep call", Position = pos,
                      Before = as.character(rv$context_peak_flag$Call[1]), After = as.character(rv$context_peak_flag$Call[1]),
                      Method = "Manual review", Evidence = flag_evidence_text(rv$context_peak_flag), Details = "No sequence change", stringsAsFactors = FALSE)
    r2 <- curation_commit(r, snap, row, rv$settings, paste0("Reviewed position ", pos))
    commit_curated_result(input$inspect_sample, r2, paste0("Reviewed position ", pos))
    removeModal()
  }, ignoreInit = TRUE)

  observeEvent(input$confirm_curation_action, {
    req(rv$pending_curation, input$inspect_sample)
    pnd <- rv$pending_curation
    r <- ensure_curation_state(selected_result())
    pos <- as.integer(pnd$position)
    calls <- curated_raw_calls(r)
    before_call <- if (pos >= 1 && pos <= length(calls)) calls[pos] else ""
    if (identical(pnd$type, "base")) {
      new_base <- toupper(as.character(pnd$value))
      if (identical(new_base, before_call)) {
        snap <- curation_review_snapshot(r, pos)
        row <- data.frame(Action = "Mark reviewed / keep call", Position = pos, Before = before_call, After = before_call,
                          Method = "Manual review", Evidence = pnd$evidence, Details = "Selected base equals current call; no sequence change", stringsAsFactors = FALSE)
        label <- paste0("Reviewed position ", pos)
        r2 <- curation_commit(r, snap, row, rv$settings, label)
        commit_curated_result(input$inspect_sample, r2, label)
        rv$pending_curation <- NULL
        removeModal(); showNotification(paste0(label, "."), type = "message")
        return()
      }
      snap <- curation_set_base_snapshot(r, pos, new_base)
      if (is.null(snap)) { showNotification("Could not apply the requested base edit.", type = "error"); return() }
      method <- if (new_base %in% c("R","Y","S","W","K","M")) "Manual IUPAC ambiguity" else "Manual base correction"
      row <- data.frame(Action = "Base edit", Position = pos, Before = before_call, After = new_base,
                        Method = method, Evidence = pnd$evidence, Details = "Confirmed by user", stringsAsFactors = FALSE)
      label <- paste0("Base edit at ", pos, ": ", before_call, "→", new_base)
    } else {
      side <- as.character(pnd$value)
      st <- as.integer(r$summary$trim_start[1]); en <- as.integer(r$summary$trim_end[1])
      snap <- curation_trim_snapshot(r, pos, side)
      if (is.null(snap)) { showNotification("The requested trimming boundary is not valid.", type = "error"); return() }
      row <- data.frame(Action = if (side == "left") "Manual trim left" else "Manual trim right", Position = pos,
                        Before = paste0(st, "-", en), After = paste0(snap$trim_start, "-", snap$trim_end),
                        Method = "Manual chromatogram curation", Evidence = pnd$evidence,
                        Details = "Flagged position excluded from retained sequence", stringsAsFactors = FALSE)
      label <- paste0(if (side == "left") "Trim left through " else "Trim right from ", pos)
    }
    r2 <- curation_commit(r, snap, row, rv$settings, label)
    commit_curated_result(input$inspect_sample, r2, label)
    rv$pending_curation <- NULL
    removeModal()
    showNotification(paste0(label, "."), type = "message")
  }, ignoreInit = TRUE)

  observeEvent(input$auto_correct_preview, {
    req(input$inspect_sample)
    r <- ensure_curation_state(selected_result())
    df <- high_confidence_autocorrections(r, rv$settings)
    if (nrow(df) && length(r$curation$reviewed_positions)) df <- df[!df$Position %in% r$curation$reviewed_positions, , drop = FALSE]
    if (!nrow(df)) {
      showNotification("No positions meet the very-high-confidence auto-correction criteria in the current trimmed sequence.", type = "message")
      return()
    }
    df$Proposed_base <- df$Competing_channel
    rv$auto_correct_preview_df <- df
    showModal(modalDialog(
      title = "Preview high-confidence base corrections",
      p(paste0(nrow(df), " position(s) meet all conservative auto-correction criteria. Nothing changes until you confirm.")),
      tableOutput("auto_correct_preview_table"),
      footer = tagList(modalButton("Cancel"), actionButton("confirm_auto_correct", paste0("Apply ", nrow(df), " correction(s)"), class = "btn-danger")),
      size = "l", easyClose = FALSE
    ))
  }, ignoreInit = TRUE)

  output$auto_correct_preview_table <- renderTable({
    df <- rv$auto_correct_preview_df
    if (!is.data.frame(df) || !nrow(df)) return(NULL)
    out <- df[, c("Position","Call","Proposed_base","Alternative_to_called_ratio","Alternative_to_third_ratio","Competitor_peak_offset","Competitor_signal"), drop = FALSE]
    names(out) <- c("Position","Current","Proposed","Alternative / current","Alternative / third","Peak offset","Signal")
    out
  }, striped = TRUE, bordered = TRUE, spacing = "xs")

  observeEvent(input$confirm_auto_correct, {
    req(input$inspect_sample)
    df <- rv$auto_correct_preview_df
    if (!is.data.frame(df) || !nrow(df)) return()
    r <- ensure_curation_state(selected_result())
    temp <- r
    rows <- list()
    for (i in seq_len(nrow(df))) {
      pos <- as.integer(df$Position[i]); new_base <- as.character(df$Proposed_base[i])
      calls <- curated_raw_calls(temp); before <- calls[pos]
      snap_i <- curation_set_base_snapshot(temp, pos, new_base)
      if (is.null(snap_i)) next
      temp <- curation_restore_snapshot(temp, snap_i, rv$settings)
      ev <- paste0("alternative/current=", df$Alternative_to_called_ratio[i],
                   "; alternative/third=", df$Alternative_to_third_ratio[i],
                   "; peak offset=", df$Competitor_peak_offset[i],
                   "; alternative signal=", df$Competitor_signal[i])
      rows[[length(rows)+1L]] <- data.frame(Action="Base edit", Position=pos, Before=before, After=new_base,
                                            Method="Auto high-confidence correction", Evidence=ev,
                                            Details="Applied after preview and user confirmation", stringsAsFactors=FALSE)
    }
    if (!length(rows)) { removeModal(); showNotification("No valid corrections remained to apply.", type="warning"); return() }
    action_rows <- do.call(rbind, rows)
    final_snap <- curation_snapshot(temp)
    label <- paste0("Auto-corrected ", nrow(action_rows), " high-confidence position(s)")
    r2 <- curation_commit(r, final_snap, action_rows, rv$settings, label)
    commit_curated_result(input$inspect_sample, r2, label)
    rv$auto_correct_preview_df <- data.frame()
    removeModal()
    showNotification(label, type = "message")
  }, ignoreInit = TRUE)

  observeEvent(input$curation_undo, {
    req(input$inspect_sample)
    ans <- curation_undo(selected_result(), rv$settings)
    if (!isTRUE(ans$changed)) { showNotification("Nothing to undo for this sample.", type = "message"); return() }
    commit_curated_result(input$inspect_sample, ans$result, paste0("Undo: ", ans$label))
    showNotification(paste0("Undid: ", ans$label), type = "message")
  }, ignoreInit = TRUE)

  observeEvent(input$curation_redo, {
    req(input$inspect_sample)
    ans <- curation_redo(selected_result(), rv$settings)
    if (!isTRUE(ans$changed)) { showNotification("Nothing to redo for this sample.", type = "message"); return() }
    commit_curated_result(input$inspect_sample, ans$result, paste0("Redo: ", ans$label))
    showNotification(paste0("Redid: ", ans$label), type = "message")
  }, ignoreInit = TRUE)

  output$curation_history_table <- renderDT({
    r <- ensure_curation_state(selected_result())
    lg <- r$curation$audit_log
    if (!is.data.frame(lg) || !nrow(lg)) return(datatable(data.frame(Message="No manual curation actions for this sample."), rownames=FALSE, options=list(dom="t")))
    datatable(lg, rownames=FALSE, options=list(pageLength=10, scrollX=TRUE, order=list(list(0,"desc"))))
  })

  observeEvent(input$curation_history, {
    req(input$inspect_sample)
    showModal(modalDialog(title = paste0("Curation history — ", input$inspect_sample), DTOutput("curation_history_table"), size="l", easyClose=TRUE, footer=modalButton("Close")))
  }, ignoreInit = TRUE)

  observeEvent(input$curation_reset, {
    req(input$inspect_sample)
    r <- ensure_curation_state(selected_result())
    if (!length(r$curation$undo_stack) && !nrow(r$curation$base_edits) && identical(as.integer(r$curation$trim_start), as.integer(r$curation$auto_trim_start)) && identical(as.integer(r$curation$trim_end), as.integer(r$curation$auto_trim_end))) {
      showNotification("This sample is already at the automatic trimming/base-call state.", type="message"); return()
    }
    showModal(modalDialog(
      title="Reset sample to automatic processing?",
      p("This will restore the original automatic trim boundaries and remove all manual base edits/review marks from the active curated sequence. The reset itself is logged and can be undone."),
      footer=tagList(modalButton("Cancel"), actionButton("confirm_curation_reset", "Reset sample", class="btn-danger")), easyClose=FALSE
    ))
  }, ignoreInit = TRUE)

  observeEvent(input$confirm_curation_reset, {
    req(input$inspect_sample)
    r <- ensure_curation_state(selected_result())
    snap <- curation_reset_snapshot(r)
    row <- data.frame(Action="Reset to automatic processing", Position=NA_integer_, Before=paste0(r$summary$trim_start[1], "-", r$summary$trim_end[1]),
                      After=paste0(r$curation$auto_trim_start, "-", r$curation$auto_trim_end), Method="Manual reset", Evidence="",
                      Details="Manual trims, base edits and review marks cleared from active curation state", stringsAsFactors=FALSE)
    r2 <- curation_commit(r, snap, row, rv$settings, "Reset to automatic processing")
    commit_curated_result(input$inspect_sample, r2, "Reset to automatic processing")
    removeModal(); showNotification("Sample reset to the automatic processing state.", type="message")
  }, ignoreInit = TRUE)

  output$chromatogram_plot <- plotly::renderPlotly({
    make_chromatogram_plotly(
      selected_result(), rv$settings,
      flags = current_peak_flags(),
      show_flags = isTRUE(input$show_peak_flags)
    )
  })

  output$qc_plot <- renderPlot({
    draw_qc_metrics(selected_result(), rv$settings)
  })

  observeEvent(input$to_rename, { req(rv$summary); updateTabsetPanel(session,"pipeline_step",selected="rename") })

  # ---------------- Rename key ----------------
  rename_key_data <- reactive({
    req(input$rename_key_file)
    f <- input$rename_key_file; ext <- tolower(tools::file_ext(f$name))
    key <- if (ext=="xlsx") readxl::read_excel(f$datapath) else if (ext=="csv") read.csv(f$datapath,stringsAsFactors=FALSE,check.names=FALSE) else stop("Rename key must be XLSX or CSV.")
    key <- as.data.frame(key,stringsAsFactors=FALSE)
    if (!all(c("old_id","new_id") %in% names(key))) stop("Rename key must contain old_id and new_id columns.")
    key$old_id <- trimws(as.character(key$old_id)); key$new_id <- trimws(as.character(key$new_id))
    key[key$old_id!="" & key$new_id!="",,drop=FALSE]
  })

  observeEvent(input$apply_rename_key, {
    req(rv$rename)
    key <- tryCatch(rename_key_data(), error=function(e){showNotification(conditionMessage(e),type="error");NULL})
    if (is.null(key)) return()
    matched <- 0L
    for(i in seq_len(nrow(rv$rename))) {
      original <- rv$rename$Original_name[i]
      idx <- which(key$old_id==original)
      if(!length(idx)) idx <- which(startsWith(original,key$old_id))
      if(length(idx)==1) { rv$rename$New_name[i] <- key$new_id[idx]; matched <- matched+1L }
    }
    showNotification(paste(matched,"of",nrow(rv$rename),"sample names matched."),type="message")
  })

  observeEvent(input$apply_batch_affixes, {
    req(rv$rename)
    x <- rv$rename$New_name
    rem <- input$rename_remove_suffix
    if(nzchar(rem)) x <- ifelse(endsWith(x, rem), substr(x, 1, nchar(x) - nchar(rem)), x)
    if(nzchar(input$rename_prefix)) x <- paste0(input$rename_prefix,x)
    if(nzchar(input$rename_suffix)) x <- paste0(x,input$rename_suffix)
    rv$rename$New_name <- x
  })
  observeEvent(input$apply_find_replace, {
    req(rv$rename)
    if(!nzchar(input$rename_find)) return()
    rv$rename$New_name <- gsub(input$rename_find,input$rename_replace,rv$rename$New_name,fixed=TRUE)
  })
  observeEvent(input$reset_names, { req(rv$rename); rv$rename$New_name <- rv$rename$Original_name })

  output$rename_table <- renderDT({
    req(rv$rename)
    datatable(rv$rename,rownames=FALSE,editable=list(target="cell",disable=list(columns=c(0))),options=list(pageLength=20,dom="tip"))
  })
  observeEvent(input$rename_table_cell_edit, {
    info <- input$rename_table_cell_edit
    if(info$col==1) rv$rename[info$row,"New_name"] <- as.character(info$value)
  })

  rename_error <- reactive({
    req(rv$rename)
    x <- trimws(rv$rename$New_name)
    if(any(x=="")) return("One or more sequence names are empty.")
    clean <- clean_fasta_name(x)
    if(anyDuplicated(clean)>0) return(paste0("Duplicate sequence name(s): ",paste(unique(clean[duplicated(clean)|duplicated(clean,fromLast=TRUE)]),collapse=", ")))
    NULL
  })
  output$rename_validation <- renderUI({
    e <- rename_error(); if(is.null(e)) div(class="status-ok","✓ Sequence names are valid.") else div(class="status-error",paste0("⚠ ",e))
  })

  # ---------------- Export records ----------------
  export_records <- reactive({
    req(rv$results,rv$rename)
    records <- list()
    for(original_name in names(rv$results)) {
      r <- rv$results[[original_name]]
      idx <- match(original_name,rv$rename$Original_name)
      r$final_name <- if(!is.na(idx)) rv$rename$New_name[idx] else original_name
      records[[original_name]] <- r
    }
    records
  })
  export_summary_df <- reactive({
    req(rv$summary,rv$rename)
    df <- rv$summary
    df$final_name <- rv$rename$New_name[match(df$sample_id,rv$rename$Original_name)]
    df
  })

  observeEvent(input$to_export, {
    e <- rename_error(); if(!is.null(e)){showNotification(e,type="error");return()}
    updateTabsetPanel(session,"pipeline_step",selected="export")
  })

  output$export_summary <- renderUI({
    req(rv$summary,rv$settings)
    tagList(
      p(strong("Target: "),rv$settings$target),
      p(strong("Forward primer: "),ifelse(rv$settings$forward_primer=="","Not specified",rv$settings$forward_primer)),
      p(strong("Reverse primer: "),ifelse(rv$settings$reverse_primer=="","Not specified",rv$settings$reverse_primer)),
      p(strong("Samples processed: "),nrow(rv$summary)),
      p(strong("Sequences available for export: "),sum(rv$summary$trimmed_length>0,na.rm=TRUE))
    )
  })

  # ---------------- Checkpoints ----------------
  output$download_trim_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_checkpoint_A_trim.zip"),
    content=function(file){
      rec <- export_records(); for(n in names(rec)) rec[[n]]$final_name <- n
      write_checkpoint_zip(file,"trim",rec,rv$summary,rv$settings,results=rv$results)
    })
  output$download_rename_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_checkpoint_B_rename.zip"),
    content=function(file) write_checkpoint_zip(file,"renamed",export_records(),export_summary_df(),rv$settings,rv$rename,results=rv$results))

  output$download_blast_fasta <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_BLAST.fasta"),
    content=function(file) writeLines(make_fasta(export_records(),FALSE),file))
  output$download_full_fasta <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_trimmed_sequences.fasta"),
    content=function(file) writeLines(make_fasta(export_records(),TRUE,export_summary_df()),file))
  output$download_summary_csv <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_trim_summary.csv"),
    content=function(file) write.csv(export_summary_df(),file,row.names=FALSE,fileEncoding="UTF-8"))
  output$download_all_zip <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_Sanger_pipeline_results.zip"),
    content=function(file) write_checkpoint_zip(file,"final",export_records(),export_summary_df(),rv$settings,rv$rename,results=rv$results))

  # ---------------- BLAST workspace ----------------
  observeEvent(input$to_blast, {
    rec <- export_records()
    choices <- setNames(names(rec), vapply(rec, function(x) x$final_name, character(1)))
    updateSelectInput(session, "blast_sample", choices=choices, selected=if(length(choices)) names(choices)[1] else character())
    updateTabsetPanel(session, "pipeline_step", selected="blast")
  })

  blast_selected <- reactive({
    req(input$blast_sample)
    export_records()[[input$blast_sample]]
  })

  observe({
    req(input$blast_sample)
    updateTextAreaInput(session, "blast_sequence_preview", value=blast_selected()$seq)
  })

  observeEvent(input$copy_blast_sequence,
               session$sendCustomMessage("copyText", list(text=blast_selected()$seq)))
  observeEvent(input$open_ncbi_blast,
               session$sendCustomMessage("openUrl", list(url="https://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE_TYPE=BlastSearch&PROGRAM=blastn")))

  output$download_selected_blast <- downloadHandler(
    filename=function() paste0(clean_fasta_name(blast_selected()$final_name), ".fasta"),
    content=function(file) writeLines(
      paste0(">", clean_fasta_name(blast_selected()$final_name), "\n", wrap_sequence(blast_selected()$seq, 80)),
      file
    )
  )

  # NCBI BLAST is a shared service. Keep all automated BLAST contacts at least
  # 10 seconds apart, in addition to the per-RID one-minute polling rule.
  wait_for_ncbi_contact_slot <- function(min_seconds = 10) {
    last <- rv$ncbi_last_contact
    if (!is.null(last) && length(last) && !is.na(last)) {
      elapsed <- as.numeric(difftime(Sys.time(), last, units="secs"))
      if (is.finite(elapsed) && elapsed < min_seconds) {
        Sys.sleep(min_seconds - elapsed)
      }
    }
    rv$ncbi_last_contact <- Sys.time()
  }

  parse_submit_response <- function(txt) {
    rid_match <- regmatches(txt, regexpr("RID = [A-Z0-9-]+", txt))
    rtoe_match <- regmatches(txt, regexpr("RTOE = [0-9]+", txt))
    rid <- if (length(rid_match) && nzchar(rid_match)) sub("RID = ", "", rid_match, fixed=TRUE) else ""
    rtoe <- if (length(rtoe_match) && nzchar(rtoe_match)) sub("RTOE = ", "", rtoe_match, fixed=TRUE) else NA_character_
    list(rid=rid, rtoe=rtoe)
  }

  latest_job_index_for_sample <- function(original_name) {
    idx <- which(rv$blast_jobs$original_name == original_name)
    if (!length(idx)) return(NA_integer_)
    tail(idx, 1)
  }

  submit_one_blast <- function(original_name) {
    records <- export_records()
    if (!original_name %in% names(records)) {
      return(list(ok=FALSE, message="Sequence is not available in the processed record set."))
    }
    r <- records[[original_name]]
    if (is.null(r) || !nzchar(r$seq)) {
      return(list(ok=FALSE, message="Processed sequence is empty."))
    }

    hitlist <- min(100L, max(1L, as.integer(input$blast_hitlist)))
    wait_for_ncbi_contact_slot(10)

    req_obj <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
      httr2::req_body_form(
        CMD="Put", PROGRAM="blastn", DATABASE=input$blast_database,
        QUERY=paste0(">", clean_fasta_name(r$final_name), "\n", r$seq),
        HITLIST_SIZE=hitlist
      ) |>
      httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")

    txt <- tryCatch(
      httr2::resp_body_string(httr2::req_perform(req_obj)),
      error=function(e) structure(list(error=conditionMessage(e)), class="blast_submit_error")
    )
    if (inherits(txt, "blast_submit_error")) {
      return(list(ok=FALSE, message=txt$error))
    }

    parsed <- parse_submit_response(txt)
    if (!nzchar(parsed$rid)) {
      return(list(ok=FALSE, message="NCBI did not return a BLAST RID."))
    }

    rv$blast_jobs <- rbind(rv$blast_jobs, data.frame(
      final_name=r$final_name,
      original_name=original_name,
      rid=parsed$rid,
      rtoe=parsed$rtoe,
      hitlist_size=hitlist,
      status="SUBMITTED",
      submitted_at=format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
      last_checked_at="",
      stringsAsFactors=FALSE
    ))

    list(ok=TRUE, rid=parsed$rid, rtoe=parsed$rtoe, final_name=r$final_name)
  }

  observeEvent(input$submit_ncbi_blast, {
    req(input$blast_sample)
    ans <- submit_one_blast(input$blast_sample)
    if (!isTRUE(ans$ok)) {
      showNotification(ans$message, type="error")
      return()
    }
    showNotification(paste("Submitted to NCBI. RID:", ans$rid), type="message")
  })

  observeEvent(input$submit_all_ncbi_blast, {
    records <- export_records()
    sample_names <- names(records)[vapply(records, function(x) !is.null(x$seq) && nzchar(x$seq), logical(1))]
    if (!length(sample_names)) {
      showNotification("No processed sequences are available for BLAST submission.", type="warning")
      return()
    }

    submitted <- 0L
    skipped <- 0L
    failed <- 0L
    failures <- character()
    rv$blast_batch_status_text <- paste0("Submitting ", length(sample_names), " processed sequence(s) to NCBI...")

    withProgress(message="Submitting all sequences to NCBI BLAST", value=0, {
      for (i in seq_along(sample_names)) {
        nm <- sample_names[i]
        idx <- latest_job_index_for_sample(nm)
        if (!is.na(idx) && rv$blast_jobs$status[idx] %in% c("SUBMITTED", "WAITING", "READY")) {
          skipped <- skipped + 1L
          incProgress(1/length(sample_names), detail=paste("Skipping active job:", records[[nm]]$final_name))
          next
        }

        incProgress(0, detail=paste("Submitting", records[[nm]]$final_name))
        ans <- submit_one_blast(nm)
        if (isTRUE(ans$ok)) {
          submitted <- submitted + 1L
        } else {
          failed <- failed + 1L
          failures <- c(failures, paste0(records[[nm]]$final_name, ": ", ans$message))
        }
        incProgress(1/length(sample_names))
      }
    })

    rv$blast_batch_status_text <- paste0(
      "Batch submission complete · submitted: ", submitted,
      " · skipped existing jobs: ", skipped,
      " · failed: ", failed,
      if (length(failures)) paste0(" · ", paste(failures, collapse=" | ")) else ""
    )
    showNotification(rv$blast_batch_status_text, type=if(failed) "warning" else "message", duration=10)
  })

  store_retrieved_hits <- function(hits, r, original_name, rid) {
    # v2.9 BLAST parser: one biological/database hit per accession. Multiple
    # HSPs (local alignment segments) must not receive independent weight in
    # taxonomy or sequence-evidence calculations.
    hits <- normalize_blast_hits_unique_accession(hits)
    hits$final_name <- r$final_name
    hits$original_name <- original_name
    hits$rid <- rid

    hit_cols <- c(
      "final_name","original_name","rid","rank","organism","record_title","accession","taxid",
      "identity_percent","query_coverage_percent","evalue","bit_score","alignment_length","hsp_count","match_support"
    )
    for (nm in setdiff(hit_cols, names(hits))) hits[[nm]] <- NA
    hits <- hits[, hit_cols, drop=FALSE]

    if (nrow(rv$blast_hits) && "rid" %in% names(rv$blast_hits)) {
      rv$blast_hits <- rv$blast_hits[rv$blast_hits$rid != rid, , drop=FALSE]
    }
    rv$blast_hits <- rbind(rv$blast_hits, hits)

    top <- hits[1, , drop=FALSE]
    top_cols <- c(
      "final_name","original_name","rid","organism","record_title","accession","taxid",
      "identity_percent","query_coverage_percent","evalue","bit_score","match_support"
    )

    # Preliminary identification is one current top-hit row per sequence.
    if (nrow(rv$blast_ids) && "original_name" %in% names(rv$blast_ids)) {
      rv$blast_ids <- rv$blast_ids[rv$blast_ids$original_name != original_name, , drop=FALSE]
    }
    rv$blast_ids <- rbind(rv$blast_ids, top[, top_cols, drop=FALSE])
  }

  retrieve_blast_job <- function(job_idx) {
    if (is.na(job_idx) || job_idx < 1 || job_idx > nrow(rv$blast_jobs)) {
      return(list(status="ERROR", contacted=FALSE, message="BLAST job index is invalid."))
    }
    if (identical(as.character(rv$blast_jobs$status[job_idx]), "STALE")) {
      return(list(status="STALE", contacted=FALSE, message="This RID belongs to a sequence version that was changed during manual curation. Submit the current curated sequence as a new BLAST job."))
    }

    original_name <- rv$blast_jobs$original_name[job_idx]
    records <- export_records()
    if (!original_name %in% names(records)) {
      return(list(status="ERROR", contacted=FALSE, message="Processed sequence is no longer available."))
    }
    r <- records[[original_name]]
    rid <- rv$blast_jobs$rid[job_idx]

    # Do not poll a single RID more often than once per minute.
    reference_time <- rv$blast_jobs$last_checked_at[job_idx]
    if (!nzchar(reference_time)) reference_time <- rv$blast_jobs$submitted_at[job_idx]
    ref <- suppressWarnings(as.POSIXct(reference_time, format="%Y-%m-%d %H:%M:%S"))
    if (!is.na(ref)) {
      elapsed <- as.numeric(difftime(Sys.time(), ref, units="secs"))
      if (is.finite(elapsed) && elapsed < 60) {
        return(list(
          status="TOO_SOON", contacted=FALSE,
          message=paste0("Wait ", ceiling(60-elapsed), " more seconds before checking RID ", rid, ".")
        ))
      }
    }

    wait_for_ncbi_contact_slot(10)
    rv$blast_jobs$last_checked_at[job_idx] <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")

    req_obj <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
      httr2::req_url_query(CMD="Get", RID=rid, FORMAT_TYPE="XML2") |>
      httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")

    txt <- tryCatch(
      httr2::resp_body_string(httr2::req_perform(req_obj)),
      error=function(e) structure(list(error=conditionMessage(e)), class="blast_retrieve_error")
    )
    if (inherits(txt, "blast_retrieve_error")) {
      return(list(status="ERROR", contacted=TRUE, message=txt$error))
    }

    if (grepl("Status=WAITING", txt)) {
      rv$blast_jobs$status[job_idx] <- "WAITING"
      return(list(status="WAITING", contacted=TRUE, message="NCBI BLAST is still running."))
    }
    if (grepl("Status=FAILED|Status=UNKNOWN", txt)) {
      rv$blast_jobs$status[job_idx] <- "FAILED/UNKNOWN"
      return(list(status="FAILED", contacted=TRUE, message="NCBI reports failed or unknown job."))
    }

    rv$blast_jobs$status[job_idx] <- "READY"
    rv$blast_raw[[rid]] <- txt

    requested_hits <- suppressWarnings(as.integer(rv$blast_jobs$hitlist_size[job_idx]))
    if (!is.finite(requested_hits) || requested_hits < 1) requested_hits <- as.integer(input$blast_hitlist)
    requested_hits <- min(100L, max(1L, requested_hits))

    hits <- parse_blast_xml2_hits(
      txt,
      query_length=nchar(r$seq),
      max_hits=requested_hits
    )

    if (!nrow(hits)) {
      # Defensive fallback to NCBI's headerless 12-field tabular CSV.
      wait_for_ncbi_contact_slot(10)
      csv_req <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
        httr2::req_url_query(CMD="Get", RID=rid, FORMAT_TYPE="CSV", ALIGNMENT_VIEW="Tabular") |>
        httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")
      csv_txt <- tryCatch(
        httr2::resp_body_string(httr2::req_perform(csv_req)),
        error=function(e) NULL
      )
      if (!is.null(csv_txt)) {
        hits <- parse_blast_csv_hits_fallback(csv_txt, query_length=nchar(r$seq))
        if (nrow(hits)) {
          hits <- head(hits, requested_hits)
          rv$blast_raw[[rid]] <- csv_txt
        }
      }
    }

    hits <- normalize_blast_hits_unique_accession(hits)
    if (nrow(hits) > requested_hits) hits <- hits[seq_len(requested_hits), , drop = FALSE]

    if (!nrow(hits)) {
      return(list(status="NO_HITS", contacted=TRUE, message="BLAST is ready, but no unique accession-level hits could be parsed."))
    }

    # Enrich every unique accession whose XML/tabular result lacks display metadata.
    needs_meta <- which(
      (!nzchar(ifelse(is.na(hits$organism), "", hits$organism))) |
      (!nzchar(ifelse(is.na(hits$record_title), "", hits$record_title)))
    )

    if (length(needs_meta)) {
      accessions_needed <- unique(hits$accession[needs_meta])
      meta_df <- tryCatch(
        fetch_ncbi_nucleotide_metadata_batch(accessions_needed),
        error=function(e) data.frame()
      )

      if (nrow(meta_df)) {
        strip_version <- function(x) sub("\\.[0-9]+$", "", as.character(x))
        for (i in needs_meta) {
          acc <- hits$accession[i]
          idx <- which(meta_df$accession == acc)
          if (!length(idx) && "primary_accession" %in% names(meta_df)) idx <- which(meta_df$primary_accession == strip_version(acc))
          if (!length(idx)) idx <- which(strip_version(meta_df$accession) == strip_version(acc))
          if (length(idx)) {
            m <- meta_df[idx[1], , drop=FALSE]
            if ((!nzchar(hits$organism[i]) || is.na(hits$organism[i])) && nzchar(m$organism[1])) hits$organism[i] <- m$organism[1]
            if ((!nzchar(hits$record_title[i]) || is.na(hits$record_title[i])) && nzchar(m$title[1])) hits$record_title[i] <- m$title[1]
            if ((is.na(hits$taxid[i]) || !is.finite(hits$taxid[i])) && !is.na(m$taxid[1])) hits$taxid[i] <- m$taxid[1]
          }
        }
      }
    }

    store_retrieved_hits(hits, r, original_name, rid)
    list(status="READY", contacted=TRUE, hits=nrow(hits), message=paste0(nrow(hits), " hit(s) retrieved."))
  }

  observeEvent(input$retrieve_ncbi_blast, {
    req(input$blast_sample)
    job_idx <- latest_job_index_for_sample(input$blast_sample)
    if (is.na(job_idx)) {
      showNotification("Submit this sequence first.", type="warning")
      return()
    }
    ans <- retrieve_blast_job(job_idx)
    type <- if (ans$status %in% c("ERROR","FAILED")) "error" else if (ans$status %in% c("TOO_SOON","WAITING","NO_HITS","STALE")) "warning" else "message"
    showNotification(ans$message, type=type, duration=8)
  })

  observeEvent(input$retrieve_all_ncbi_blast, {
    if (!nrow(rv$blast_jobs)) {
      showNotification("No BLAST jobs have been submitted yet.", type="warning")
      return()
    }

    # Only the newest RID for each sequence is relevant to the current workspace.
    latest_indices <- unname(vapply(unique(rv$blast_jobs$original_name), latest_job_index_for_sample, integer(1)))
    latest_indices <- latest_indices[is.finite(latest_indices)]
    if (!length(latest_indices)) return()

    ready <- 0L; waiting <- 0L; too_soon <- 0L; failed <- 0L; no_hits <- 0L; stale <- 0L
    rv$blast_batch_status_text <- paste0("Checking ", length(latest_indices), " BLAST job(s)...")

    withProgress(message="Retrieving submitted NCBI BLAST jobs", value=0, {
      for (k in seq_along(latest_indices)) {
        idx <- latest_indices[k]
        final_name <- rv$blast_jobs$final_name[idx]
        rid <- rv$blast_jobs$rid[idx]

        # A READY RID that is already present in the hit store does not need another server request.
        already_stored <- nrow(rv$blast_hits) && "rid" %in% names(rv$blast_hits) && rid %in% rv$blast_hits$rid
        if (identical(rv$blast_jobs$status[idx], "READY") && already_stored) {
          ready <- ready + 1L
          incProgress(1/length(latest_indices), detail=paste(final_name, "already retrieved"))
          next
        }

        incProgress(0, detail=paste("Checking", final_name))
        ans <- retrieve_blast_job(idx)
        if (ans$status == "READY") ready <- ready + 1L
        else if (ans$status == "WAITING") waiting <- waiting + 1L
        else if (ans$status == "TOO_SOON") too_soon <- too_soon + 1L
        else if (ans$status == "NO_HITS") no_hits <- no_hits + 1L
        else if (ans$status == "STALE") stale <- stale + 1L
        else failed <- failed + 1L
        incProgress(1/length(latest_indices))
      }
    })

    rv$blast_batch_status_text <- paste0(
      "Batch retrieval · ready: ", ready,
      " · still running: ", waiting,
      " · too soon to poll: ", too_soon,
      " · no parsed hits: ", no_hits,
      " · stale: ", stale,
      " · failed: ", failed
    )
    showNotification(rv$blast_batch_status_text, type=if(failed) "warning" else "message", duration=10)
  })

  output$blast_batch_status <- renderUI({
    div(class="tax-note", strong("Batch status: "), rv$blast_batch_status_text)
  })

  output$blast_job_status <- renderUI({
    req(input$blast_sample)
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name == input$blast_sample, , drop=FALSE]
    if (!nrow(jobs)) return(p(class="settings-note", "No NCBI submission yet for this sequence."))
    j <- jobs[nrow(jobs), ]
    div(
      class=if(j$status == "READY") "status-ok" else "status-warning",
      paste("Selected sequence · RID:", j$rid, "| Status:", j$status,
            "| Requested hits:", j$hitlist_size,
            "| Estimated wait (RTOE):", j$rtoe, "seconds")
    )
  })

  output$blast_jobs_table <- renderDT({
    df <- rv$blast_jobs
    if (!nrow(df)) return(datatable(data.frame(Message="No BLAST jobs submitted yet."), rownames=FALSE, options=list(dom="t")))
    keep <- c("final_name","original_name","rid","hitlist_size","rtoe","status","submitted_at","last_checked_at")
    df <- df[, intersect(keep, names(df)), drop=FALSE]
    friendly <- c(
      final_name="Sample", original_name="Original sample", rid="RID", hitlist_size="Hits requested",
      rtoe="Estimated wait (s)", status="Status", submitted_at="Submitted at", last_checked_at="Last checked at"
    )
    names(df) <- unname(friendly[names(df)])
    datatable(df, rownames=FALSE, options=list(pageLength=25, scrollX=TRUE))
  })

  output$blast_identification_table <- renderDT({
    # Deliberately show all retrieved sequences here: one current top hit per
    # sequence. The selected-sequence filter belongs to the detailed hit table.
    df <- rv$blast_ids
    if (!nrow(df)) {
      return(datatable(
        data.frame(Message="No parsed identification results yet. Submit and retrieve one or more BLAST jobs."),
        rownames=FALSE, options=list(dom="t")
      ))
    }

    df <- df[order(tolower(as.character(df$final_name))), , drop=FALSE]
    keep <- intersect(c(
      "final_name","organism","accession","identity_percent","query_coverage_percent",
      "evalue","bit_score","match_support","record_title","taxid","rid"
    ), names(df))
    df <- df[, keep, drop=FALSE]
    friendly <- c(
      final_name="Sample", organism="Organism / taxon", accession="Accession",
      identity_percent="Identity (%)", query_coverage_percent="Query coverage (%)",
      evalue="E-value", bit_score="Bit score", match_support="Match support",
      record_title="NCBI hit title", taxid="NCBI TaxID", rid="RID"
    )
    names(df) <- unname(friendly[names(df)])

    datatable(
      df, rownames=FALSE, filter="top",
      options=list(
        pageLength=25, scrollX=TRUE, autoWidth=TRUE,
        columnDefs=list(
          list(targets=1, className="dt-organism", width="190px"),
          list(targets=8, className="dt-hit-title", width="440px"),
          list(targets=c(0,2,3,4,5,6,7,9,10), className="dt-nowrap")
        )
      )
    )
  })

  output$blast_hits_table <- renderDT({
    df <- rv$blast_hits
    if (nrow(df) && !is.null(input$blast_sample)) {
      jobs <- rv$blast_jobs[rv$blast_jobs$original_name == input$blast_sample, , drop=FALSE]
      if (nrow(jobs)) {
        latest_rid <- jobs$rid[nrow(jobs)]
        df <- df[df$rid == latest_rid, , drop=FALSE]
      } else {
        df <- df[0, , drop=FALSE]
      }
    }
    if (!nrow(df)) return(datatable(data.frame(Message="No retrieved hits yet for the selected sequence."), rownames=FALSE, options=list(dom="t")))

    keep <- intersect(c(
      "rank","organism","accession","identity_percent","query_coverage_percent",
      "evalue","bit_score","hsp_count","match_support","record_title","taxid"
    ), names(df))
    df <- df[, keep, drop=FALSE]
    friendly <- c(
      rank="Rank", organism="Organism / taxon", accession="Accession",
      identity_percent="Identity (%)", query_coverage_percent="Query coverage (%)",
      evalue="E-value", bit_score="Bit score", hsp_count="HSP count", match_support="Match support",
      record_title="NCBI hit title", taxid="NCBI TaxID"
    )
    names(df) <- unname(friendly[names(df)])

    datatable(
      df, rownames=FALSE, filter="top",
      options=list(
        pageLength=25, scrollX=TRUE, autoWidth=TRUE,
        columnDefs=list(
          list(targets=1, className="dt-organism", width="190px"),
          list(targets=9, className="dt-hit-title", width="440px"),
          list(targets=c(0,2,3,4,5,6,7,8,10), className="dt-nowrap")
        )
      )
    )
  })

  output$blast_raw_preview <- renderText({
    req(input$blast_sample)
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name == input$blast_sample, , drop=FALSE]
    if (!nrow(jobs)) return("")
    rid <- jobs$rid[nrow(jobs)]
    txt <- rv$blast_raw[[rid]]
    if (is.null(txt)) return("")
    substr(txt, 1, min(5000, nchar(txt)))
  })

  output$download_blast_jobs <- downloadHandler(
    filename=function() "NCBI_BLAST_jobs_and_identifications.csv",
    content=function(file) {
      jobs <- rv$blast_jobs
      if (nrow(rv$blast_ids)) jobs <- merge(jobs, rv$blast_ids, by=c("final_name","original_name","rid"), all.x=TRUE)
      write.csv(jobs, file, row.names=FALSE, fileEncoding="UTF-8")
    }
  )

  output$download_blast_hits <- downloadHandler(
    filename=function() "NCBI_BLAST_all_hits.csv",
    content=function(file) write.csv(rv$blast_hits, file, row.names=FALSE, fileEncoding="UTF-8")
  )

  # ---------------- Taxonomic interpretation ----------------
  latest_blast_rid_for_sample <- function(original_name) {
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name == original_name,,drop=FALSE]
    if (!nrow(jobs)) return("")
    jobs$rid[nrow(jobs)]
  }

  blast_hits_for_sample <- function(original_name) {
    rid <- latest_blast_rid_for_sample(original_name)
    if (!nzchar(rid) || !nrow(rv$blast_hits)) return(rv$blast_hits[0,,drop=FALSE])
    rv$blast_hits[rv$blast_hits$rid == rid,,drop=FALSE]
  }

  update_tax_sample_choices <- function(selected = NULL) {
    if (!nrow(rv$blast_hits)) {
      updateSelectInput(session, "tax_sample", choices = character())
      return(invisible(NULL))
    }
    pairs <- unique(rv$blast_hits[,c("original_name","final_name"),drop=FALSE])
    pairs <- pairs[nzchar(as.character(pairs$original_name)),,drop=FALSE]
    choices <- setNames(as.character(pairs$original_name), as.character(pairs$final_name))
    if (is.null(selected) || !selected %in% choices) selected <- if (length(choices)) choices[1] else character()
    updateSelectInput(session, "tax_sample", choices = choices, selected = selected)
  }

  observeEvent(input$pipeline_step, {
    if (identical(input$pipeline_step, "taxonomy") && nrow(rv$blast_hits)) {
      selected <- if (!is.null(input$tax_sample) && nzchar(input$tax_sample)) input$tax_sample else if (!is.null(input$blast_sample) && nzchar(input$blast_sample)) input$blast_sample else NULL
      update_tax_sample_choices(selected)
    }
  }, ignoreInit = TRUE)

  # Keep the taxonomy selector synchronized as each sequence result arrives,
  # including results retrieved through the batch BLAST workflow.
  observe({
    rv$blast_hits
    if (nrow(rv$blast_hits)) {
      selected <- isolate(input$tax_sample)
      update_tax_sample_choices(selected)
    }
  })


  observeEvent(input$to_taxonomy, {
    if (!nrow(rv$blast_hits)) {
      showNotification("Retrieve at least one BLAST result before taxonomic interpretation.", type="warning")
      return()
    }
    selected <- if (!is.null(input$blast_sample) && nzchar(input$blast_sample)) input$blast_sample else NULL
    update_tax_sample_choices(selected)
    updateTabsetPanel(session, "pipeline_step", selected="taxonomy")
  })

  analyze_taxonomy_sample <- function(sample_key, quiet = FALSE) {
    src <- normalize_blast_hits_unique_accession(blast_hits_for_sample(sample_key))
    if (!nrow(src)) return(list(ok=FALSE, message="No retrieved unique accession-level BLAST hits are available for this sequence."))

    rid <- unique(as.character(src$rid))[1]
    final_name <- unique(as.character(src$final_name))[1]
    top_n <- nrow(src)

    enriched <- NULL
    result <- NULL
    err <- NULL
    enriched <- tryCatch(
      enrich_hits_with_taxonomy(src),
      error=function(e) { err <<- conditionMessage(e); NULL }
    )
    if (!is.null(enriched)) {
      result <- tryCatch(
        build_taxonomic_consensus(enriched, target=rv$settings$target, top_n=top_n),
        error=function(e) { err <<- conditionMessage(e); NULL }
      )
    }
    if (is.null(result) || !nrow(result$summary)) {
      return(list(ok=FALSE, message=if (!is.null(err)) paste("Taxonomic analysis failed:", err) else "Taxonomic analysis did not produce a summary."))
    }

    tax_error <- attr(enriched, "taxonomy_error")
    sm <- result$summary
    sm$final_name <- final_name
    sm$original_name <- sample_key
    sm$rid <- rid
    sm$target <- rv$settings$target
    sm$max_hits_inspected <- top_n
    sm$analyzed_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
    sm$app_version <- APP_VERSION
    order_cols <- c("final_name","original_name","rid","target","recommended_identification","recommended_level","confidence")
    sm <- sm[,c(order_cols, setdiff(names(sm), order_cols)),drop=FALSE]

    th <- result$hits
    th$final_name <- final_name
    th$original_name <- sample_key
    th$rid <- rid

    tc <- result$counts
    tc$final_name <- final_name
    tc$original_name <- sample_key
    tc$rid <- rid

    if (nrow(rv$taxonomy_summary) && "rid" %in% names(rv$taxonomy_summary)) rv$taxonomy_summary <- rv$taxonomy_summary[rv$taxonomy_summary$rid != rid,,drop=FALSE]
    if (nrow(rv$taxonomy_hits) && "rid" %in% names(rv$taxonomy_hits)) rv$taxonomy_hits <- rv$taxonomy_hits[rv$taxonomy_hits$rid != rid,,drop=FALSE]
    if (nrow(rv$taxonomy_counts) && "rid" %in% names(rv$taxonomy_counts)) rv$taxonomy_counts <- rv$taxonomy_counts[rv$taxonomy_counts$rid != rid,,drop=FALSE]

    rv$taxonomy_summary <- rbind_fill(rv$taxonomy_summary, sm)
    rv$taxonomy_hits <- rbind_fill(rv$taxonomy_hits, th)
    rv$taxonomy_counts <- rbind_fill(rv$taxonomy_counts, tc)

    msg <- paste0(
      "Analysis complete for ", final_name, ": ",
      sm$recommended_identification[1], " · ", sm$recommended_level[1],
      " · confidence ", sm$confidence[1], "."
    )
    if (!is.null(tax_error) && nzchar(tax_error)) msg <- paste0(msg, " Some NCBI lineage lookups reported: ", tax_error)
    list(ok=TRUE, message=msg, final_name=final_name)
  }

  observeEvent(input$run_taxonomy, {
    req(input$tax_sample)
    rv$taxonomy_status_text <- paste0("Resolving NCBI taxonomy for ", input$tax_sample, "...")
    ans <- NULL
    withProgress(message="Taxonomic interpretation", value=0, {
      incProgress(0.2, detail="Resolving NCBI taxonomy and lineages")
      ans <- analyze_taxonomy_sample(input$tax_sample)
      incProgress(0.8, detail="Preparing consensus")
    })
    rv$taxonomy_status_text <- ans$message
    if (isTRUE(ans$ok)) showNotification("Taxonomic consensus completed.", type="message") else showNotification(ans$message, type="error")
  })

  observeEvent(input$run_taxonomy_all, {
    if (!nrow(rv$blast_hits)) {
      showNotification("Retrieve BLAST results before running batch taxonomy.", type="warning")
      return()
    }
    pairs <- unique(rv$blast_hits[,c("original_name","final_name"),drop=FALSE])
    samples <- as.character(pairs$original_name)
    samples <- samples[nzchar(samples)]
    if (!length(samples)) return()

    ok_n <- 0L; fail_n <- 0L; failures <- character()
    withProgress(message="Analyzing all retrieved sequences", value=0, {
      for (i in seq_along(samples)) {
        incProgress(1/length(samples), detail=paste0(i, "/", length(samples), " · ", pairs$final_name[match(samples[i], pairs$original_name)]))
        ans <- analyze_taxonomy_sample(samples[i], quiet=TRUE)
        if (isTRUE(ans$ok)) ok_n <- ok_n + 1L else { fail_n <- fail_n + 1L; failures <- c(failures, paste0(samples[i], ": ", ans$message)) }
        if (i < length(samples)) Sys.sleep(0.35)
      }
    })
    rv$taxonomy_batch_status_text <- paste0("Batch taxonomy complete: ", ok_n, " analyzed, ", fail_n, " failed.")
    rv$taxonomy_status_text <- rv$taxonomy_batch_status_text
    if (fail_n) showNotification(paste0(rv$taxonomy_batch_status_text, " Review failed samples individually."), type="warning") else showNotification(rv$taxonomy_batch_status_text, type="message")
    update_tax_sample_choices(isolate(input$tax_sample))
  })

  selected_tax_summary <- reactive({
    req(input$tax_sample)
    if (!nrow(rv$taxonomy_summary)) return(rv$taxonomy_summary[0,,drop=FALSE])
    rid <- latest_blast_rid_for_sample(input$tax_sample)
    rv$taxonomy_summary[rv$taxonomy_summary$rid == rid,,drop=FALSE]
  })

  selected_tax_hits <- reactive({
    req(input$tax_sample)
    if (!nrow(rv$taxonomy_hits)) return(rv$taxonomy_hits[0,,drop=FALSE])
    rid <- latest_blast_rid_for_sample(input$tax_sample)
    rv$taxonomy_hits[rv$taxonomy_hits$rid == rid,,drop=FALSE]
  })

  selected_tax_counts <- reactive({
    req(input$tax_sample)
    if (!nrow(rv$taxonomy_counts)) return(rv$taxonomy_counts[0,,drop=FALSE])
    rid <- latest_blast_rid_for_sample(input$tax_sample)
    rv$taxonomy_counts[rv$taxonomy_counts$rid == rid,,drop=FALSE]
  })

  output$taxonomy_status <- renderUI({
    div(class="tax-note", strong("Status: "), rv$taxonomy_status_text)
  })

  output$taxonomy_hero <- renderUI({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(NULL)
    conf <- tolower(as.character(sm$confidence[1]))
    conf_class <- if (grepl("high", conf)) "confidence-high" else if (grepl("moderate", conf)) "confidence-moderate" else "confidence-low"

    species_candidate_line <- NULL
    if ("species_candidate" %in% names(sm) && nzchar(as.character(sm$species_candidate[1])) &&
        !identical(as.character(sm$recommended_identification[1]), as.character(sm$species_candidate[1]))) {
      species_candidate_line <- div(
        class="taxonomy-sub",
        paste0(
          "Species candidate for review: ", sm$species_candidate[1],
          " · candidate confidence: ",
          ifelse("species_candidate_confidence" %in% names(sm), sm$species_candidate_confidence[1], "—")
        )
      )
    }

    panel_box(
      div(class="taxonomy-hero",
        div(class="taxonomy-id", sm$recommended_identification[1]),
        div(class="taxonomy-sub",
          paste0("Recommended level: ", sm$recommended_level[1], " · "),
          span(class=conf_class, paste0("Overall confidence: ", sm$confidence[1]))
        ),
        div(class="taxonomy-sub",
          paste0(
            "Taxonomic support: ", ifelse("taxonomic_support" %in% names(sm), sm$taxonomic_support[1], "—"),
            " · Sequence evidence: ", ifelse("sequence_evidence" %in% names(sm), sm$sequence_evidence[1], "—"),
            " · Reference support: ", ifelse("reference_support" %in% names(sm), sm$reference_support[1], "—")
          )
        ),
        species_candidate_line
      )
    )
  })

  output$taxonomy_summary_cards <- renderUI({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(NULL)
    val <- function(x, suffix="") {
      if (length(x) == 0 || is.na(x) || !nzchar(as.character(x))) "—" else paste0(x, suffix)
    }
    delta_value <- if ("species_delta_bit" %in% names(sm) && is.finite(suppressWarnings(as.numeric(sm$species_delta_bit[1])))) {
      val(sm$species_delta_bit[1])
    } else if ("genus_delta_bit" %in% names(sm)) {
      val(sm$genus_delta_bit[1])
    } else {
      "—"
    }
    delta_label <- if ("species_delta_bit" %in% names(sm) && is.finite(suppressWarnings(as.numeric(sm$species_delta_bit[1])))) {
      "ΔBit to best different species"
    } else {
      "ΔBit to best different genus"
    }

    fluidRow(
      column(3, div(class="summary-card",
                    div(class="summary-number", val(sm$genus_cluster_agreement_percent[1], "%")),
                    div(class="summary-label", "Genus agreement · primary score cluster"))),
      column(3, div(class="summary-card",
                    div(class="summary-number", val(sm$species_cluster_agreement_percent[1], "%")),
                    div(class="summary-label", "Species agreement · primary score cluster"))),
      column(3, div(class="summary-card",
                    div(class="summary-number", delta_value),
                    div(class="summary-label", delta_label))),
      column(3, div(class="summary-card",
                    div(class="summary-number", val(sm$sequence_evidence[1])),
                    div(class="summary-label", "Sequence evidence")))
    )
  })

  output$taxonomy_summary_table <- renderDT({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(datatable(data.frame(Message="Run multi-hit taxonomic analysis for this sequence."), rownames=FALSE, options=list(dom="t")))

    keep <- intersect(c(
      "algorithm_version","recommended_identification","recommended_level","confidence","taxonomic_support","sequence_evidence","reference_support",
      "species_candidate","species_candidate_confidence",
      "hits_used","primary_score_cluster_hits","score_cluster_method","score_cliff_gap","score_cliff_threshold",
      "candidate_genus","genus_cluster_agreement_percent","genus_best_competitor",
      "genus_delta_bit","genus_delta_bit_percent","genus_separation","genus_reference_support",
      "species_cluster_agreement_percent","species_best_competitor",
      "species_delta_bit","species_delta_bit_percent","species_separation","species_reference_support",
      "candidate_identity_percent","candidate_query_coverage_percent",
      "lowest_common_taxon","lowest_common_rank"
    ), names(sm))
    df <- sm[,keep,drop=FALSE]

    friendly <- c(
      algorithm_version="Decision engine",
      recommended_identification="Recommended identification",
      recommended_level="Recommended level",
      confidence="Overall confidence",
      taxonomic_support="Taxonomic support",
      sequence_evidence="Sequence evidence",
      reference_support="Reference support",
      species_candidate="Species candidate for review",
      species_candidate_confidence="Species candidate confidence",
      hits_used="Unique accession hits evaluated",
      primary_score_cluster_hits="Hits in primary score cluster",
      score_cluster_method="Score-cluster rule",
      score_cliff_gap="Detected score-cliff ΔBit",
      score_cliff_threshold="Score-cliff threshold",
      candidate_genus="Candidate genus",
      genus_cluster_agreement_percent="Genus agreement in score cluster (%)",
      genus_best_competitor="Best different genus",
      genus_delta_bit="Genus competitor ΔBit",
      genus_delta_bit_percent="Genus competitor ΔBit (%)",
      genus_separation="Genus competitor separation",
      genus_reference_support="Genus reference support",
      species_cluster_agreement_percent="Species agreement in score cluster (%)",
      species_best_competitor="Best different species",
      species_delta_bit="Species competitor ΔBit",
      species_delta_bit_percent="Species competitor ΔBit (%)",
      species_separation="Species competitor separation",
      species_reference_support="Species reference support",
      candidate_identity_percent="Candidate hit identity (%)",
      candidate_query_coverage_percent="Candidate hit query coverage (%)",
      lowest_common_taxon="Lowest common taxon",
      lowest_common_rank="LCA rank"
    )
    names(df) <- unname(friendly[names(df)])
    datatable(df, rownames=FALSE, options=list(dom="t", scrollX=TRUE, autoWidth=TRUE))
  })

  output$taxonomy_locus_note <- renderUI({
    sm <- selected_tax_summary()
    if (!nrow(sm)) return(NULL)
    tagList(
      div(class="tax-note", strong("Decision explanation: "),
          if ("decision_reason" %in% names(sm)) sm$decision_reason[1] else "—"),
      div(class="tax-note", style="margin-top:8px;", strong("How the decision is made: "),
          "The recommendation is driven by the primary high-scoring cluster, the strongest competing taxon, sequence evidence and reference context."),
      div(class="tax-note", style="margin-top:8px;", strong(paste0("Locus-aware note (", sm$target[1], "): ")), sm$locus_note[1])
    )
  })

  output$taxonomy_counts_table <- renderDT({
    df <- selected_tax_counts()
    if (!nrow(df)) return(datatable(data.frame(Message="No agreement summary yet."), rownames=FALSE, options=list(dom="t")))
    keep <- intersect(c("level","taxon","hit_count","resolved_hits","agreement_percent","share_of_scope_percent"), names(df))
    df <- df[,keep,drop=FALSE]
    friendly <- c(
      level="Level", taxon="Taxon", hit_count="Hit count",
      resolved_hits="Resolved hits at rank",
      agreement_percent="Agreement among resolved hits (%)",
      share_of_scope_percent="Share of all hits in scope (%)"
    )
    names(df) <- unname(friendly[names(df)])
    datatable(df, rownames=FALSE,
              options=list(pageLength=14, dom="tip", scrollX=TRUE,
                           order=list(list(0,"asc"),list(2,"desc"))))
  })

  output$taxonomy_score_plot <- plotly::renderPlotly({
    df <- selected_tax_hits()
    if (!nrow(df)) return(plotly::plot_ly() |> plotly::layout(title="Run taxonomic analysis to display the BLAST score landscape."))

    df$analysis_rank <- if ("analysis_rank" %in% names(df)) suppressWarnings(as.numeric(df$analysis_rank)) else seq_len(nrow(df))
    df$bit_score_num <- suppressWarnings(as.numeric(df$bit_score))
    df$cluster_label <- if ("primary_score_cluster" %in% names(df)) ifelse(as.logical(df$primary_score_cluster), "Primary score cluster", "Outside primary cluster") else "Outside primary cluster"
    df$display_taxon <- ifelse(nzchar(clean_taxon_text(df$species)), clean_taxon_text(df$species),
                               ifelse(nzchar(clean_taxon_text(df$genus)), clean_taxon_text(df$genus), clean_taxon_text(df$organism)))
    refq <- if ("reference_quality" %in% names(df)) as.character(df$reference_quality) else ""
    acc <- if ("accession" %in% names(df)) as.character(df$accession) else ""
    ident <- if ("identity_percent" %in% names(df)) suppressWarnings(as.numeric(df$identity_percent)) else NA_real_
    cov <- if ("query_coverage_percent" %in% names(df)) suppressWarnings(as.numeric(df$query_coverage_percent)) else NA_real_

    df$hover <- paste0(
      "<b>", df$display_taxon, "</b>",
      "<br>Accession: ", acc,
      "<br>Bit score: ", round(df$bit_score_num,2),
      "<br>Identity: ", round(ident,2), "%",
      "<br>Query coverage: ", round(cov,1), "%",
      "<br>Reference: ", refq
    )

    p <- plotly::plot_ly(
      df,
      x=~analysis_rank,
      y=~bit_score_num,
      color=~cluster_label,
      type="scatter",
      mode="lines+markers",
      text=~hover,
      hoverinfo="text"
    )
    p <- plotly::layout(
      p,
      xaxis=list(title="BLAST hit rank after accession-level normalization", dtick=1),
      yaxis=list(title="Bit score"),
      legend=list(orientation="h", x=0, y=1.12),
      hovermode="closest"
    )
    plotly::config(
      p,
      displaylogo=FALSE,
      modeBarButtonsToRemove=c("lasso2d", "select2d", "hoverCompareCartesian")
    )
  })

  output$taxonomy_hits_table <- renderDT({
    df <- selected_tax_hits()
    if (!nrow(df)) return(datatable(data.frame(Message="No taxonomy-enriched hits yet."), rownames=FALSE, options=list(dom="t")))
    keep <- intersect(c(
      "analysis_rank","primary_score_cluster","organism","genus","species","family","accession","taxid",
      "identity_percent","query_coverage_percent","evalue","bit_score","delta_bit_from_best",
      "relative_bit_score_percent","reference_quality","hsp_count"
    ), names(df))
    df <- df[,keep,drop=FALSE]
    friendly <- c(
      analysis_rank="Analysis rank",
      primary_score_cluster="Primary score cluster",
      organism="NCBI organism",
      genus="Genus",
      species="Species",
      family="Family",
      accession="Accession",
      taxid="NCBI TaxID",
      identity_percent="Identity (%)",
      query_coverage_percent="Query coverage (%)",
      evalue="E-value",
      bit_score="Bit score",
      delta_bit_from_best="ΔBit from best",
      relative_bit_score_percent="Relative Bit score (%)",
      reference_quality="Reference quality",
      hsp_count="HSP count"
    )
    names(df) <- unname(friendly[names(df)])

    datatable(
      df, rownames=FALSE, filter="top",
      options=list(
        pageLength=25, scrollX=TRUE, autoWidth=TRUE,
        columnDefs=list(
          list(targets=intersect(c(2,3,4,5), seq_len(ncol(df))-1), className="dt-taxon")
        )
      )
    )
  })

  all_qc_peak_flags <- reactive({
    if (is.null(rv$results) || !length(rv$results)) return(data.frame())
    collect_ambiguous_peak_flags(rv$results, scope = "trimmed", settings = rv$settings)
  })

  all_curation_log <- reactive({
    if (is.null(rv$results) || !length(rv$results)) return(data.frame())
    collect_curation_log(rv$results)
  })

  team_summary_df <- reactive({
    base <- if (!is.null(rv$summary) && nrow(rv$summary)) export_summary_df() else data.frame()
    if (!nrow(base)) return(data.frame())

    out <- data.frame(
      Sample = as.character(base$final_name),
      Original_sample = as.character(base$sample_id),
      Target = if ("target" %in% names(base)) as.character(base$target) else if (!is.null(rv$settings)) rv$settings$target else "",
      Raw_length = if ("raw_length" %in% names(base)) base$raw_length else NA,
      Trimmed_length = if ("trimmed_length" %in% names(base)) base$trimmed_length else NA,
      QC_status = if ("status" %in% names(base)) as.character(base$status) else "",
      Ambiguous_peak_flags = 0L,
      Strong_peak_flags = 0L,
      Manual_curation_actions = 0L,
      Manual_base_edits = 0L,
      Curation_revision = 0L,
      Identification = "Not analyzed",
      Identification_level = "",
      Overall_confidence = "",
      Taxonomic_support = "",
      Sequence_evidence = "",
      Reference_support = "",
      Species_candidate = "",
      Species_candidate_confidence = "",
      Genus_cluster_agreement_percent = NA_real_,
      Species_cluster_agreement_percent = NA_real_,
      Candidate_identity_percent = NA_real_,
      Candidate_query_coverage_percent = NA_real_,
      Genus_best_competitor = "",
      Genus_delta_bit = NA_real_,
      Species_best_competitor = "",
      Species_delta_bit = NA_real_,
      Primary_score_cluster_hits = NA_integer_,
      BLAST_hits_used = NA_integer_,
      Top_accession = "",
      Top_NCBI_organism = "",
      RID = "",
      Comment = "",
      Application_version = APP_VERSION,
      stringsAsFactors = FALSE
    )

    qcf <- all_qc_peak_flags()
    if (nrow(qcf)) {
      for (i in seq_len(nrow(out))) {
        sf <- qcf[qcf$Sample == out$Original_sample[i], , drop = FALSE]
        if ("Review_status" %in% names(sf)) sf <- sf[sf$Review_status == "Active", , drop = FALSE]
        out$Ambiguous_peak_flags[i] <- nrow(sf)
        out$Strong_peak_flags[i] <- if (nrow(sf)) sum(sf$Severity == "Strong", na.rm = TRUE) else 0L
      }
    }
    clog <- all_curation_log()
    for (i in seq_len(nrow(out))) {
      nm <- out$Original_sample[i]
      if (nrow(clog)) out$Manual_curation_actions[i] <- sum(clog$Sample == nm & !clog$Action %in% c("UNDO","REDO"), na.rm=TRUE)
      r <- rv$results[[nm]]
      if (!is.null(r)) {
        r <- ensure_curation_state(r)
        out$Manual_base_edits[i] <- nrow(r$curation$base_edits)
        out$Curation_revision[i] <- as.integer(r$curation$revision)
      }
    }

    if (nrow(rv$taxonomy_summary)) {
      for (i in seq_len(nrow(out))) {
        sm <- rv$taxonomy_summary[rv$taxonomy_summary$original_name == out$Original_sample[i],,drop=FALSE]
        if (!nrow(sm)) next
        sm <- sm[nrow(sm),,drop=FALSE]
        out$Identification[i] <- as.character(sm$recommended_identification[1])
        out$Identification_level[i] <- as.character(sm$recommended_level[1])
        out$Overall_confidence[i] <- as.character(sm$confidence[1])
        if ("taxonomic_support" %in% names(sm)) out$Taxonomic_support[i] <- as.character(sm$taxonomic_support[1])
        if ("sequence_evidence" %in% names(sm)) out$Sequence_evidence[i] <- as.character(sm$sequence_evidence[1])
        if ("reference_support" %in% names(sm)) out$Reference_support[i] <- as.character(sm$reference_support[1])
        if ("species_candidate" %in% names(sm)) out$Species_candidate[i] <- as.character(sm$species_candidate[1])
        if ("species_candidate_confidence" %in% names(sm)) out$Species_candidate_confidence[i] <- as.character(sm$species_candidate_confidence[1])
        if ("genus_cluster_agreement_percent" %in% names(sm)) out$Genus_cluster_agreement_percent[i] <- sm$genus_cluster_agreement_percent[1]
        if ("species_cluster_agreement_percent" %in% names(sm)) out$Species_cluster_agreement_percent[i] <- sm$species_cluster_agreement_percent[1]
        if ("candidate_identity_percent" %in% names(sm)) out$Candidate_identity_percent[i] <- sm$candidate_identity_percent[1]
        if ("candidate_query_coverage_percent" %in% names(sm)) out$Candidate_query_coverage_percent[i] <- sm$candidate_query_coverage_percent[1]
        if ("genus_best_competitor" %in% names(sm)) out$Genus_best_competitor[i] <- as.character(sm$genus_best_competitor[1])
        if ("genus_delta_bit" %in% names(sm)) out$Genus_delta_bit[i] <- sm$genus_delta_bit[1]
        if ("species_best_competitor" %in% names(sm)) out$Species_best_competitor[i] <- as.character(sm$species_best_competitor[1])
        if ("species_delta_bit" %in% names(sm)) out$Species_delta_bit[i] <- sm$species_delta_bit[1]
        if ("primary_score_cluster_hits" %in% names(sm)) out$Primary_score_cluster_hits[i] <- sm$primary_score_cluster_hits[1]
        if ("hits_used" %in% names(sm)) out$BLAST_hits_used[i] <- sm$hits_used[1]
        out$RID[i] <- as.character(sm$rid[1])
        if ("decision_reason" %in% names(sm)) out$Comment[i] <- as.character(sm$decision_reason[1])

        bh <- rv$blast_hits[rv$blast_hits$rid == out$RID[i],,drop=FALSE]
        if (nrow(bh)) {
          if ("rank" %in% names(bh)) bh <- bh[order(suppressWarnings(as.numeric(bh$rank))),,drop=FALSE]
          if ("accession" %in% names(bh)) out$Top_accession[i] <- as.character(bh$accession[1])
          if ("organism" %in% names(bh)) out$Top_NCBI_organism[i] <- as.character(bh$organism[1])
        }
      }
    }
    out
  })

  output$team_summary_table <- renderDT({
    df <- team_summary_df()
    if (!nrow(df)) return(datatable(data.frame(Message="No processed sequences yet."), rownames=FALSE, options=list(dom="t")))
    show <- intersect(c(
      "Sample","Target","Trimmed_length","QC_status","Ambiguous_peak_flags","Strong_peak_flags","Manual_curation_actions","Manual_base_edits","Curation_revision","Identification","Identification_level","Overall_confidence",
      "Species_candidate","Species_candidate_confidence","Species_cluster_agreement_percent","Genus_cluster_agreement_percent",
      "Candidate_identity_percent","Candidate_query_coverage_percent","Reference_support",
      "Species_best_competitor","Species_delta_bit","Genus_best_competitor","Genus_delta_bit","Comment"
    ), names(df))
    datatable(df[,show,drop=FALSE], rownames=FALSE, filter="top",
              options=list(pageLength=25, scrollX=TRUE, autoWidth=TRUE, columnDefs=list(list(targets=which(show=="Comment")-1, width="360px"))))
  })

  output$download_team_summary_csv <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(rv$settings), "Sanger", rv$settings$target)), "_team_identification_summary.csv"),
    content=function(file) write.csv(team_summary_df(), file, row.names=FALSE, fileEncoding="UTF-8")
  )

  output$download_team_summary_xlsx <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(rv$settings), "Sanger", rv$settings$target)), "_team_identification_summary.xlsx"),
    content=function(file) {
      req(nrow(team_summary_df()))
      wb <- openxlsx::createWorkbook(creator="Sanger Sequence Pipeline")
      header_style <- openxlsx::createStyle(fgFill="#1F4E78", fontColour="#FFFFFF", textDecoration="bold", halign="center", valign="center")
      wrap_style <- openxlsx::createStyle(wrapText=TRUE, valign="top")

      add_sheet <- function(name, df, freeze=TRUE) {
        if (is.null(df) || !ncol(df)) df <- data.frame(Message="No data available", stringsAsFactors=FALSE)
        openxlsx::addWorksheet(wb, name)
        openxlsx::writeData(wb, name, df, withFilter=nrow(df)>0, headerStyle=header_style)
        if (freeze) openxlsx::freezePane(wb, name, firstRow=TRUE)
        if (nrow(df)) openxlsx::addStyle(wb, name, wrap_style, rows=2:(nrow(df)+1), cols=seq_len(ncol(df)), gridExpand=TRUE, stack=TRUE)
        openxlsx::setColWidths(wb, name, cols=seq_len(ncol(df)), widths="auto")
        long_cols <- which(names(df) %in% c("Comment","decision_reason","record_title","hit_title","NCBI hit title"))
        if (length(long_cols)) openxlsx::setColWidths(wb, name, cols=long_cols, widths=45)
      }

      add_sheet("Summary", team_summary_df())
      add_sheet("BLAST Hits", rv$blast_hits)
      add_sheet("Taxonomy Details", rv$taxonomy_summary)
      add_sheet("QC", export_summary_df())
      add_sheet("QC Flags", all_qc_peak_flags())
      add_sheet("Manual Curation", all_curation_log())
      if (!is.null(rv$rename)) add_sheet("Rename Map", rv$rename)
      settings_df <- data.frame(
        Field=c("Application version","Exported at", if (!is.null(rv$settings)) names(rv$settings) else character()),
        Value=c(APP_VERSION, format(Sys.time(), "%Y-%m-%d %H:%M:%S"), if (!is.null(rv$settings)) unlist(rv$settings, use.names=FALSE) else character()),
        stringsAsFactors=FALSE
      )
      add_sheet("Run Settings", settings_df, freeze=FALSE)
      openxlsx::saveWorkbook(wb, file, overwrite=TRUE)
    }
  )

  output$changelog_text <- renderText({
    path <- "CHANGELOG.md"
    if (!file.exists(path)) return("No changelog file found.")
    paste(readLines(path, warn=FALSE), collapse="\n")
  })

  output$download_taxonomy_summary <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(input$tax_sample), "sample", input$tax_sample)), "_taxonomic_summary.csv"),
    content=function(file) write.csv(selected_tax_summary(), file, row.names=FALSE, fileEncoding="UTF-8")
  )

  output$download_taxonomy_hits <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(input$tax_sample), "sample", input$tax_sample)), "_taxonomy_enriched_hits.csv"),
    content=function(file) write.csv(selected_tax_hits(), file, row.names=FALSE, fileEncoding="UTF-8")
  )

  output$download_taxonomy_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(ifelse(is.null(input$tax_sample), "sample", input$tax_sample)), "_checkpoint_D_taxonomy.zip"),
    content=function(file) {
      req(nrow(selected_tax_summary()))
      source_hits <- blast_hits_for_sample(input$tax_sample)
      make_taxonomy_checkpoint_zip(file, selected_tax_summary(), selected_tax_hits(), selected_tax_counts(), source_hits)
    }
  )

  # ---------------- Reset ----------------
  reset_pipeline_state <- function() {
    rv$results <- list(); rv$summary <- NULL; rv$rename <- NULL; rv$settings <- NULL
    rv$blast_jobs <- rv$blast_jobs[0,]; rv$blast_raw <- list(); rv$blast_ids <- data.frame(); rv$blast_hits <- data.frame()
    rv$ncbi_last_contact <- as.POSIXct(NA); rv$blast_batch_status_text <- "No batch operation has been run yet."
    rv$taxonomy_summary <- data.frame(); rv$taxonomy_hits <- data.frame(); rv$taxonomy_counts <- data.frame()
    rv$taxonomy_status_text <- "No taxonomic analysis has been run yet."
    rv$taxonomy_batch_status_text <- "No batch taxonomic analysis has been run yet."
    rv$project_status_text <- "Current session has not been saved as a project."
    rv$project_loaded_name <- ""
    updateTabsetPanel(session,"pipeline_step",selected="upload")
  }
  observeEvent(input$reset_pipeline, reset_pipeline_state())
  observeEvent(input$reset_pipeline_tax, reset_pipeline_state())
}

shinyApp(ui=ui,server=server)
