# ============================================================
# Sanger Sequence Pipeline v2.2
# Modular Shiny application
# ============================================================

required_cran <- c("shiny", "DT", "zip", "readxl", "httr2")
for (pkg in required_cran) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
}
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("sangerseqR", quietly = TRUE)) BiocManager::install("sangerseqR")

library(shiny)
library(DT)
library(sangerseqR)
options(shiny.maxRequestSize = 500 * 1024^2)

source(file.path("R", "core_sanger.R"), local = TRUE)
source(file.path("R", "sequence_tools.R"), local = TRUE)
source(file.path("R", "export_tools.R"), local = TRUE)

# ============================================================
# UI helpers
# ============================================================

panel_box <- function(...) div(class = "panel-box", ...)
section_title <- function(x) div(class = "section-title", x)

ui <- fluidPage(
  tags$head(
    tags$script(HTML("
      Shiny.addCustomMessageHandler('openUrl', function(message) {
        window.open(message.url, '_blank');
      });
      Shiny.addCustomMessageHandler('copyText', function(message) {
        navigator.clipboard.writeText(message.text);
      });

      // A real browser horizontal scrollbar used to navigate the chromatogram.
      // The plot itself remains fixed-width; scrolling reports a read position to Shiny.
      Shiny.addCustomMessageHandler('configureChromScrollbar', function(message) {
        var bar = document.getElementById('chrom_scrollbar');
        var inner = document.getElementById('chrom_scroll_inner');
        if (!bar || !inner) return;

        var viewport = Math.max(300, bar.clientWidth || 900);
        var totalBases = Math.max(1, Number(message.totalBases || 1));
        var visibleBases = Math.max(1, Number(message.visibleBases || 50));
        var scale = Math.max(1, totalBases / visibleBases);
        inner.style.width = Math.round(viewport * scale) + 'px';

        var maxScroll = Math.max(0, bar.scrollWidth - bar.clientWidth);
        var fraction = Math.max(0, Math.min(1, Number(message.fraction || 0)));
        bar.__suppressChromEvent = true;
        bar.scrollLeft = fraction * maxScroll;
        window.setTimeout(function(){ bar.__suppressChromEvent = false; }, 30);
      });

      $(document).on('shiny:connected', function() {
        var bindChromScrollbar = function() {
          var bar = document.getElementById('chrom_scrollbar');
          if (!bar || bar.__chromBound) return;
          bar.__chromBound = true;
          var scheduled = false;
          bar.addEventListener('scroll', function() {
            if (bar.__suppressChromEvent || scheduled) return;
            scheduled = true;
            window.requestAnimationFrame(function() {
              var maxScroll = Math.max(1, bar.scrollWidth - bar.clientWidth);
              var fraction = Math.max(0, Math.min(1, bar.scrollLeft / maxScroll));
              Shiny.setInputValue('chrom_scroll_fraction', fraction, {priority:'event'});
              scheduled = false;
            });
          });
        };
        bindChromScrollbar();
        new MutationObserver(bindChromScrollbar).observe(document.body, {childList:true, subtree:true});
      });
    ")),
    tags$style(HTML("
      body { background:#f5f7fa; }
      .pipeline-container { max-width:1450px; margin:auto; }
      .app-header { background:white; padding:22px 28px; margin:20px 0 18px; border-radius:12px; border:1px solid #e5e7eb; }
      .app-header h2 { margin:0 0 5px; }
      .app-header p { margin:0; color:#6b7280; }
      .panel-box { background:white; padding:22px; border-radius:12px; border:1px solid #e5e7eb; margin-bottom:18px; }
      .section-title { font-size:20px; font-weight:600; margin-bottom:16px; }
      .summary-card { background:#f8fafc; border:1px solid #e5e7eb; border-radius:10px; padding:15px; margin-bottom:10px; }
      .summary-number { font-size:26px; font-weight:700; }
      .summary-label { color:#6b7280; }
      .settings-note { color:#6b7280; font-size:13px; }
      .status-ok { color:#15803d; font-weight:600; }
      .status-warning { color:#b45309; font-weight:600; }
      .status-error { color:#b91c1c; font-weight:600; }
      .checkpoint { background:#fffaf0; border:1px solid #f3d7a0; }
      .mono { font-family:Consolas,Monaco,monospace; white-space:pre-wrap; word-break:break-all; background:#f8fafc; padding:12px; border-radius:8px; border:1px solid #e5e7eb; }
      table.dataTable td input { color:#111827 !important; background:#fff !important; }
      table.dataTable td input:focus { color:#111827 !important; background:#fff !important; }
      textarea.form-control { font-family:Consolas,Monaco,monospace; }
      .btn { border-radius:7px; margin-right:6px; margin-bottom:6px; }
      .chrom-scroll-wrap { margin-top:8px; }
      .chrom-scroll-label { font-size:12px; color:#6b7280; margin-bottom:3px; }
      #chrom_scrollbar { width:100%; overflow-x:scroll; overflow-y:hidden; height:20px; border:1px solid #e5e7eb; border-radius:5px; background:#f8fafc; }
      #chrom_scroll_inner { height:1px; min-width:100%; }
      .experimental-box { background:#fffdf5; border:1px solid #f1dfae; border-radius:8px; padding:10px 12px; margin-top:8px; }
    "))
  ),

  div(class = "pipeline-container",
    div(class = "app-header",
      h2("Sanger Sequence Pipeline"),
      p("AB1 processing → QC & chromatogram → rename → export → NCBI BLAST")
    ),

    tabsetPanel(id = "pipeline_step", type = "tabs",

      # --------------------------------------------------------
      # 1. Upload
      # --------------------------------------------------------
      tabPanel("1 · Upload", value = "upload",
        panel_box(
          section_title("Upload raw Sanger sequences"),
          fileInput("ab1_files", "Select AB1 files", multiple = TRUE,
                    accept = c(".ab1", ".AB1"), buttonLabel = "Select files"),
          p(class = "settings-note", "Multiple AB1 chromatogram files can be selected or dragged here."),
          DTOutput("uploaded_files_table"), br(),
          actionButton("to_settings", "Continue to Settings →", class = "btn-primary")
        )
      ),

      # --------------------------------------------------------
      # 2. Assay & trimming settings
      # --------------------------------------------------------
      tabPanel("2 · Assay & Trim", value = "settings",
        fluidRow(
          column(6,
            panel_box(
              section_title("Assay information"),
              selectInput("target", "Target / Gene",
                          c("ITS", "LSU", "TEF1 / EF1-alpha", "RPB2", "Beta-tubulin", "CYP51", "SDHB", "IGS", "Other"),
                          selected = "ITS"),
              textInput("forward_primer", "Forward primer name", ""),
              textInput("forward_primer_seq", "Forward primer sequence (5'→3')", ""),
              textInput("reverse_primer", "Reverse primer name", ""),
              textInput("reverse_primer_seq", "Reverse primer sequence (5'→3')", ""),
              radioButtons(
                "sequencing_primer", "Primer used for this Sanger read",
                choices = c("Forward" = "Forward", "Reverse" = "Reverse", "Unknown / infer" = "Unknown"),
                selected = "Forward", inline = TRUE
              ),
              checkboxInput("enable_primer_mapping", "Enable experimental primer-site mapping in QC", value = FALSE),
              div(class = "experimental-box",
                p(class = "settings-note", style="margin:0;",
                  "Experimental: Sanger base-calling often begins after the sequencing primer and the noisy read start can make primer-site inference unreliable. Keep this off unless primer-site inspection is specifically useful for the run.")),
              numericInput("expected_amplicon_len", "Expected amplicon length (bp)", 650, min = 1),
              numericInput("absolute_max_base_index", "Maximum sequence position (bp)", 680, min = 50)
            )
          ),
          column(6,
            panel_box(
              section_title("Advanced trimming settings"),
              numericInput("window", "Window size", 25, min = 5),
              numericInput("min_peak_ratio", "Minimum peak ratio", 3, min = 0, step = 0.1),
              numericInput("min_relative_signal", "Minimum relative signal", 0.20, min = 0, max = 1, step = 0.01),
              numericInput("min_len_before_collapse", "Minimum length before collapse search", 350, min = 1),
              numericInput("bad_run_windows", "Consecutive bad windows", 12, min = 1),
              numericInput("min_usable_len", "Minimum usable trimmed length", 400, min = 1)
            )
          )
        ),
        panel_box(
          actionButton("back_upload", "← Back"),
          actionButton("run_trimming", "Run trimming", class = "btn-primary")
        )
      ),

      # --------------------------------------------------------
      # 3. QC, chromatogram & sequence preview
      # --------------------------------------------------------
      tabPanel("3 · QC & Chromatogram", value = "qc",
        uiOutput("qc_summary_cards"),
        panel_box(
          section_title("Trimming results"),
          DTOutput("summary_table")
        ),
        fluidRow(
          column(4,
            panel_box(
              section_title("Sequence inspection"),
              selectInput("inspect_sample", "Sample", choices = NULL),
              numericInput("chrom_visible", "Visible bases (zoom)", value = 50, min = 10, max = 200, step = 5),
              p(class="settings-note", "Smaller values show fewer bases at higher horizontal resolution."),
              uiOutput("chrom_window_label"),
              DTOutput("sequence_metrics"),
              conditionalPanel(
                condition = "input.enable_primer_mapping === true",
                br(), h5("Experimental primer-site mapping"),
                DTOutput("primer_match_table")
              )
            )
          ),
          column(8,
            panel_box(
              section_title("Read / trim / primer overview"),
              plotOutput("amplicon_overview", height = "210px")
            ),
            panel_box(
              section_title("Chromatogram"),
              plotOutput("chromatogram_plot", height = "500px"),
              div(class="chrom-scroll-wrap",
                div(class="chrom-scroll-label", "Scroll through the read"),
                div(id="chrom_scrollbar", div(id="chrom_scroll_inner"))
              ),
              p(class = "settings-note", "The X axis is the called base position. Visible bases controls zoom; use the horizontal scrollbar directly below the graph to move through the read. Dashed lines mark trim boundaries.")
            )
          )
        ),
        conditionalPanel(
          condition = "input.enable_primer_mapping === true",
          panel_box(
            section_title("Experimental primer alignment"),
            verbatimTextOutput("primer_alignment")
          )
        ),
        panel_box(
          section_title("Processed sequence preview"),
          textAreaInput("trimmed_sequence_preview", NULL, value = "", rows = 8, width = "100%")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint A · Processed sequences"),
          p("Save an anchor after trimming/QC before renaming."),
          downloadButton("download_trim_checkpoint", "Download Trim checkpoint ZIP"),
          actionButton("back_settings", "← Back to Settings"),
          actionButton("to_rename", "Continue to Rename →", class = "btn-primary")
        )
      ),

      # --------------------------------------------------------
      # 4. Rename
      # --------------------------------------------------------
      tabPanel("4 · Rename", value = "rename",
        panel_box(
          section_title("Rename key"),
          p("Edit New_name manually or import a key."),
          fluidRow(
            column(6, fileInput("rename_key_file", "Upload rename key", multiple = FALSE, accept = c(".xlsx", ".csv"))),
            column(6, br(), actionButton("apply_rename_key", "Apply rename key", class = "btn-primary"))
          ),
          p(class = "settings-note", "Required columns: old_id and new_id. Prefix matching is supported, e.g. 265DMAA000 matches 265DMAA000_customer."),
          uiOutput("rename_key_status")
        ),
        panel_box(
          section_title("Batch rename tools"),
          fluidRow(
            column(3, textInput("rename_remove_suffix", "Remove suffix", "_customer")),
            column(3, textInput("rename_prefix", "Add prefix", "")),
            column(3, textInput("rename_suffix", "Add suffix", "")),
            column(3, actionButton("apply_batch_affixes", "Apply suffix/prefix tools", class = "btn-primary"))
          ),
          fluidRow(
            column(4, textInput("rename_find", "Find text", "")),
            column(4, textInput("rename_replace", "Replace with", "")),
            column(4, br(), actionButton("apply_find_replace", "Find & Replace"))
          ),
          actionButton("reset_names", "Reset names to original")
        ),
        panel_box(
          section_title("Sequence names"),
          DTOutput("rename_table"), br(),
          uiOutput("rename_validation")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint B · Renamed sequences"),
          p("Save an anchor after sample names have been resolved."),
          downloadButton("download_rename_checkpoint", "Download Rename checkpoint ZIP"),
          actionButton("back_qc", "← Back to QC"),
          actionButton("to_export", "Continue to Export →", class = "btn-primary")
        )
      ),

      # --------------------------------------------------------
      # 5. Export
      # --------------------------------------------------------
      tabPanel("5 · Export", value = "export",
        panel_box(section_title("Run summary"), uiOutput("export_summary")),
        panel_box(
          section_title("Final data exports"),
          downloadButton("download_blast_fasta", "BLAST FASTA"),
          downloadButton("download_full_fasta", "FASTA + metadata"),
          downloadButton("download_summary_csv", "Summary CSV"),
          downloadButton("download_all_zip", "Final results ZIP")
        ),
        panel_box(
          actionButton("back_rename", "← Back to Rename"),
          actionButton("to_blast", "Continue to NCBI BLAST →", class = "btn-primary")
        )
      ),

      # --------------------------------------------------------
      # 6. NCBI BLAST
      # --------------------------------------------------------
      tabPanel("6 · NCBI BLAST", value = "blast",
        panel_box(
          section_title("BLAST query workspace"),
          p("This stage uses the final processed and renamed sequence. The current version can submit a selected sequence to the official NCBI BLAST URL API and retrieve the result when it is ready."),
          fluidRow(
            column(4,
              selectInput("blast_sample", "Sequence", choices = NULL),
              selectInput("blast_database", "NCBI database", choices = c("core_nt", "nt"), selected = "core_nt"),
              numericInput("blast_hitlist", "Maximum hits", 10, min = 1, max = 100),
              actionButton("copy_blast_sequence", "Copy processed sequence"),
              actionButton("open_ncbi_blast", "Open NCBI Nucleotide BLAST"),
              downloadButton("download_selected_blast", "Download selected FASTA")
            ),
            column(8,
              h5("Processed query sequence"),
              textAreaInput("blast_sequence_preview", NULL, value = "", rows = 9, width = "100%")
            )
          )
        ),
        panel_box(
          section_title("NCBI automated submission · initial integration"),
          actionButton("submit_ncbi_blast", "Submit selected sequence to NCBI", class = "btn-primary"),
          actionButton("retrieve_ncbi_blast", "Check / retrieve result"),
          uiOutput("blast_job_status"),
          DTOutput("blast_jobs_table")
        ),
        panel_box(
          section_title("Preliminary identification result"),
          p(class = "settings-note", "Match support is a technical heuristic from BLAST identity, query coverage and E-value. It is not, by itself, a species-level taxonomic validation; interpretation should remain locus-aware."),
          DTOutput("blast_identification_table"),
          verbatimTextOutput("blast_raw_preview")
        ),
        div(class = "panel-box checkpoint",
          section_title("Checkpoint C · Identification workspace"),
          downloadButton("download_blast_jobs", "Download BLAST job/results CSV"),
          actionButton("back_export", "← Back to Export"),
          actionButton("reset_pipeline", "Start new run")
        )
      )
    )
  )
)

# ============================================================
# Server
# ============================================================

server <- function(input, output, session) {
  rv <- reactiveValues(
    results = list(), summary = NULL, rename = NULL, settings = NULL,
    blast_jobs = data.frame(final_name=character(), original_name=character(), rid=character(), rtoe=character(), status=character(), submitted_at=character(), stringsAsFactors=FALSE),
    blast_raw = list(), blast_ids = data.frame()
  )

  # ---------------- Upload ----------------
  output$uploaded_files_table <- renderDT({
    req(input$ab1_files)
    datatable(data.frame(File=input$ab1_files$name, Size_KB=round(input$ab1_files$size/1024,1)),
              rownames=FALSE, options=list(pageLength=15, dom="tip"))
  })

  observeEvent(input$to_settings, {
    if (is.null(input$ab1_files) || nrow(input$ab1_files)==0) {
      showNotification("Please upload at least one AB1 file.", type="error"); return()
    }
    updateTabsetPanel(session, "pipeline_step", selected="settings")
  })
  observeEvent(input$back_upload, updateTabsetPanel(session,"pipeline_step",selected="upload"))
  observeEvent(input$back_settings, updateTabsetPanel(session,"pipeline_step",selected="settings"))
  observeEvent(input$back_qc, updateTabsetPanel(session,"pipeline_step",selected="qc"))
  observeEvent(input$back_rename, updateTabsetPanel(session,"pipeline_step",selected="rename"))
  observeEvent(input$back_export, updateTabsetPanel(session,"pipeline_step",selected="export"))

  # ---------------- Trimming ----------------
  observeEvent(input$run_trimming, {
    req(input$ab1_files)
    settings <- list(
      target=input$target,
      forward_primer=input$forward_primer,
      forward_primer_seq=sanitize_dna(input$forward_primer_seq),
      reverse_primer=input$reverse_primer,
      reverse_primer_seq=sanitize_dna(input$reverse_primer_seq),
      sequencing_primer=input$sequencing_primer,
      enable_primer_mapping=isTRUE(input$enable_primer_mapping),
      expected_amplicon_len=as.integer(input$expected_amplicon_len),
      absolute_max_base_index=as.integer(input$absolute_max_base_index),
      window=as.integer(input$window),
      min_peak_ratio=as.numeric(input$min_peak_ratio),
      min_relative_signal=as.numeric(input$min_relative_signal),
      min_len_before_collapse=as.integer(input$min_len_before_collapse),
      bad_run_windows=as.integer(input$bad_run_windows),
      min_usable_len=as.integer(input$min_usable_len)
    )
    rv$settings <- settings
    all_results <- list(); summaries <- list(); files <- input$ab1_files

    withProgress(message="Processing AB1 files", value=0, {
      for (i in seq_len(nrow(files))) {
        sample_id <- sub("\\.ab1$", "", files$name[i], ignore.case=TRUE)
        incProgress(1/nrow(files), detail=paste("Processing", files$name[i]))
        result <- tryCatch(
          trim_one_ab1(files$datapath[i], sample_id, settings),
          error=function(e) structure(list(error=conditionMessage(e)), class="ab1_error")
        )
        if (inherits(result,"ab1_error")) {
          summaries[[sample_id]] <- make_failure_summary(sample_id, settings, result$error)
        } else {
          all_results[[sample_id]] <- result
          summaries[[sample_id]] <- result$summary
        }
      }
    })

    rv$results <- all_results
    rv$summary <- do.call(rbind, summaries); rownames(rv$summary) <- NULL
    rv$rename <- data.frame(Original_name=rv$summary$sample_id, New_name=rv$summary$sample_id, stringsAsFactors=FALSE)
    choices <- names(rv$results)
    updateSelectInput(session,"inspect_sample",choices=choices,selected=if(length(choices)) choices[1] else character())
    updateTabsetPanel(session,"pipeline_step",selected="qc")
  })

  # ---------------- QC summary ----------------
  output$qc_summary_cards <- renderUI({
    req(rv$summary)
    vals <- c(
      Total=nrow(rv$summary),
      OK=sum(rv$summary$status=="OK",na.rm=TRUE),
      Warnings=sum(rv$summary$status=="SHORT_AFTER_TRIMMING",na.rm=TRUE),
      Failed=sum(rv$summary$status %in% c("FAILED_TRIMMING","ERROR"),na.rm=TRUE)
    )
    fluidRow(lapply(names(vals), function(nm) column(3, div(class="summary-card", div(class="summary-number",vals[[nm]]), div(class="summary-label",nm)))))
  })

  output$summary_table <- renderDT({
    req(rv$summary)
    df <- rv$summary[,c("sample_id","target","raw_length","trimmed_length","trim_start","trim_end","collapse_index","reason","median_peak_ratio_trimmed","status")]
    names(df) <- c("Sample","Target","Raw length","Trimmed length","Start","End","Collapse","Reason","Median peak ratio","Status")
    datatable(df, rownames=FALSE, filter="top", options=list(pageLength=15,scrollX=TRUE))
  })

  selected_result <- reactive({
    req(input$inspect_sample, rv$results[[input$inspect_sample]])
    rv$results[[input$inspect_sample]]
  })

  # Chromatogram navigation state. Zoom and horizontal position are deliberately
  # independent to prevent the old slider/update feedback loop.
  chrom_start_base <- reactiveVal(1L)
  chrom_last_visible <- reactiveVal(50L)

  chrom_visible_bases <- reactive({
    r <- selected_result()
    v <- suppressWarnings(as.integer(input$chrom_visible))
    if (is.na(v)) v <- 50L
    max(10L, min(v, length(r$peak_pos)))
  })

  sync_chrom_scrollbar <- function(r, visible, start) {
    n <- length(r$peak_pos)
    max_start <- max(1L, n - visible + 1L)
    start <- max(1L, min(as.integer(start), max_start))
    fraction <- if (max_start <= 1L) 0 else (start - 1) / (max_start - 1)
    session$sendCustomMessage("configureChromScrollbar", list(
      totalBases = n,
      visibleBases = visible,
      fraction = fraction
    ))
  }

  observeEvent(input$inspect_sample, {
    r <- selected_result()
    visible <- max(10L, min(50L, length(r$peak_pos)))
    # Keep the numeric zoom stable; unlike sliderInput this does not create a
    # recurring update loop.
    updateNumericInput(session, "chrom_visible", value = visible, min = 10, max = 200, step = 5)
    preferred <- if (!is.na(r$summary$trim_start)) max(1L, r$summary$trim_start - 5L) else 1L
    max_start <- max(1L, length(r$peak_pos) - visible + 1L)
    preferred <- min(preferred, max_start)
    chrom_start_base(preferred)
    chrom_last_visible(visible)
    session$onFlushed(function() sync_chrom_scrollbar(r, visible, preferred), once = TRUE)
    updateTextAreaInput(session,"trimmed_sequence_preview",value=r$seq)
  })

  observeEvent(input$chrom_visible, {
    req(input$inspect_sample)
    r <- selected_result()
    new_visible <- chrom_visible_bases()
    old_visible <- chrom_last_visible()
    old_start <- chrom_start_base()
    center <- old_start + (old_visible - 1) / 2
    new_start <- round(center - (new_visible - 1) / 2)
    max_start <- max(1L, length(r$peak_pos) - new_visible + 1L)
    new_start <- max(1L, min(new_start, max_start))
    chrom_start_base(new_start)
    chrom_last_visible(new_visible)
    session$onFlushed(function() sync_chrom_scrollbar(r, new_visible, new_start), once = TRUE)
  }, ignoreInit = TRUE)

  observeEvent(input$chrom_scroll_fraction, {
    req(input$inspect_sample)
    r <- selected_result()
    visible <- chrom_visible_bases()
    max_start <- max(1L, length(r$peak_pos) - visible + 1L)
    frac <- suppressWarnings(as.numeric(input$chrom_scroll_fraction))
    if (!is.finite(frac)) return()
    frac <- max(0, min(1, frac))
    start <- 1L + round(frac * (max_start - 1L))
    if (!identical(as.integer(start), as.integer(chrom_start_base()))) chrom_start_base(start)
  }, ignoreInit = TRUE)

  output$chrom_window_label <- renderUI({
    r <- selected_result()
    visible <- chrom_visible_bases()
    start <- max(1L, min(chrom_start_base(), max(1L,length(r$peak_pos)-visible+1L)))
    end <- min(length(r$peak_pos), start + visible - 1L)
    p(class="settings-note", paste0("Viewing bases ", start, "–", end, " of ", length(r$peak_pos)))
  })

  output$sequence_metrics <- renderDT({
    datatable(make_sequence_preview(selected_result()), rownames=FALSE, options=list(dom="t"))
  })
  output$primer_match_table <- renderDT({
    req(isTRUE(input$enable_primer_mapping))
    datatable(primer_match_table(selected_result(),rv$settings), rownames=FALSE, options=list(dom="t",scrollX=TRUE))
  })
  output$primer_alignment <- renderText({
    req(isTRUE(input$enable_primer_mapping))
    primer_alignment_text(selected_result(),rv$settings)
  })
  output$amplicon_overview <- renderPlot({
    draw_amplicon_overview(selected_result(), rv$settings)
  })
  output$chromatogram_plot <- renderPlot({
    r <- selected_result()
    visible <- chrom_visible_bases()
    start <- max(1L, min(chrom_start_base(), max(1L,length(r$peak_pos)-visible+1L)))
    draw_chromatogram(r,rv$settings,start_base=start,visible_bases=visible)
  })

  observeEvent(input$to_rename, { req(rv$summary); updateTabsetPanel(session,"pipeline_step",selected="rename") })

  # ---------------- Rename key ----------------
  rename_key_data <- reactive({
    req(input$rename_key_file)
    f <- input$rename_key_file; ext <- tolower(tools::file_ext(f$name))
    key <- if (ext=="xlsx") readxl::read_excel(f$datapath) else if (ext=="csv") read.csv(f$datapath,stringsAsFactors=FALSE,check.names=FALSE) else stop("Rename key must be XLSX or CSV.")
    key <- as.data.frame(key,stringsAsFactors=FALSE)
    if (!all(c("old_id","new_id") %in% names(key))) stop("Rename key must contain old_id and new_id columns.")
    key$old_id <- trimws(as.character(key$old_id)); key$new_id <- trimws(as.character(key$new_id))
    key[key$old_id!="" & key$new_id!="",,drop=FALSE]
  })

  observeEvent(input$apply_rename_key, {
    req(rv$rename)
    key <- tryCatch(rename_key_data(), error=function(e){showNotification(conditionMessage(e),type="error");NULL})
    if (is.null(key)) return()
    matched <- 0L
    for(i in seq_len(nrow(rv$rename))) {
      original <- rv$rename$Original_name[i]
      idx <- which(key$old_id==original)
      if(!length(idx)) idx <- which(startsWith(original,key$old_id))
      if(length(idx)==1) { rv$rename$New_name[i] <- key$new_id[idx]; matched <- matched+1L }
    }
    showNotification(paste(matched,"of",nrow(rv$rename),"sample names matched."),type="message")
  })

  observeEvent(input$apply_batch_affixes, {
    req(rv$rename)
    x <- rv$rename$New_name
    rem <- input$rename_remove_suffix
    if(nzchar(rem)) x <- ifelse(endsWith(x, rem), substr(x, 1, nchar(x) - nchar(rem)), x)
    if(nzchar(input$rename_prefix)) x <- paste0(input$rename_prefix,x)
    if(nzchar(input$rename_suffix)) x <- paste0(x,input$rename_suffix)
    rv$rename$New_name <- x
  })
  observeEvent(input$apply_find_replace, {
    req(rv$rename)
    if(!nzchar(input$rename_find)) return()
    rv$rename$New_name <- gsub(input$rename_find,input$rename_replace,rv$rename$New_name,fixed=TRUE)
  })
  observeEvent(input$reset_names, { req(rv$rename); rv$rename$New_name <- rv$rename$Original_name })

  output$rename_table <- renderDT({
    req(rv$rename)
    datatable(rv$rename,rownames=FALSE,editable=list(target="cell",disable=list(columns=c(0))),options=list(pageLength=20,dom="tip"))
  })
  observeEvent(input$rename_table_cell_edit, {
    info <- input$rename_table_cell_edit
    if(info$col==1) rv$rename[info$row,"New_name"] <- as.character(info$value)
  })

  rename_error <- reactive({
    req(rv$rename)
    x <- trimws(rv$rename$New_name)
    if(any(x=="")) return("One or more sequence names are empty.")
    clean <- clean_fasta_name(x)
    if(anyDuplicated(clean)>0) return(paste0("Duplicate sequence name(s): ",paste(unique(clean[duplicated(clean)|duplicated(clean,fromLast=TRUE)]),collapse=", ")))
    NULL
  })
  output$rename_validation <- renderUI({
    e <- rename_error(); if(is.null(e)) div(class="status-ok","✓ Sequence names are valid.") else div(class="status-error",paste0("⚠ ",e))
  })

  # ---------------- Export records ----------------
  export_records <- reactive({
    req(rv$results,rv$rename)
    records <- list()
    for(original_name in names(rv$results)) {
      r <- rv$results[[original_name]]
      idx <- match(original_name,rv$rename$Original_name)
      r$final_name <- if(!is.na(idx)) rv$rename$New_name[idx] else original_name
      records[[original_name]] <- r
    }
    records
  })
  export_summary_df <- reactive({
    req(rv$summary,rv$rename)
    df <- rv$summary
    df$final_name <- rv$rename$New_name[match(df$sample_id,rv$rename$Original_name)]
    df
  })

  observeEvent(input$to_export, {
    e <- rename_error(); if(!is.null(e)){showNotification(e,type="error");return()}
    updateTabsetPanel(session,"pipeline_step",selected="export")
  })

  output$export_summary <- renderUI({
    req(rv$summary,rv$settings)
    tagList(
      p(strong("Target: "),rv$settings$target),
      p(strong("Forward primer: "),ifelse(rv$settings$forward_primer=="","Not specified",rv$settings$forward_primer)),
      p(strong("Reverse primer: "),ifelse(rv$settings$reverse_primer=="","Not specified",rv$settings$reverse_primer)),
      p(strong("Samples processed: "),nrow(rv$summary)),
      p(strong("Sequences available for export: "),sum(rv$summary$trimmed_length>0,na.rm=TRUE))
    )
  })

  # ---------------- Checkpoints ----------------
  output$download_trim_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_checkpoint_A_trim.zip"),
    content=function(file){
      rec <- export_records(); for(n in names(rec)) rec[[n]]$final_name <- n
      write_checkpoint_zip(file,"trim",rec,rv$summary,rv$settings)
    })
  output$download_rename_checkpoint <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_checkpoint_B_rename.zip"),
    content=function(file) write_checkpoint_zip(file,"renamed",export_records(),export_summary_df(),rv$settings,rv$rename))

  output$download_blast_fasta <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_BLAST.fasta"),
    content=function(file) writeLines(make_fasta(export_records(),FALSE),file))
  output$download_full_fasta <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_trimmed_sequences.fasta"),
    content=function(file) writeLines(make_fasta(export_records(),TRUE,export_summary_df()),file))
  output$download_summary_csv <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_trim_summary.csv"),
    content=function(file) write.csv(export_summary_df(),file,row.names=FALSE,fileEncoding="UTF-8"))
  output$download_all_zip <- downloadHandler(
    filename=function() paste0(clean_fasta_name(rv$settings$target),"_Sanger_pipeline_results.zip"),
    content=function(file) write_checkpoint_zip(file,"final",export_records(),export_summary_df(),rv$settings,rv$rename))

  # ---------------- BLAST workspace ----------------
  observeEvent(input$to_blast, {
    rec <- export_records(); choices <- setNames(names(rec),vapply(rec,function(x)x$final_name,character(1)))
    updateSelectInput(session,"blast_sample",choices=choices,selected=if(length(choices)) names(choices)[1] else character())
    updateTabsetPanel(session,"pipeline_step",selected="blast")
  })

  blast_selected <- reactive({ req(input$blast_sample); export_records()[[input$blast_sample]] })
  observe({
    req(input$blast_sample)
    updateTextAreaInput(session,"blast_sequence_preview",value=blast_selected()$seq)
  })
  observeEvent(input$copy_blast_sequence, session$sendCustomMessage("copyText",list(text=blast_selected()$seq)))
  observeEvent(input$open_ncbi_blast, session$sendCustomMessage("openUrl",list(url="https://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE_TYPE=BlastSearch&PROGRAM=blastn")))
  output$download_selected_blast <- downloadHandler(
    filename=function() paste0(clean_fasta_name(blast_selected()$final_name),".fasta"),
    content=function(file) writeLines(paste0(">",clean_fasta_name(blast_selected()$final_name),"\n",wrap_sequence(blast_selected()$seq,80)),file))

  observeEvent(input$submit_ncbi_blast, {
    r <- blast_selected(); req(nzchar(r$seq))
    req_obj <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
      httr2::req_body_form(
        CMD="Put", PROGRAM="blastn", DATABASE=input$blast_database,
        QUERY=paste0(">",clean_fasta_name(r$final_name),"\n",r$seq),
        HITLIST_SIZE=as.integer(input$blast_hitlist)
      ) |>
      httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")
    txt <- tryCatch(httr2::resp_body_string(httr2::req_perform(req_obj)), error=function(e){showNotification(conditionMessage(e),type="error");NULL})
    if(is.null(txt)) return()
    rid_match <- regmatches(txt, regexpr("RID = [A-Z0-9-]+", txt))
    rtoe_match <- regmatches(txt, regexpr("RTOE = [0-9]+", txt))
    rid <- if (length(rid_match) && nzchar(rid_match)) sub("RID = ", "", rid_match, fixed=TRUE) else ""
    rtoe <- if (length(rtoe_match) && nzchar(rtoe_match)) sub("RTOE = ", "", rtoe_match, fixed=TRUE) else NA_character_
    if(!nzchar(rid)) { showNotification("NCBI did not return a BLAST RID.",type="error"); return() }
    rv$blast_jobs <- rbind(rv$blast_jobs,data.frame(
      final_name=r$final_name,original_name=input$blast_sample,rid=rid,rtoe=rtoe,status="SUBMITTED",
      submitted_at=format(Sys.time(),"%Y-%m-%d %H:%M:%S"),stringsAsFactors=FALSE))
    showNotification(paste("Submitted to NCBI. RID:",rid),type="message")
  })

  observeEvent(input$retrieve_ncbi_blast, {
    r <- blast_selected()
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name==input$blast_sample,,drop=FALSE]
    if(!nrow(jobs)){showNotification("Submit this sequence first.",type="warning");return()}
    rid <- jobs$rid[nrow(jobs)]
    req_obj <- httr2::request("https://blast.ncbi.nlm.nih.gov/Blast.cgi") |>
      httr2::req_url_query(CMD="Get",RID=rid,FORMAT_TYPE="CSV",ALIGNMENT_VIEW="Tabular") |>
      httr2::req_user_agent("Local Sanger Sequence Pipeline / NCBI BLAST client")
    txt <- tryCatch(httr2::resp_body_string(httr2::req_perform(req_obj)), error=function(e){showNotification(conditionMessage(e),type="error");NULL})
    if(is.null(txt)) return()
    if(grepl("Status=WAITING",txt)) { rv$blast_jobs$status[rv$blast_jobs$rid==rid] <- "WAITING"; showNotification("NCBI BLAST is still running.",type="message"); return() }
    if(grepl("Status=FAILED|Status=UNKNOWN",txt)) { rv$blast_jobs$status[rv$blast_jobs$rid==rid] <- "FAILED/UNKNOWN"; showNotification("NCBI reports failed or unknown job.",type="error"); return() }
    rv$blast_jobs$status[rv$blast_jobs$rid==rid] <- "READY"
    rv$blast_raw[[rid]] <- txt
    hit <- parse_blast_csv_top_hit(txt)
    if(!is.null(hit)) {
      # Enrich the BLAST row from the corresponding NCBI nucleotide record.
      # This is more reliable for organism name than guessing from an accession.
      meta <- tryCatch(fetch_ncbi_nucleotide_metadata(hit$accession), error=function(e) NULL)
      if (!is.null(meta)) {
        if (nzchar(meta$organism)) hit$organism <- meta$organism
        if (nzchar(meta$title)) hit$record_title <- meta$title
      }
      hit$final_name <- r$final_name; hit$original_name <- input$blast_sample; hit$rid <- rid
      wanted <- c("final_name","original_name","rid","top_hit","organism","record_title","accession","identity_percent","query_coverage_percent","evalue","match_support")
      for (nm in setdiff(wanted,names(hit))) hit[[nm]] <- NA_character_
      # Replace previous retrieval of the same RID instead of creating duplicate rows.
      if (nrow(rv$blast_ids) && "rid" %in% names(rv$blast_ids)) rv$blast_ids <- rv$blast_ids[rv$blast_ids$rid != rid,,drop=FALSE]
      rv$blast_ids <- rbind(rv$blast_ids,hit[,wanted,drop=FALSE])
    }
    showNotification("BLAST result retrieved.",type="message")
  })

  output$blast_job_status <- renderUI({
    req(input$blast_sample)
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name==input$blast_sample,,drop=FALSE]
    if(!nrow(jobs)) return(p(class="settings-note","No NCBI submission yet for this sequence."))
    j <- jobs[nrow(jobs),]
    div(class=if(j$status=="READY") "status-ok" else "status-warning", paste("RID:",j$rid,"| Status:",j$status,"| Estimated wait (RTOE):",j$rtoe,"seconds"))
  })
  output$blast_jobs_table <- renderDT({ datatable(rv$blast_jobs,rownames=FALSE,options=list(pageLength=10,scrollX=TRUE)) })
  output$blast_identification_table <- renderDT({
    df <- rv$blast_ids
    if(!nrow(df)) {
      df <- data.frame(Message="No parsed identification result yet. Submit and retrieve a BLAST job.")
    } else {
      keep <- intersect(c("final_name","organism","record_title","accession","identity_percent","query_coverage_percent","evalue","match_support","rid"), names(df))
      df <- df[, keep, drop=FALSE]
      friendly <- c(
        final_name="Sample", organism="Organism / taxon", record_title="NCBI hit title",
        accession="Accession", identity_percent="Identity (%)", query_coverage_percent="Query coverage (%)",
        evalue="E-value", match_support="Match support", rid="RID"
      )
      names(df) <- unname(friendly[names(df)])
    }
    datatable(df,rownames=FALSE,options=list(pageLength=10,scrollX=TRUE))
  })
  output$blast_raw_preview <- renderText({
    req(input$blast_sample)
    jobs <- rv$blast_jobs[rv$blast_jobs$original_name==input$blast_sample,,drop=FALSE]
    if(!nrow(jobs)) return("")
    rid <- jobs$rid[nrow(jobs)]; txt <- rv$blast_raw[[rid]]
    if(is.null(txt)) return("")
    substr(txt,1,min(4000,nchar(txt)))
  })
  output$download_blast_jobs <- downloadHandler(
    filename=function() "NCBI_BLAST_jobs_and_identifications.csv",
    content=function(file){
      jobs <- rv$blast_jobs
      if(nrow(rv$blast_ids)) jobs <- merge(jobs,rv$blast_ids,by=c("final_name","original_name","rid"),all.x=TRUE)
      write.csv(jobs,file,row.names=FALSE,fileEncoding="UTF-8")
    })

  # ---------------- Reset ----------------
  observeEvent(input$reset_pipeline, {
    rv$results <- list(); rv$summary <- NULL; rv$rename <- NULL; rv$settings <- NULL
    rv$blast_jobs <- rv$blast_jobs[0,]; rv$blast_raw <- list(); rv$blast_ids <- data.frame()
    updateTabsetPanel(session,"pipeline_step",selected="upload")
  })
}

shinyApp(ui=ui,server=server)
