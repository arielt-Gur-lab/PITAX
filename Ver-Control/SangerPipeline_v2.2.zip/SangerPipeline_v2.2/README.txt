Sanger Sequence Pipeline v2.2
=============================

Workflow
--------
1. Upload AB1 chromatograms
2. Define assay and trimming settings
3. Trim + QC + chromatogram inspection
4. Rename samples manually or with an XLSX/CSV key
5. Export processed FASTA / checkpoints
6. Submit processed sequences to NCBI BLAST and retrieve the top hit

v2.2 changes
------------
- Fixed chromatogram zoom feedback/oscillation.
- Visible bases is now a numeric zoom control rather than a self-updating slider.
- Added a real browser horizontal scrollbar directly below the chromatogram.
- Chromatogram X axis remains base position; raw trace-sample coordinates are internal only.
- Expected amplicon length is displayed as metadata below the overview rather than as a misleading coordinate label.
- Primer-site mapping is now EXPERIMENTAL and OFF by default because sequencing-primer sequence may be absent/noisy in Sanger base calls.
- NCBI identification table now uses readable column labels.
- After a BLAST top hit is retrieved, the app attempts to fetch the NCBI nucleotide record and display its organism/taxon name and full record title in addition to accession.
- Existing checkpoint/export workflow retained.

NCBI note
---------
The current identification stage retrieves one top BLAST hit per submitted sequence. Match support is a technical summary only; a later stage can compare multiple hits and determine locus-aware identification confidence.
