# Manual smoke tests for the v2.10 score-aware taxonomy engine.
# Run from the application folder with:
#   Rscript tests/taxonomy_logic_smoke.R

source(file.path("R", "taxonomy_tools.R"))

make_hits <- function(species, genus, bits, identity, coverage, accession_prefix="ACC") {
  n <- length(bits)
  data.frame(
    rank=seq_len(n),
    organism=species,
    record_title=paste(species, "ITS sequence"),
    accession=paste0(accession_prefix, seq_len(n), ".1"),
    taxid=seq_len(n)+1000L,
    identity_percent=identity,
    query_coverage_percent=coverage,
    evalue=rep(0, n),
    bit_score=bits,
    alignment_length=rep(500L,n),
    hsp_count=rep(1L,n),
    match_support=rep("Strong",n),
    kingdom=rep("Fungi",n), phylum=rep("Basidiomycota",n), class=rep("Agaricomycetes",n),
    order=rep("Agaricales",n), family=rep("Exampleaceae",n), genus=genus, species=species,
    reference_quality=rep("Standard GenBank",n),
    stringsAsFactors=FALSE
  )
}

# Case 1: broad ITS species agreement but Identity below broad 99.6% species
# benchmark. Expected: genus recommendation + retained species candidate.
bits <- c(1114,1110,1096,1089,1085,1082,1079,1076,1060,1015,1014,1014,1011,980,969,750)
h1 <- make_hits(rep("Granulobasidium vellereum",16), rep("Granulobasidium",16), bits,
                c(rep(98.2,15),86.9), c(rep(98,15),98))
h1$species[16] <- "Cunninghammyces umbonatus"
h1$genus[16] <- "Cunninghammyces"
h1$organism[16] <- h1$species[16]
r1 <- build_taxonomic_consensus(h1, target="ITS", top_n=16)$summary
stopifnot(r1$recommended_identification == "Granulobasidium")
stopifnot(r1$recommended_level == "genus")
stopifnot(r1$species_candidate == "Granulobasidium vellereum")
stopifnot(r1$primary_score_cluster_hits == 15)

# Case 2: full-length, high-identity ITS with no close species competitor.
h2 <- make_hits(rep("Pleurotus pulmonarius",10), rep("Pleurotus",10),
                seq(900,873,length.out=10), rep(99.8,10), rep(100,10), "PLE")
r2 <- build_taxonomic_consensus(h2, target="ITS", top_n=10)$summary
stopifnot(r2$recommended_identification == "Pleurotus pulmonarius")
stopifnot(r2$recommended_level == "species candidate")

# Case 3: two close species with essentially tied scores. Species should not
# be accepted merely because the first accession happens to rank first.
h3 <- make_hits(
  c("Fusarium alpha","Fusarium beta","Fusarium alpha","Fusarium beta","Fusarium alpha"),
  rep("Fusarium",5), c(900,899,898,897,896), rep(99.8,5), rep(100,5), "FUS")
r3 <- build_taxonomic_consensus(h3, target="ITS", top_n=5)$summary
stopifnot(r3$recommended_identification == "Fusarium")
stopifnot(r3$recommended_level == "genus")

cat("v2.10 taxonomy smoke tests passed.\n")
