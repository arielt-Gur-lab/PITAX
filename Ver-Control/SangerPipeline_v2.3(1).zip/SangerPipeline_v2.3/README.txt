Sanger Sequence Pipeline v2.3
=============================

Main workflow
-------------
1. Upload AB1 chromatograms
2. Configure assay and trimming parameters
3. Run trimming and QC
4. Inspect interactive chromatogram and QC plots
5. Rename samples manually or with old_id/new_id key
6. Export processed FASTA / summaries / checkpoints
7. Submit selected processed sequence to NCBI BLAST and retrieve structured hits

v2.3 changes
------------
- Chromatogram moved from repeatedly rendered PNG plots to a client-side Plotly graph.
  * X axis is base position.
  * Mouse-wheel zoom and pan are interactive in the browser.
  * The Plotly range slider beneath the graph acts as a horizontal scrollbar.
  * Base-call letters move with the interactive viewport.
- Original QC plots (called-base signal and peak ratio) are restored on screen.
- QC plot PNGs are included in Checkpoint A, Checkpoint B and Final ZIP exports.
- Expected amplicon length is displayed as metadata below the overview rather than as a misleading track coordinate.
- NCBI retrieval now requests the supported XML2 format first.
- BLAST hit tables include friendly column names, scientific organism/taxon, title, accession,
  TaxID, identity, query coverage, E-value, bit score and match support when available.
- All retrieved hits are preserved in a separate table/CSV for the next multi-hit confidence stage.
- Headerless NCBI tabular CSV is retained as a defensive fallback parser.
- The app prevents polling the same BLAST RID more often than once per minute.

Primer mapping
--------------
Primer-site mapping remains experimental and disabled by default. It is not used to decide trimming quality.

Run
---
Double-click run_app.bat.
